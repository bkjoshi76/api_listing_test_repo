import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { LayoutDashboard, Server, Shield, Activity, RefreshCw, Download, Plus, Trash2, Save, AlertTriangle, Moon, Sun, Settings } from 'lucide-react';
import StatCard from './components/StatCard';
import ApiTable from './components/ApiTable';
import AnalyticsChart from './components/AnalyticsChart';

function App() {
  const [hosts, setHosts] = useState([
    { name: 'Example Host', host: 'api.example.com', port: '8075', username: 'admin', password: 'password' }
  ]);
  const [apis, setApis] = useState([]);
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState('dashboard');
  const [theme, setTheme] = useState('light');
  const [showHostSettings, setShowHostSettings] = useState(false);
  const [hostAliases, setHostAliases] = useState({});

  useEffect(() => {
    // Check system preference
    if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
      setTheme('dark');
    }
    fetchHostAliases();
  }, []);

  const fetchHostAliases = async () => {
    try {
      const response = await axios.get('http://localhost:8000/api/hosts');
      setHostAliases(response.data);
    } catch (error) {
      console.error("Error fetching host aliases:", error);
    }
  };

  const updateHostAlias = async (host, alias) => {
    try {
      await axios.post('http://localhost:8000/api/hosts/alias', { host, alias });
      setHostAliases(prev => ({ ...prev, [host]: alias }));
      // Refresh APIs to reflect new alias
      if (apis.length > 0) {
        setApis(prev => prev.map(api => api.host === host ? { ...api, host_alias: alias } : api));
      }
    } catch (error) {
      console.error("Error updating host alias:", error);
      alert("Failed to update alias");
    }
  };

  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [theme]);

  const toggleTheme = () => {
    setTheme(theme === 'light' ? 'dark' : 'light');
  };

  const fetchApis = async () => {
    setLoading(true);
    try {
      const response = await axios.post('http://localhost:8000/api/proxies', hosts);
      setApis(response.data);
    } catch (error) {
      console.error("Error fetching APIs:", error);
      alert("Failed to fetch APIs. Check console for details.");
    } finally {
      setLoading(false);
    }
  };

  const addHost = () => {
    setHosts([...hosts, { name: '', host: '', port: '8075', username: '', password: '' }]);
  };

  const removeHost = (index) => {
    const newHosts = [...hosts];
    newHosts.splice(index, 1);
    setHosts(newHosts);
  };

  const updateHost = (index, field, value) => {
    const newHosts = [...hosts];
    newHosts[index][field] = value;
    setHosts(newHosts);
  };

  useEffect(() => {
    const savedHosts = localStorage.getItem('axway_dash_hosts');
    if (savedHosts) {
      try {
        setHosts(JSON.parse(savedHosts));
      } catch (e) {
        console.error("Failed to parse saved hosts", e);
      }
    }
  }, []);

  const saveConfiguration = () => {
    localStorage.setItem('axway_dash_hosts', JSON.stringify(hosts));
    alert("Configuration saved!");
  };

  const loadDemoData = () => {
    const demoHosts = [
      { name: 'Production', host: 'mock-prod', port: '8075', username: 'admin', password: 'password' },
      { name: 'Staging', host: 'mock-staging', port: '8075', username: 'admin', password: 'password' },
      { name: 'Development', host: 'mock-dev', port: '8075', username: 'dev', password: 'password' }
    ];
    setHosts(demoHosts);
    // Trigger fetch immediately after setting host (need to wait for state update in real app, but here we can just call with the new host)
    setLoading(true);
    axios.post('http://localhost:8000/api/proxies', demoHosts)
      .then(response => {
        setApis(response.data);
        setActiveTab('dashboard');
      })
      .catch(error => console.error(error))
      .finally(() => setLoading(false));
  };

  // Calculate stats
  const stats = React.useMemo(() => {
    const activeApis = apis.filter(api => !api.ignore);
    const total = activeApis.length;
    const publishedCount = activeApis.filter(a => a.state === 'published').length;
    const publishedTrend = total > 0 ? Math.round((publishedCount / total) * 100) : 0;
    const highComplexityCount = activeApis.filter(a => a.technical_complexity === 'High').length;
    const deprecatedCount = activeApis.filter(a => a.state === 'deprecated').length;

    return [
      {
        title: 'Total APIs',
        value: total,
        icon: Server,
        color: 'text-blue-600',
        trend: 'Total'
      },
      {
        title: 'Published APIs',
        value: publishedCount,
        icon: Shield,
        color: 'text-green-600',
        trend: `${publishedTrend}% `
      },
      {
        title: 'High Complexity',
        value: highComplexityCount,
        icon: Activity,
        color: 'text-purple-600',
        trend: 'Technical'
      },
      {
        title: 'Deprecated',
        value: deprecatedCount,
        icon: AlertTriangle,
        color: 'text-amber-600',
        trend: 'Action Needed'
      }
    ];
  }, [apis]);

  const handleComplexityUpdate = async (targetApi, field, value) => {
    // Optimistic update
    setApis(apis.map(api =>
      (api.host === targetApi.host && api.name === targetApi.name && api.version === targetApi.version)
        ? { ...api, [field]: value }
        : api
    ));

    // Persist to backend
    try {
      await axios.post('http://localhost:8000/api/complexity', {
        host: targetApi.host,
        name: targetApi.name,
        version: targetApi.version,
        field: field,
        value: value
      });
    } catch (error) {
      console.error("Error updating complexity:", error);
      // Revert on failure (optional, but good practice)
    }
  };

  const fileInputRef = React.useRef(null);

  const handleImportClick = () => {
    fileInputRef.current.click();
  };

  const handleImport = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    const formData = new FormData();
    formData.append('file', file);

    setLoading(true);
    try {
      const response = await axios.post('http://localhost:8000/api/import', formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      });
      setApis(prevApis => {
        const existingIds = new Set(prevApis.map(api => `${api.host}:${api.name}:${api.version}`));
        const newApis = response.data.filter(api => !existingIds.has(`${api.host}:${api.name}:${api.version}`));
        return [...prevApis, ...newApis];
      });
      alert(`Successfully imported ${response.data.length} APIs (Merged with existing)`);
    } catch (error) {
      console.error("Error importing CSV:", error);
      alert("Failed to import CSV");
    } finally {
      setLoading(false);
      // Reset file input
      event.target.value = null;
    }
  };

  const exportCsv = async () => {
    try {
      const response = await axios.post('http://localhost:8000/api/export', hosts, {
        responseType: 'blob'
      });

      const blob = new Blob([response.data], { type: 'text/csv' });
      const filename = `api_export_${new Date().toISOString().slice(0, 10)}.csv`;

      // Try using the File System Access API to show a Save As dialog
      if ('showSaveFilePicker' in window) {
        try {
          const handle = await window.showSaveFilePicker({
            suggestedName: filename,
            types: [{
              description: 'CSV File',
              accept: { 'text/csv': ['.csv'] },
            }],
          });
          const writable = await handle.createWritable();
          await writable.write(blob);
          await writable.close();
          return;
        } catch (err) {
          if (err.name === 'AbortError') {
            return; // User cancelled
          }
          console.warn("File System Access API failed, falling back to download", err);
        }
      }

      // Fallback for browsers that don't support showSaveFilePicker
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', filename);
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error("Error exporting CSV:", error);
      alert("Failed to export CSV");
    }
  };

  // Get unique hosts from current APIs for the settings modal
  const uniqueHosts = React.useMemo(() => {
    const hosts = new Set(apis.map(api => api.host));
    return Array.from(hosts);
  }, [apis]);

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900 flex font-sans text-slate-900 dark:text-slate-100 transition-colors duration-200">
      {/* Sidebar */}
      <div className="w-72 bg-slate-900 text-white flex flex-col shadow-xl border-r border-slate-800">
        <div className="p-6 border-b border-slate-800 flex justify-between items-center">
          <h1 className="text-xl font-bold flex items-center gap-3 tracking-wide">
            <div className="bg-indigo-500 p-2 rounded-lg">
              <LayoutDashboard className="h-6 w-6 text-white" />
            </div>
            <span>Axway<span className="text-indigo-400">Dash</span></span>
          </h1>
        </div>

        <nav className="flex-1 py-6 px-3 space-y-1">
          <button
            onClick={() => setActiveTab('dashboard')}
            className={`w-full flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-colors duration-200 ${activeTab === 'dashboard'
              ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-900/50'
              : 'text-slate-400 hover:bg-slate-800 hover:text-white'
              }`}
          >
            <LayoutDashboard className="h-5 w-5 mr-3" />
            Dashboard Overview
          </button>
          <button
            onClick={() => setActiveTab('config')}
            className={`w-full flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-colors duration-200 ${activeTab === 'config'
              ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-900/50'
              : 'text-slate-400 hover:bg-slate-800 hover:text-white'
              }`}
          >
            <Server className="h-5 w-5 mr-3" />
            Configuration
          </button>
        </nav>

        <div className="p-4 border-t border-slate-800 space-y-4">
          <button
            onClick={toggleTheme}
            className="w-full flex items-center justify-center gap-2 px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
          >
            {theme === 'light' ? <Moon className="h-4 w-4" /> : <Sun className="h-4 w-4" />}
            {theme === 'light' ? 'Dark Mode' : 'Light Mode'}
          </button>
          <div className="flex items-center gap-3 px-4 py-2">
            <div className="h-8 w-8 rounded-full bg-indigo-500 flex items-center justify-center text-sm font-bold">A</div>
            <div className="text-sm">
              <div className="font-medium">Admin User</div>
              <div className="text-slate-500 text-xs">admin@example.com</div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col h-screen overflow-hidden relative">
        {/* Top Header */}
        <header className="bg-white dark:bg-slate-800 border-b border-slate-200 dark:border-slate-700 h-16 flex items-center justify-between px-8 shadow-sm z-10 transition-colors duration-200">
          <h2 className="text-xl font-semibold text-slate-800 dark:text-white">
            {activeTab === 'dashboard' ? 'Dashboard Overview' : 'System Configuration'}
          </h2>
          <div className="flex items-center gap-4">
            <button
              onClick={() => setShowHostSettings(!showHostSettings)}
              className="text-slate-500 hover:text-indigo-600 dark:text-slate-400 dark:hover:text-indigo-400 transition-colors flex items-center gap-2 text-sm font-medium"
            >
              <Settings className="h-4 w-4" />
              Host Settings
            </button>
            <span className="text-sm text-slate-500 dark:text-slate-400">Last updated: {new Date().toLocaleTimeString()}</span>
          </div>
        </header>

        {/* Host Settings Modal */}
        {showHostSettings && (
          <div className="absolute top-16 right-8 w-96 bg-white dark:bg-slate-800 shadow-2xl rounded-xl border border-slate-200 dark:border-slate-700 z-50 p-6 animate-in fade-in slide-in-from-top-4 duration-200">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-medium text-slate-900 dark:text-white">Host Aliases</h3>
              <button onClick={() => setShowHostSettings(false)} className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200">
                &times;
              </button>
            </div>
            <p className="text-sm text-slate-500 dark:text-slate-400 mb-4">
              Assign friendly names to your hosts. These aliases will appear in charts and tables.
            </p>
            <div className="space-y-4 max-h-[60vh] overflow-y-auto pr-2">
              {uniqueHosts.length > 0 ? uniqueHosts.map(host => (
                <div key={host} className="space-y-1">
                  <label className="text-xs font-medium text-slate-500 dark:text-slate-400">{host}</label>
                  <input
                    type="text"
                    value={hostAliases[host] || ''}
                    onChange={(e) => updateHostAlias(host, e.target.value)}
                    placeholder="Enter alias..."
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-sm focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
                  />
                </div>
              )) : (
                <div className="text-center py-8 text-slate-400 text-sm">
                  No hosts detected yet. Load data first.
                </div>
              )}
            </div>
          </div>
        )}

        <main className="flex-1 overflow-y-auto p-8 bg-slate-50/50 dark:bg-slate-900/50">
          {activeTab === 'dashboard' ? (
            <div className="space-y-8 max-w-7xl mx-auto">
              <div className="flex justify-between items-center">
                <div>
                  <h3 className="text-lg font-medium text-slate-900 dark:text-white">Performance Metrics</h3>
                  <p className="text-sm text-slate-500 dark:text-slate-400">Real-time overview of your API ecosystem</p>
                </div>
                <div className="flex gap-3">
                  {apis.length === 0 && (
                    <button
                      onClick={loadDemoData}
                      className="bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 text-slate-700 dark:text-slate-200 px-4 py-2 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-700 shadow-sm transition-all flex items-center gap-2 font-medium"
                    >
                      <Server className="h-4 w-4 text-green-600" />
                      Load Demo Data
                    </button>
                  )}
                  <button
                    onClick={fetchApis}
                    disabled={loading}
                    className="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 shadow-md shadow-indigo-200 dark:shadow-none transition-all disabled:opacity-70 disabled:cursor-not-allowed flex items-center gap-2 font-medium"
                  >
                    <Activity className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
                    {loading ? 'Refreshing...' : 'Refresh Data'}
                  </button>
                  <button
                    onClick={exportCsv}
                    disabled={apis.length === 0}
                    className="bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 text-slate-700 dark:text-slate-200 px-4 py-2 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-700 shadow-sm transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2 font-medium"
                  >
                    Export CSV
                  </button>
                  <input
                    type="file"
                    ref={fileInputRef}
                    onChange={handleImport}
                    accept=".csv"
                    className="hidden"
                  />
                  <button
                    onClick={handleImportClick}
                    disabled={loading}
                    className="bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 text-slate-700 dark:text-slate-200 px-4 py-2 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-700 shadow-sm transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2 font-medium"
                  >
                    <Download className="h-4 w-4 rotate-180" />
                    Import CSV
                  </button>
                </div>
              </div>

              {/* Stats Grid */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {stats.map((stat, index) => (
                  <StatCard key={index} {...stat} />
                ))}
              </div>

              {/* Charts */}
              <AnalyticsChart apis={apis} />

              {/* API Table */}
              <div className="space-y-4">
                <div>
                  <h3 className="text-lg font-medium text-slate-900 dark:text-white">API Inventory</h3>
                  <p className="text-sm text-slate-500 dark:text-slate-400">Detailed list of all managed proxies</p>
                </div>
                {apis.length > 0 ? (
                  <ApiTable apis={apis} onUpdateComplexity={handleComplexityUpdate} />
                ) : (
                  <div className="bg-white dark:bg-slate-800 rounded-xl shadow-sm border border-slate-200 dark:border-slate-700 p-12 text-center transition-colors duration-200">
                    <div className="mx-auto h-16 w-16 bg-indigo-50 dark:bg-indigo-900/30 rounded-full flex items-center justify-center mb-4">
                      <Server className="h-8 w-8 text-indigo-500" />
                    </div>
                    <h3 className="text-lg font-medium text-slate-900 dark:text-white mb-2">No APIs Loaded</h3>
                    <p className="text-slate-500 dark:text-slate-400 mb-6 max-w-md mx-auto">
                      Configure a host connection or load demo data to visualize your API ecosystem.
                    </p>
                    <button
                      onClick={loadDemoData}
                      className="bg-indigo-600 text-white px-6 py-3 rounded-lg hover:bg-indigo-700 shadow-lg shadow-indigo-200 dark:shadow-none transition-all font-medium inline-flex items-center gap-2"
                    >
                      Load Demo Data
                    </button>
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div className="max-w-4xl mx-auto">
              <div className="bg-white dark:bg-slate-800 shadow-sm rounded-xl border border-slate-200 dark:border-slate-700 overflow-hidden transition-colors duration-200">
                <div className="px-6 py-5 border-b border-slate-200 dark:border-slate-700">
                  <h3 className="text-lg font-medium text-slate-900 dark:text-white">Gateway Configuration</h3>
                  <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">Manage your Axway API Gateway connections</p>
                </div>
                <div className="p-6 space-y-6">
                  {hosts.map((host, index) => (
                    <div key={index} className="bg-slate-50 dark:bg-slate-900/50 p-6 rounded-lg border border-slate-200 dark:border-slate-700 relative group transition-colors">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                          <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Host Name (Alias)</label>
                          <input
                            type="text"
                            value={host.name || ''}
                            onChange={(e) => updateHost(index, 'name', e.target.value)}
                            className="w-full rounded-lg border-slate-300 dark:border-slate-600 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                            placeholder="e.g., Production"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Host Address</label>
                          <input
                            type="text"
                            value={host.host}
                            onChange={(e) => updateHost(index, 'host', e.target.value)}
                            className="w-full rounded-lg border-slate-300 dark:border-slate-600 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                            placeholder="e.g., api.example.com"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Port</label>
                          <input
                            type="text"
                            value={host.port}
                            onChange={(e) => updateHost(index, 'port', e.target.value)}
                            className="w-full rounded-lg border-slate-300 dark:border-slate-600 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                            placeholder="8075"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Username</label>
                          <input
                            type="text"
                            value={host.username}
                            onChange={(e) => updateHost(index, 'username', e.target.value)}
                            className="w-full rounded-lg border-slate-300 dark:border-slate-600 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Password</label>
                          <input
                            type="password"
                            value={host.password}
                            onChange={(e) => updateHost(index, 'password', e.target.value)}
                            className="w-full rounded-lg border-slate-300 dark:border-slate-600 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                          />
                        </div>
                      </div>
                      {hosts.length > 1 && (
                        <button
                          onClick={() => removeHost(index)}
                          className="text-red-600 hover:text-red-800 dark:text-red-400 dark:hover:text-red-300 text-sm font-medium flex items-center gap-1 opacity-60 group-hover:opacity-100 transition-opacity"
                        >
                          <Trash2 className="h-4 w-4" />
                          Remove Connection
                        </button>
                      )}
                    </div>
                  ))}
                </div>
                <div className="px-6 pb-6">
                  <button
                    onClick={addHost}
                    className="w-full py-3 border-2 border-dashed border-slate-300 dark:border-slate-600 rounded-lg text-slate-500 dark:text-slate-400 hover:border-indigo-500 hover:text-indigo-500 dark:hover:border-indigo-400 dark:hover:text-indigo-400 transition-colors flex items-center justify-center gap-2 font-medium"
                  >
                    <Plus className="h-5 w-5" />
                    Add Another Host
                  </button>
                </div>
                <div className="bg-slate-50 dark:bg-slate-900 px-6 py-4 border-t border-slate-200 dark:border-slate-700 flex justify-between items-center">
                  <div className="flex gap-4">
                    <button
                      onClick={saveConfiguration}
                      className="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 shadow-sm transition-all flex items-center gap-2 font-medium"
                    >
                      <Save className="h-4 w-4" />
                      Save Configuration
                    </button>
                    <button
                      onClick={loadDemoData}
                      className="text-indigo-600 hover:text-indigo-800 dark:text-indigo-400 dark:hover:text-indigo-300 text-sm font-medium"
                    >
                      Load Demo Configuration
                    </button>
                  </div>
                  <p className="text-sm text-slate-500 dark:text-slate-400">
                    Use <span className="font-mono bg-slate-200 dark:bg-slate-700 px-1 rounded">mock-*</span> as hostname to load test data.
                  </p>
                </div>
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}

export default App;
