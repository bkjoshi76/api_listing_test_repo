import React, { useState } from 'react';
import { Search } from 'lucide-react';

const ApiTable = ({ apis, onUpdateComplexity }) => {
    const [searchTerm, setSearchTerm] = useState('');
    const [filters, setFilters] = useState({
        host: '',
        name: '',
        technical_complexity: 'All',
        business_complexity: 'All',
        inbound_security: '',
        outbound_security: '',
        notes: ''
    });

    const handleFilterChange = (column, value) => {
        setFilters(prev => ({
            ...prev,
            [column]: value
        }));
    };

    const filteredApis = apis.filter(api => {
        // Global search
        const matchesSearch =
            api.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
            api.path.toLowerCase().includes(searchTerm.toLowerCase()) ||
            api.host.toLowerCase().includes(searchTerm.toLowerCase());

        // Column filters
        const matchesHost = (api.host_alias || api.host).toLowerCase().includes(filters.host.toLowerCase());
        const matchesName = api.name.toLowerCase().includes(filters.name.toLowerCase());
        const matchesTech = filters.technical_complexity === 'All' || (api.technical_complexity || 'Medium') === filters.technical_complexity;
        const matchesBiz = filters.business_complexity === 'All' || (api.business_complexity || 'Medium') === filters.business_complexity;
        const matchesInbound = api.inbound_security.toLowerCase().includes(filters.inbound_security.toLowerCase());
        const matchesOutbound = api.outbound_security.toLowerCase().includes(filters.outbound_security.toLowerCase());
        const matchesNotes = (api.notes || '').toLowerCase().includes(filters.notes.toLowerCase());

        return matchesSearch && matchesHost && matchesName && matchesTech && matchesBiz && matchesInbound && matchesOutbound && matchesNotes;
    });

    return (
        <div className="bg-white dark:bg-slate-800 shadow-sm rounded-xl border border-slate-200 dark:border-slate-700 overflow-hidden transition-colors duration-200">
            <div className="px-6 py-5 border-b border-slate-200 dark:border-slate-700 flex justify-between items-center bg-white dark:bg-slate-800">
                <div className="relative rounded-md shadow-sm max-w-xs w-full">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Search className="h-4 w-4 text-slate-400" aria-hidden="true" />
                    </div>
                    <input
                        type="text"
                        className="focus:ring-indigo-500 focus:border-indigo-500 block w-full pl-10 sm:text-sm border-slate-300 dark:border-slate-600 rounded-lg p-2.5 bg-slate-50 dark:bg-slate-700 text-slate-900 dark:text-white placeholder-slate-400"
                        placeholder="Search APIs..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                    />
                </div>
            </div>
            <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
                    <thead className="bg-slate-50 dark:bg-slate-900/50">
                        <tr>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                                <div className="space-y-2">
                                    <span>Host</span>
                                    <input
                                        type="text"
                                        placeholder="Filter..."
                                        className="w-full text-xs p-1 rounded border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-1 focus:ring-indigo-500 outline-none"
                                        value={filters.host}
                                        onChange={(e) => handleFilterChange('host', e.target.value)}
                                    />
                                </div>
                            </th>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                                <div className="space-y-2">
                                    <span>Name</span>
                                    <input
                                        type="text"
                                        placeholder="Filter..."
                                        className="w-full text-xs p-1 rounded border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-1 focus:ring-indigo-500 outline-none"
                                        value={filters.name}
                                        onChange={(e) => handleFilterChange('name', e.target.value)}
                                    />
                                </div>
                            </th>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                                <div className="space-y-2">
                                    <span>Tech Complexity</span>
                                    <select
                                        className="w-full text-xs p-1 rounded border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-1 focus:ring-indigo-500 outline-none"
                                        value={filters.technical_complexity}
                                        onChange={(e) => handleFilterChange('technical_complexity', e.target.value)}
                                    >
                                        <option value="All">All</option>
                                        <option value="Low">Low</option>
                                        <option value="Medium">Medium</option>
                                        <option value="Low">Low</option>
                                        <option value="Medium">Medium</option>
                                        <option value="High">High</option>
                                    </select>
                                </div>
                            </th>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                                <div className="space-y-2">
                                    <span>Inbound Security</span>
                                    <input
                                        type="text"
                                        placeholder="Filter..."
                                        className="w-full text-xs p-1 rounded border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-1 focus:ring-indigo-500 outline-none"
                                        value={filters.inbound_security}
                                        onChange={(e) => handleFilterChange('inbound_security', e.target.value)}
                                    />
                                </div>
                            </th>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                                <div className="space-y-2">
                                    <span>Outbound Security</span>
                                    <input
                                        type="text"
                                        placeholder="Filter..."
                                        className="w-full text-xs p-1 rounded border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-1 focus:ring-indigo-500 outline-none"
                                        value={filters.outbound_security}
                                        onChange={(e) => handleFilterChange('outbound_security', e.target.value)}
                                    />
                                </div>
                            </th>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                                <div className="space-y-2">
                                    <span>Notes</span>
                                    <input
                                        type="text"
                                        placeholder="Filter..."
                                        className="w-full text-xs p-1 rounded border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-1 focus:ring-indigo-500 outline-none"
                                        value={filters.notes}
                                        onChange={(e) => handleFilterChange('notes', e.target.value)}
                                    />
                                </div>
                            </th>
                            <th scope="col" className="px-6 py-3 text-center text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                                <span>Ignore</span>
                            </th>
                        </tr>
                    </thead>
                    <tbody className="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
                        {filteredApis.map((api, index) => (
                            <tr key={index} className="hover:bg-slate-50 dark:hover:bg-slate-700/50 transition-colors">
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500 dark:text-slate-400 max-w-[200px] truncate" title={api.host}>{api.host_alias || api.host}</td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-slate-900 dark:text-white">{api.name}</td>

                                <td className="px-6 py-4 whitespace-nowrap">
                                    <select
                                        value={api.technical_complexity || 'Medium'}
                                        onChange={(e) => onUpdateComplexity && onUpdateComplexity(api, 'technical_complexity', e.target.value)}
                                        className={`text-xs font-medium rounded-full border px-2 py-0.5 outline-none cursor-pointer appearance-none pr-6 relative
                                            ${(api.technical_complexity || 'Medium') === 'Low' ? 'bg-green-50 text-green-700 border-green-200 dark:bg-green-900/30 dark:text-green-400 dark:border-green-800' :
                                                (api.technical_complexity || 'Medium') === 'Medium' ? 'bg-yellow-50 text-yellow-700 border-yellow-200 dark:bg-yellow-900/30 dark:text-yellow-400 dark:border-yellow-800' :
                                                    'bg-red-50 text-red-700 border-red-200 dark:bg-red-900/30 dark:text-red-400 dark:border-red-800'
                                            }`}
                                    >
                                        <option value="Low" className="bg-white dark:bg-slate-800 text-slate-900 dark:text-white">Low</option>
                                        <option value="Medium" className="bg-white dark:bg-slate-800 text-slate-900 dark:text-white">Medium</option>
                                        <option value="High" className="bg-white dark:bg-slate-800 text-slate-900 dark:text-white">High</option>
                                    </select>
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap">
                                    <select
                                        value={api.business_complexity || 'Medium'}
                                        onChange={(e) => onUpdateComplexity && onUpdateComplexity(api, 'business_complexity', e.target.value)}
                                        className={`text-xs font-medium rounded-full border px-2 py-0.5 outline-none cursor-pointer appearance-none pr-6 relative
                                            ${(api.business_complexity || 'Medium') === 'Low' ? 'bg-green-50 text-green-700 border-green-200 dark:bg-green-900/30 dark:text-green-400 dark:border-green-800' :
                                                (api.business_complexity || 'Medium') === 'Medium' ? 'bg-yellow-50 text-yellow-700 border-yellow-200 dark:bg-yellow-900/30 dark:text-yellow-400 dark:border-yellow-800' :
                                                    'bg-red-50 text-red-700 border-red-200 dark:bg-red-900/30 dark:text-red-400 dark:border-red-800'
                                            }`}
                                    >
                                        <option value="Low" className="bg-white dark:bg-slate-800 text-slate-900 dark:text-white">Low</option>
                                        <option value="Medium" className="bg-white dark:bg-slate-800 text-slate-900 dark:text-white">Medium</option>
                                        <option value="High" className="bg-white dark:bg-slate-800 text-slate-900 dark:text-white">High</option>
                                    </select>
                                </td>
                                <EditableSecurityCell
                                    api={api}
                                    field="inbound_security"
                                    value={api.inbound_security}
                                    onUpdate={onUpdateComplexity}
                                />
                                <EditableSecurityCell
                                    api={api}
                                    field="outbound_security"
                                    value={api.outbound_security}
                                    onUpdate={onUpdateComplexity}
                                />
                                <td className="px-6 py-4 whitespace-nowrap">
                                    <textarea
                                        value={api.notes || ''}
                                        onChange={(e) => onUpdateComplexity && onUpdateComplexity(api, 'notes', e.target.value)}
                                        placeholder="Add notes..."
                                        rows={1}
                                        className="text-xs w-full bg-transparent border-b border-transparent hover:border-slate-300 focus:border-indigo-500 focus:outline-none transition-colors text-slate-600 dark:text-slate-300 placeholder-slate-400 resize-y min-h-[24px]"
                                        onClick={(e) => e.target.rows = 3}
                                        onBlur={(e) => e.target.rows = 1}
                                    />
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap text-center">
                                    <input
                                        type="checkbox"
                                        checked={api.ignore || false}
                                        onChange={(e) => onUpdateComplexity && onUpdateComplexity(api, 'ignore', e.target.checked)}
                                        className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded cursor-pointer"
                                    />
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table >
                {
                    filteredApis.length === 0 && (
                        <div className="p-8 text-center text-slate-500 dark:text-slate-400">
                            <p>No APIs found matching your search.</p>
                        </div>
                    )
                }
            </div >
        </div >
    );
};

const EditableSecurityCell = ({ api, field, value, onUpdate }) => {
    const [isEditing, setIsEditing] = React.useState(false);
    const [editValue, setEditValue] = React.useState(value);

    React.useEffect(() => {
        setEditValue(value);
    }, [value]);

    const handleBlur = () => {
        setIsEditing(false);
        if (editValue !== value) {
            onUpdate(api, field, editValue);
        }
    };

    const handleKeyDown = (e) => {
        if (e.key === 'Enter') {
            handleBlur();
        }
        if (e.key === 'Escape') {
            setEditValue(value);
            setIsEditing(false);
        }
    };

    if (isEditing) {
        return (
            <td className="px-6 py-4 whitespace-nowrap">
                <input
                    type="text"
                    value={editValue}
                    onChange={(e) => setEditValue(e.target.value)}
                    onBlur={handleBlur}
                    onKeyDown={handleKeyDown}
                    autoFocus
                    className="w-full text-sm border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:border-indigo-500 focus:ring-indigo-500 dark:bg-slate-700 dark:text-white px-2 py-1"
                />
            </td>
        );
    }

    return (
        <td
            className="px-6 py-4 whitespace-nowrap text-sm text-slate-600 dark:text-slate-300 cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-700/50 transition-colors"
            onClick={() => setIsEditing(true)}
            title="Click to edit"
        >
            <div className="flex gap-1 flex-wrap">
                {value ? value.split(', ').map((sec, i) => (
                    <span key={i} className="bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 text-xs px-2 py-0.5 rounded border border-slate-200 dark:border-slate-600">{sec}</span>
                )) : <span className="text-slate-400 italic">None</span>}
            </div>
        </td>
    );
};

export default ApiTable;
