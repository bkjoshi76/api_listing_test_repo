import React from 'react';

const StatCard = ({ title, value, icon: Icon, color, trend }) => {
    return (
        <div className="bg-white dark:bg-slate-800 overflow-hidden shadow-sm rounded-xl border border-slate-200 dark:border-slate-700 hover:shadow-md transition-shadow duration-200">
            <div className="p-6">
                <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                        <div className={`p-3 rounded-lg bg-opacity-10 dark:bg-opacity-20 ${color.replace('text-', 'bg-')}`}>
                            <Icon className={`h-6 w-6 ${color} dark:text-opacity-90`} aria-hidden="true" />
                        </div>
                        <div>
                            <p className="text-sm font-medium text-slate-500 dark:text-slate-400 truncate">{title}</p>
                            <p className="text-2xl font-bold text-slate-900 dark:text-white mt-1">{value}</p>
                        </div>
                    </div>
                    {trend && (
                        <div className={`text-xs font-medium px-2 py-1 rounded-full ${trend.includes('+') ? 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400' : 'bg-slate-100 text-slate-600 dark:bg-slate-700 dark:text-slate-300'}`}>
                            {trend}
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default StatCard;
