import React, { useMemo } from 'react';
import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

const AnalyticsChart = ({ apis }) => {
    // Filter out ignored APIs
    const activeApis = useMemo(() => apis.filter(api => !api.ignore), [apis]);

    const hostData = useMemo(() => {
        const counts = activeApis.reduce((acc, api) => {
            const key = api.host_alias || api.host;
            acc[key] = (acc[key] || 0) + 1;
            return acc;
        }, {});

        const COLORS = ['#10b981', '#3b82f6', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#06b6d4'];

        return Object.entries(counts).map(([name, value], index) => ({
            name,
            value,
            color: COLORS[index % COLORS.length]
        }));
    }, [activeApis]);

    const technicalComplexityData = useMemo(() => {
        const data = [
            { name: 'Low', value: 0 },
            { name: 'Medium', value: 0 },
            { name: 'High', value: 0 }
        ];

        activeApis.forEach(api => {
            const tech = api.technical_complexity || 'Medium';
            const idx = data.findIndex(d => d.name === tech);
            if (idx > -1) data[idx].value++;
        });

        return data;
    }, [activeApis]);

    const businessCriticalityData = useMemo(() => {
        const data = [
            { name: 'Low', value: 0 },
            { name: 'Medium', value: 0 },
            { name: 'High', value: 0 }
        ];

        activeApis.forEach(api => {
            const biz = api.business_complexity || 'Medium';
            const idx = data.findIndex(d => d.name === biz);
            if (idx > -1) data[idx].value++;
        });

        return data;
    }, [activeApis]);

    const inboundSecurityData = useMemo(() => {
        const counts = {};
        activeApis.forEach(api => {
            const securities = api.inbound_security ? api.inbound_security.split(', ') : ['None'];
            securities.forEach(sec => {
                counts[sec] = (counts[sec] || 0) + 1;
            });
        });

        const COLORS = ['#10b981', '#3b82f6', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#06b6d4'];

        return Object.entries(counts)
            .map(([name, value], index) => ({
                name,
                value,
                color: COLORS[index % COLORS.length]
            }))
            .sort((a, b) => b.value - a.value);
    }, [activeApis]);

    const outboundSecurityData = useMemo(() => {
        const counts = {};
        activeApis.forEach(api => {
            const securities = api.outbound_security ? api.outbound_security.split(', ') : ['None'];
            securities.forEach(sec => {
                counts[sec] = (counts[sec] || 0) + 1;
            });
        });

        const COLORS = ['#10b981', '#3b82f6', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#06b6d4'];

        return Object.entries(counts)
            .map(([name, value], index) => ({
                name,
                value,
                color: COLORS[index % COLORS.length]
            }))
            .sort((a, b) => b.value - a.value);
    }, [activeApis]);

    if (apis.length === 0) return null;

    return (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
            {/* Host Distribution */}
            <div className="bg-white dark:bg-slate-800 shadow-sm rounded-xl border border-slate-200 dark:border-slate-700 p-6 transition-colors duration-200">
                <h3 className="text-lg leading-6 font-medium text-slate-900 dark:text-white mb-6">API Distribution By Host</h3>
                <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                            <Pie
                                data={hostData}
                                cx="50%"
                                cy="50%"
                                innerRadius={60}
                                outerRadius={80}
                                paddingAngle={5}
                                dataKey="value"
                            >
                                {hostData.map((entry, index) => (
                                    <Cell key={`cell-${index}`} fill={entry.color} />
                                ))}
                            </Pie>
                            <Tooltip
                                contentStyle={{
                                    backgroundColor: 'var(--tooltip-bg, #fff)',
                                    borderRadius: '8px',
                                    border: '1px solid var(--tooltip-border, #e2e8f0)',
                                    color: 'var(--tooltip-text, #1e293b)'
                                }}
                                itemStyle={{ color: 'var(--tooltip-text, #1e293b)' }}
                            />
                            <Legend />
                        </PieChart>
                    </ResponsiveContainer>
                </div>
            </div>

            {/* Technical Complexity */}
            <div className="bg-white dark:bg-slate-800 shadow-sm rounded-xl border border-slate-200 dark:border-slate-700 p-6 transition-colors duration-200">
                <h3 className="text-lg leading-6 font-medium text-slate-900 dark:text-white mb-6">Technical Complexity</h3>
                <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                        <BarChart
                            data={technicalComplexityData}
                            margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                        >
                            <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" className="dark:stroke-slate-700" vertical={false} />
                            <XAxis dataKey="name" stroke="#94a3b8" fontSize={12} tickLine={false} axisLine={false} />
                            <YAxis stroke="#94a3b8" fontSize={12} tickLine={false} axisLine={false} />
                            <Tooltip
                                cursor={{ fill: 'transparent' }}
                                contentStyle={{
                                    backgroundColor: 'var(--tooltip-bg, #fff)',
                                    borderRadius: '8px',
                                    border: '1px solid var(--tooltip-border, #e2e8f0)',
                                    color: 'var(--tooltip-text, #1e293b)'
                                }}
                                itemStyle={{ color: 'var(--tooltip-text, #1e293b)' }}
                            />
                            <Legend />
                            <Bar dataKey="value" name="APIs" fill="#6366f1" radius={[4, 4, 0, 0]} />
                        </BarChart>
                    </ResponsiveContainer>
                </div>
            </div>

            {/* Business Criticality */}
            <div className="bg-white dark:bg-slate-800 shadow-sm rounded-xl border border-slate-200 dark:border-slate-700 p-6 transition-colors duration-200">
                <h3 className="text-lg leading-6 font-medium text-slate-900 dark:text-white mb-6">Business Criticality</h3>
                <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                        <BarChart
                            data={businessCriticalityData}
                            margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                        >
                            <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" className="dark:stroke-slate-700" vertical={false} />
                            <XAxis dataKey="name" stroke="#94a3b8" fontSize={12} tickLine={false} axisLine={false} />
                            <YAxis stroke="#94a3b8" fontSize={12} tickLine={false} axisLine={false} />
                            <Tooltip
                                cursor={{ fill: 'transparent' }}
                                contentStyle={{
                                    backgroundColor: 'var(--tooltip-bg, #fff)',
                                    borderRadius: '8px',
                                    border: '1px solid var(--tooltip-border, #e2e8f0)',
                                    color: 'var(--tooltip-text, #1e293b)'
                                }}
                                itemStyle={{ color: 'var(--tooltip-text, #1e293b)' }}
                            />
                            <Legend />
                            <Bar dataKey="value" name="APIs" fill="#8b5cf6" radius={[4, 4, 0, 0]} />
                        </BarChart>
                    </ResponsiveContainer>
                </div>
            </div>

            {/* Inbound Security Distribution */}
            <div className="bg-white dark:bg-slate-800 shadow-sm rounded-xl border border-slate-200 dark:border-slate-700 p-6 transition-colors duration-200">
                <h3 className="text-lg leading-6 font-medium text-slate-900 dark:text-white mb-6">Inbound Security</h3>
                <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                            <Pie
                                data={inboundSecurityData}
                                cx="50%"
                                cy="50%"
                                innerRadius={60}
                                outerRadius={80}
                                paddingAngle={5}
                                dataKey="value"
                            >
                                {inboundSecurityData.map((entry, index) => (
                                    <Cell key={`cell-${index}`} fill={entry.color} />
                                ))}
                            </Pie>
                            <Tooltip
                                contentStyle={{
                                    backgroundColor: 'var(--tooltip-bg, #fff)',
                                    borderRadius: '8px',
                                    border: '1px solid var(--tooltip-border, #e2e8f0)',
                                    color: 'var(--tooltip-text, #1e293b)'
                                }}
                                itemStyle={{ color: 'var(--tooltip-text, #1e293b)' }}
                            />
                            <Legend />
                        </PieChart>
                    </ResponsiveContainer>
                </div>
            </div>

            {/* Outbound Security Distribution */}
            <div className="bg-white dark:bg-slate-800 shadow-sm rounded-xl border border-slate-200 dark:border-slate-700 p-6 transition-colors duration-200">
                <h3 className="text-lg leading-6 font-medium text-slate-900 dark:text-white mb-6">Outbound Security</h3>
                <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                            <Pie
                                data={outboundSecurityData}
                                cx="50%"
                                cy="50%"
                                innerRadius={60}
                                outerRadius={80}
                                paddingAngle={5}
                                dataKey="value"
                            >
                                {outboundSecurityData.map((entry, index) => (
                                    <Cell key={`cell-${index}`} fill={entry.color} />
                                ))}
                            </Pie>
                            <Tooltip
                                contentStyle={{
                                    backgroundColor: 'var(--tooltip-bg, #fff)',
                                    borderRadius: '8px',
                                    border: '1px solid var(--tooltip-border, #e2e8f0)',
                                    color: 'var(--tooltip-text, #1e293b)'
                                }}
                                itemStyle={{ color: 'var(--tooltip-text, #1e293b)' }}
                            />
                            <Legend />
                        </PieChart>
                    </ResponsiveContainer>
                </div>
            </div>

            <style>{`
        :root {
            --tooltip-bg: #fff;
            --tooltip-border: #e2e8f0;
            --tooltip-text: #1e293b;
        }
        .dark {
            --tooltip-bg: #1e293b;
            --tooltip-border: #334155;
            --tooltip-text: #f8fafc;
        }
      `}</style>
        </div>
    );
};

export default AnalyticsChart;
