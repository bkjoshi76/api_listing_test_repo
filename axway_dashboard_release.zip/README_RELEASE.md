# Axway API Dashboard Release

## Prerequisites
- Python 3.x
- Node.js (optional, only if you want to modify frontend)

## Setup

1.  **Backend Setup**:
    ```bash
    pip install -r requirements.txt
    ```

2.  **Frontend Setup**:
    The frontend is pre-built in `frontend/dist`.
    To serve it, you can use a static file server or integrate it with the FastAPI backend (not currently configured for static serving, so running separately is recommended for this version).

    *Alternative*: If you want to run the full dev environment:
    ```bash
    cd frontend
    npm install
    npm run dev
    ```

## Running

1.  **Start Backend**:
    ```bash
    cd backend
    uvicorn main:app --reload
    ```

2.  **Access Dashboard**:
    If running in dev mode: http://localhost:5173
    
    *Note*: This release package contains the source code. To deploy for production, you would typically serve the `frontend/dist` folder using Nginx or similar, proxying `/api` requests to the FastAPI backend.

## Troubleshooting

-   **"Load Demo Data" not working?**
    -   Ensure the **Backend** is running (`uvicorn main:app --reload`).
    -   The frontend needs to communicate with `http://localhost:8000`.
    -   Check the browser console (F12) for connection errors.

-   **"npm install" fails?**
    -   Make sure you are in the `frontend` directory.
    -   Ensure Node.js is installed.
