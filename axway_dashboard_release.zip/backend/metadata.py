import json
import os
from typing import Dict, Any

class MetadataStore:
    def __init__(self, file_path: str = "api_metadata.json"):
        self.file_path = file_path
        self.metadata = self._load_metadata()

    def _load_metadata(self) -> Dict[str, Any]:
        if not os.path.exists(self.file_path):
            return {}
        try:
            with open(self.file_path, 'r') as f:
                return json.load(f)
        except Exception as e:
            print(f"Error loading metadata: {e}")
            return {}

    def _save_metadata(self):
        try:
            with open(self.file_path, 'w') as f:
                json.dump(self.metadata, f, indent=2)
        except Exception as e:
            print(f"Error saving metadata: {e}")

    def get_metadata(self, api_id: str) -> Dict[str, Any]:
        return self.metadata.get(api_id, {})

    def update_metadata(self, api_id: str, data: Dict[str, Any]):
        if api_id not in self.metadata:
            self.metadata[api_id] = {}
        
        self.metadata[api_id].update(data)
        self._save_metadata()

    def get_all_metadata(self) -> Dict[str, Any]:
        return self.metadata

    def get_host_alias(self, host: str) -> str:
        aliases = self.metadata.get("_host_aliases", {})
        return aliases.get(host)

    def set_host_alias(self, host: str, alias: str):
        if "_host_aliases" not in self.metadata:
            self.metadata["_host_aliases"] = {}
        
        self.metadata["_host_aliases"][host] = alias
        self._save_metadata()

    def get_file_alias(self, filename: str) -> str:
        aliases = self.metadata.get("_file_aliases", {})
        return aliases.get(filename)

    def set_file_alias(self, filename: str, alias: str):
        if "_file_aliases" not in self.metadata:
            self.metadata["_file_aliases"] = {}
        
        self.metadata["_file_aliases"][filename] = alias
        self._save_metadata()
