from fastapi import FastAPI, HTTPException, Query, Response, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional, Union
import sys
import os
import random
import csv
import io
from datetime import datetime, timedelta

# Add parent directory to path to import get_axway_apis
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import get_axway_apis
from backend.metadata import MetadataStore

app = FastAPI(title="Axway API Dashboard")
metadata_store = MetadataStore()

# Enable CORS for frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, specify the frontend URL
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class HostConfig(BaseModel):
    host: str
    port: str = "8075"
    username: str
    password: str
    name: Optional[str] = None

class ApiProxy(BaseModel):
    host: str
    host_alias: str
    name: str
    path: str
    version: str
    state: str
    inbound_security: str
            version=row.get('Version', ''),
            state=row.get('State', 'Unknown'),
            inbound_security=row.get('Inbound Security') or 'None',
            outbound_security=row.get('Outbound Security') or 'None',
            technical_complexity=row.get('Technical Complexity', 'Medium'),
            business_complexity=row.get('Business Complexity', 'Medium'),
            notes=row.get('Notes', '')
        ))
        
    return imported_proxies

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
