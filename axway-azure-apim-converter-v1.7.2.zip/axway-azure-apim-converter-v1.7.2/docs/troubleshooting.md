# Troubleshooting Guide

## Strategic Axway to Azure APIM Converter - Common Issues & Solutions

This guide provides comprehensive troubleshooting information for resolving common issues encountered during Axway FilterCircuit to Azure APIM conversion.

### 🚨 Quick Diagnostics

#### **Run Quick Diagnostic Check**
```bash
# Test your environment
quick-strategic-test.bat

# Expected output should show:
# ✅ Python installation verified
# ✅ Strategic Matrix displayed
# ✅ Policy conversions successful
# ✅ Validations passed
```

#### **Check System Requirements**
```bash
# Verify Python version (requires 3.8+)
python --version

# Check required packages
pip list | findstr "PyYAML"
pip list | findstr "lxml"

# Test basic functionality
python -c "import yaml, json; print('✅ Core dependencies working')"
```

---

## 📋 Common Issues & Solutions

### **Issue 1: Python Command Not Found**

#### **Symptoms**
```
'python' is not recognized as an internal or external command
```

#### **Solutions**

**Option A: Install Python**
1. Download Python 3.8+ from https://python.org
2. During installation, check "Add Python to PATH"
3. Restart command prompt
4. Test: `python --version`

**Option B: Use Python Launcher (Windows)**
```bash
# Try py command instead of python
py --version
py src/strategic_filter_converter.py --matrix
```

**Option C: Fix PATH Environment Variable**
1. Find Python installation directory
2. Add to PATH: `C:\Users\YourName\AppData\Local\Programs\Python\Python311`
3. Add Scripts folder: `C:\Users\YourName\AppData\Local\Programs\Python\Python311\Scripts`

---

### **Issue 2: YAML Parsing Errors**

#### **Symptoms**
```
yaml.scanner.ScannerError: while scanning for the next token
found character '\t' that cannot start any token
```

#### **Causes**
- Mixed tabs and spaces in YAML files
- Invalid YAML syntax
- Unicode encoding issues

#### **Solutions**

**Fix Indentation Issues:**
```bash
# Check for mixed tabs/spaces
python -c "
import sys
with open('policy.yaml', 'rb') as f:
    content = f.read()
    if b'\t' in content:
        print('❌ Found tabs - YAML requires spaces only')
    else:
        print('✅ Indentation looks clean')
"
```

**Validate YAML Syntax:**
```bash
# Test YAML syntax
python -c "
import yaml
try:
    with open('policy.yaml', 'r') as f:
        yaml.safe_load(f)
    print('✅ YAML syntax is valid')
except yaml.YAMLError as e:
    print(f'❌ YAML error: {e}')
"
```

**Fix Encoding Issues:**
```bash
# Convert to UTF-8
python -c "
with open('policy.yaml', 'r', encoding='utf-8') as f:
    content = f.read()
with open('policy_fixed.yaml', 'w', encoding='utf-8') as f:
    f.write(content)
print('✅ File converted to UTF-8')
"
```

---

### **Issue 3: Filter Type Not Supported**

#### **Symptoms**
```
Filter 'CustomFilter' not supported - externalizing
Success rate: 50%
```

#### **Solutions**

**Check Supported Filters:**
```bash
# Display all supported filter types
python src/strategic_filter_converter.py --matrix
```

**Add Custom Filter Mapping:**
```python
# Edit src/filter_mappings.py to add support
'CustomFilter': {
    'apim_policy': 'custom-policy',
    'complexity': FilterComplexity.MODERATE,
    'section': PolicySection.INBOUND,
    'description': 'Custom filter implementation',
    'conversion_pattern': 'custom_policy'
}
```

**Implement Custom Conversion:**
```python
# Add to strategic_filter_converter.py
def _convert_custom_filter(self, config: Dict[str, Any]) -> Dict[str, Any]:
    return {
        'type': 'custom-policy',
        'policy': {
            'custom-policy': {
                'configuration': config
            }
        },
        'complexity': 'Moderate'
    }
```

---

### **Issue 4: Policy Validation Failures**

#### **Symptoms**
```
❌ Policy validation failed
Structure Issues: Missing required field: calls
Security Issues: Potential hardcoded secret detected
```

#### **Solutions**

**Fix Structure Issues:**
```bash
# Check what's missing
python src/validate_apim_policies.py policy.json --verbose

# Common fixes:
# 1. Add missing required attributes
# 2. Fix policy section placement
# 3. Ensure proper JSON structure
```

**Fix Security Issues:**
```bash
# Replace hardcoded values with variables
# BAD:  "password": "secret123"
# GOOD: "password": "{{api-password}}"

# Use variables for all sensitive data:
# - Passwords
# - API keys
# - Connection strings
# - Certificate data
```

**Validation Report Analysis:**
```bash
# Generate detailed report
python src/validate_apim_policies.py --directory policies/ --report validation.html

# Review report for:
# - Missing required fields
# - Security compliance issues
# - Enterprise policy violations
```

---

### **Issue 5: File Path and Permission Errors**

#### **Symptoms**
```
FileNotFoundError: [Errno 2] No such file or directory: 'policy.yaml'
PermissionError: [Errno 13] Permission denied
```

#### **Solutions**

**Check File Paths:**
```bash
# Use absolute paths
python src/strategic_filter_converter.py --convert "C:\full\path\to\policy.yaml"

# Or run from repository root
cd axway-azure-apim-converter
python src/strategic_filter_converter.py --convert examples/enterprise_policies/xml-threat-policy.yaml
```

**Fix Permission Issues:**
```bash
# Run as administrator (Windows)
# Or check file permissions

# Create output directory manually
mkdir output
mkdir policies\generated

# Ensure write permissions on output directories
```

**Working Directory Issues:**
```bash
# Check current directory
pwd  # Linux/Mac
cd   # Windows

# Ensure you're in the converter directory
dir  # Should see: src, examples, scripts, tests
```

---

### **Issue 6: Dependency Installation Problems**

#### **Symptoms**
```
ModuleNotFoundError: No module named 'yaml'
pip: command not found
```

#### **Solutions**

**Install Package Manager:**
```bash
# Download get-pip.py if pip is missing
python -m ensurepip --upgrade

# Or download from https://bootstrap.pypa.io/get-pip.py
python get-pip.py
```

**Install Dependencies:**
```bash
# Install specific packages
pip install PyYAML lxml --user

# Or install from requirements
pip install -r requirements.txt

# If behind corporate firewall
pip install --trusted-host pypi.org --trusted-host pypi.python.org PyYAML
```

**Virtual Environment Solution:**
```bash
# Create isolated environment
python -m venv converter_env

# Activate (Windows)
converter_env\Scripts\activate

# Activate (Linux/Mac)
source converter_env/bin/activate

# Install dependencies
pip install -r requirements.txt
```

---

### **Issue 7: Large File Processing Timeouts**

#### **Symptoms**
```
Conversion taking too long...
Memory usage high
Process hangs during batch conversion
```

#### **Solutions**

**Process Files in Smaller Batches:**
```bash
# Convert one file at a time
for file in policies/*.yaml; do
    python src/strategic_filter_converter.py --convert "$file"
done
```

**Optimize Memory Usage:**
```python
# Add to converter for large files
import gc

def convert_large_batch(self, files):
    for file in files:
        result = self.convert_file(file)
        gc.collect()  # Force garbage collection
        yield result
```

**Configure Timeouts:**
```python
# Add timeout to conversion process
import signal

def timeout_handler(signum, frame):
    raise TimeoutError("Conversion timeout")

signal.signal(signal.SIGALRM, timeout_handler)
signal.alarm(300)  # 5 minute timeout
```

---

### **Issue 8: Azure APIM Deployment Problems**

#### **Symptoms**
```
Azure APIM reports policy syntax error
Policy uploads but doesn't work as expected
CORS errors in browser
```

#### **Solutions**

**Validate Policy XML:**
```bash
# Ensure proper XML structure
python -c "
import xml.etree.ElementTree as ET
try:
    ET.parse('policy.xml')
    print('✅ XML structure valid')
except ET.ParseError as e:
    print(f'❌ XML error: {e}')
"
```

**Test Policy Locally:**
```bash
# Use Azure CLI to test deployment
az apim api policy create --service-name myapim --api-id myapi --policy-format rawxml --policy-file policy.xml

# Check Azure APIM logs for errors
az apim api policy show --service-name myapim --api-id myapi
```

**Common APIM Policy Issues:**
1. **Namespace Issues**: Ensure correct XML namespaces
2. **Policy Order**: Check inbound → backend → outbound → on-error order
3. **Variable References**: Verify all {{variables}} are defined
4. **Expression Syntax**: Check @() expressions are valid C#

---

### **Issue 9: Character Encoding Problems**

#### **Symptoms**
```
UnicodeDecodeError: 'utf-8' codec can't decode byte
Strange characters in output
Policy contains garbled text
```

#### **Solutions**

**Detect File Encoding:**
```bash
# Install chardet for encoding detection
pip install chardet

# Check file encoding
python -c "
import chardet
with open('policy.yaml', 'rb') as f:
    result = chardet.detect(f.read())
    print(f'Encoding: {result[\"encoding\"]} (confidence: {result[\"confidence\"]})')
"
```

**Convert Encoding:**
```python
# Convert to UTF-8
with open('input.yaml', 'r', encoding='latin1') as infile:
    content = infile.read()

with open('output.yaml', 'w', encoding='utf-8') as outfile:
    outfile.write(content)
```

**Force Encoding:**
```bash
# Specify encoding in converter
python src/strategic_filter_converter.py --convert policy.yaml --encoding iso-8859-1
```

---

### **Issue 10: Complex Filter Chain Conversion**

#### **Symptoms**
```
Filter chain dependencies not preserved
Policy order incorrect
Missing filter interactions
```

#### **Solutions**

**Analyze Filter Dependencies:**
```bash
# Generate dependency analysis
python src/strategic_filter_converter.py --assess policies/ --dependencies

# Review filter execution order
python src/filter_mappings.py --analyze-chains policy.yaml
```

**Manual Policy Ordering:**
```json
{
  "inbound_policies": [
    {"type": "authentication-basic", "order": 1},
    {"type": "rate-limit", "order": 2}, 
    {"type": "xml-threat-detection", "order": 3}
  ],
  "backend_policies": [
    {"type": "set-backend-service", "order": 1}
  ]
}
```

**Split Complex Chains:**
```yaml
# Break down complex filter chains into logical groups
authentication_chain:
  - HTTPBasicFilter
  - JWTFilter

security_chain:
  - XMLThreatProtectionFilter
  - IPWhitelistFilter

routing_chain:
  - LoadBalancingFilter
  - ConnectToURLFilter
```

---

## 🔧 Advanced Troubleshooting

### **Enable Debug Logging**
```bash
# Set environment variable for detailed logs
set CONVERTER_LOG_LEVEL=DEBUG

# Or use verbose flag
python src/strategic_filter_converter.py --convert policy.yaml --verbose

# Enable file logging
python src/strategic_filter_converter.py --convert policy.yaml --log-file debug.log
```

### **Memory and Performance Profiling**
```python
# Add memory profiling
from memory_profiler import profile

@profile
def convert_policy(self, policy_data):
    # Conversion logic here
    pass

# Run with profiling
python -m memory_profiler src/strategic_filter_converter.py
```

### **Custom Validation Rules**
```python
# Add custom validation in validate_apim_policies.py
def validate_enterprise_custom_rules(self, policy_data):
    issues = []
    
    # Custom validation logic
    if self._check_custom_requirement(policy_data):
        issues.append("Custom requirement not met")
    
    return issues
```

---

## 📞 Getting Help

### **Self-Service Diagnostics**
1. Run `quick-strategic-test.bat` for immediate validation
2. Check `output/validation_report.txt` for detailed issues
3. Review logs in debug mode for specific errors
4. Compare your policy with working examples in `/examples`

### **Community Support**
- 🐛 **GitHub Issues**: Report bugs and feature requests
- 💬 **Discussions**: Community Q&A and best practices
- 📖 **Documentation**: Comprehensive guides in `/docs`

### **Enterprise Support**
- 📧 **Technical Support**: Contact your Azure representative
- 🎓 **Training**: Azure APIM migration workshops
- 🏢 **Professional Services**: Migration consulting available

### **Useful Commands Summary**
```bash
# Quick environment check
python --version && pip list | grep -E "(yaml|lxml)"

# Test basic functionality
python src/strategic_filter_converter.py --matrix

# Validate single policy
python src/validate_apim_policies.py policy.json

# Full diagnostic test
quick-strategic-test.bat

# Generate comprehensive test policies
generate-yaml-policies.bat

# Run complete test suite
strategic-test-enterprise.bat
```

---

**Remember**: Most issues are resolved by ensuring proper Python installation, correct file paths, and valid YAML syntax. When in doubt, start with `quick-strategic-test.bat` to verify your environment!
