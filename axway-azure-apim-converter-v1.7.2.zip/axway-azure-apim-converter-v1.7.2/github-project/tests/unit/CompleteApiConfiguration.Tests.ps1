# Enhanced Unit Tests for Complete API Configuration Migration
# Tests for enhanced AxwayToApimConverterEnhanced module

#Requires -Modules @{ ModuleName="Pester"; ModuleVersion="5.0.0" }

BeforeAll {
    # Import the enhanced module
    $modulePath = "$PSScriptRoot/../../scripts/modules/AxwayToApimConverterEnhanced.psm1"
    if (Test-Path $modulePath) {
        Import-Module $modulePath -Force
    }
    else {
        throw "Enhanced module not found: $modulePath"
    }
    
    # Test data directory
    $testDataPath = "$PSScriptRoot/test-data"
    if (-not (Test-Path $testDataPath)) {
        New-Item -Path $testDataPath -ItemType Directory -Force | Out-Null
    }
}

Describe "Enhanced AxwayToApimConverter Module Tests" {
    
    Context "Convert-AxwayApiConfiguration" {
        BeforeAll {
            # Create sample complete API configuration
            $sampleCompleteConfig = @{
                name = "Test Complete API"
                path = "/api/v1/complete"
                version = "1.0.0"
                organization = "Test Organization"
                backendBasepath = "https://backend.test.com/v1"
                securityProfiles = @(
                    @{
                        name = "_default"
                        isDefault = $true
                        devices = @(
                            @{
                                name = "API Key"
                                type = "apiKey"
                                properties = @{
                                    apiKeyFieldName = "X-API-Key"
                                    takeFrom = "HEADER"
                                }
                            }
                        )
                    }
                )
                outboundProfiles = @{
                    _default = @{
                        authenticationProfile = "backend_oauth"
                    }
                }
                authenticationProfiles = @(
                    @{
                        name = "backend_oauth"
                        type = "oauth"
                        parameters = @{
                            tokenEndpoint = "https://auth.test.com/oauth/token"
                            clientId = "test-client"
                            clientSecret = "test-secret"
                            scope = "api.access"
                        }
                    }
                )
                corsProfiles = @(
                    @{
                        name = "test_cors"
                        origins = @("https://app.test.com")
                        allowedHeaders = @("Authorization", "Content-Type")
                        supportCredentials = $true
                    }
                )
                customProperties = @{
                    environment = "test"
                    owner = "test-team"
                }
                applicationQuota = @{
                    restrictions = @(
                        @{
                            method = "GET"
                            type = "throttle"
                            config = @{
                                period = "minute"
                                per = 1
                                messages = 100
                            }
                        }
                    )
                }
            }
            
            $configFile = "$testDataPath/complete-test-config.json"
            $sampleCompleteConfig | ConvertTo-Json -Depth 10 | Out-File $configFile -Encoding UTF8
        }
        
        It "Should convert complete API configuration successfully" {
            $result = Convert-AxwayApiConfiguration -AxwayConfig $configFile -OutputPath $testDataPath
            
            $result | Should -Not -BeNullOrEmpty
            $result.Success | Should -Be $true
            $result.ArtifactsGenerated | Should -BeGreaterThan 0
        }
        
        It "Should generate all required artifacts" {
            $result = Convert-AxwayApiConfiguration -AxwayConfig $configFile -OutputPath $testDataPath
            
            $result.Report.GeneratedArtifacts.Keys | Should -Contain "apiDefinition"
            $result.Report.GeneratedArtifacts.Keys | Should -Contain "inboundPolicies" 
            $result.Report.GeneratedArtifacts.Keys | Should -Contain "outboundPolicies"
            $result.Report.GeneratedArtifacts.Keys | Should -Contain "corsConfiguration"
            $result.Report.GeneratedArtifacts.Keys | Should -Contain "customProperties"
            $result.Report.GeneratedArtifacts.Keys | Should -Contain "quotaConfiguration"
        }
        
        It "Should handle infrastructure generation when requested" {
            $result = Convert-AxwayApiConfiguration -AxwayConfig $configFile -OutputPath $testDataPath -IncludeInfrastructure
            
            $result.Report.GeneratedArtifacts.Keys | Should -Contain "infrastructure"
        }
        
        It "Should validate required fields in API configuration" {
            $invalidConfig = @{
                name = "Invalid API"
                # Missing required fields: path, version, organization
            }
            
            $invalidConfigFile = "$testDataPath/invalid-config.json"
            $invalidConfig | ConvertTo-Json | Out-File $invalidConfigFile -Encoding UTF8
            
            { Convert-AxwayApiConfiguration -AxwayConfig $invalidConfigFile -OutputPath $testDataPath } | Should -Throw
        }
    }
    
    Context "Convert-AxwayOutboundAuthentication" {
        BeforeAll {
            $testOutboundProfiles = @{
                _default = @{
                    authenticationProfile = "oauth_profile"
                }
                readOperations = @{
                    authenticationProfile = "apikey_profile"  
                }
                writeOperations = @{
                    authenticationProfile = "ssl_profile"
                }
            }
        }
        
        It "Should convert outbound authentication profiles" {
            $result = Convert-AxwayOutboundAuthentication -OutboundProfiles $testOutboundProfiles
            
            $result | Should -Not -BeNullOrEmpty
            $result.Keys | Should -Contain "_default"
            $result.Keys | Should -Contain "readOperations" 
            $result.Keys | Should -Contain "writeOperations"
        }
        
        It "Should include retry policies when requested" {
            $result = Convert-AxwayOutboundAuthentication -OutboundProfiles $testOutboundProfiles -IncludeRetry
            
            foreach ($policy in $result.Values) {
                $policy | Should -Match "retry"
            }
        }
        
        It "Should handle empty outbound profiles gracefully" {
            $emptyProfiles = @{}
            
            $result = Convert-AxwayOutboundAuthentication -OutboundProfiles $emptyProfiles
            
            $result | Should -Not -BeNullOrEmpty
            $result.Count | Should -Be 0
        }
    }
    
    Context "Get-AxwayApiConfiguration" {
        BeforeAll {
            $validConfig = @{
                name = "Valid API"
                path = "/api/v1/valid"
                version = "1.0.0"
                organization = "Valid Organization"
            }
            
            $validConfigFile = "$testDataPath/valid-config.json"
            $validConfig | ConvertTo-Json | Out-File $validConfigFile -Encoding UTF8
        }
        
        It "Should parse JSON file successfully" {
            $result = Get-AxwayApiConfiguration -Config $validConfigFile
            
            $result | Should -Not -BeNullOrEmpty
            $result.name | Should -Be "Valid API"
            $result.path | Should -Be "/api/v1/valid"
        }
        
        It "Should parse JSON string successfully" {
            $jsonString = $validConfig | ConvertTo-Json
            $result = Get-AxwayApiConfiguration -Config $jsonString
            
            $result | Should -Not -BeNullOrEmpty
            $result.name | Should -Be "Valid API"
        }
        
        It "Should parse PowerShell object successfully" {
            $result = Get-AxwayApiConfiguration -Config $validConfig
            
            $result | Should -Not -BeNullOrEmpty
            $result.name | Should -Be "Valid API"
        }
        
        It "Should set default values for optional fields" {
            $minimalConfig = @{
                name = "Minimal API"
                path = "/api/minimal"
                version = "1.0.0"
                organization = "Test Org"
            }
            
            $result = Get-AxwayApiConfiguration -Config $minimalConfig
            
            $result.state | Should -Be "unpublished"
            $result.backendBasepath | Should -Be ""
            $result.descriptionType | Should -Be "original"
        }
        
        It "Should throw error for invalid configuration" {
            { Get-AxwayApiConfiguration -Config "invalid-json" } | Should -Throw
        }
        
        It "Should throw error for missing required fields" {
            $invalidConfig = @{
                name = "Invalid API"
                # Missing required fields
            }
            
            { Get-AxwayApiConfiguration -Config $invalidConfig } | Should -Throw
        }
    }
    
    Context "Outbound Authentication Policy Generation" {
        
        Context "New-OutboundApiKeyPolicy" {
            It "Should generate valid API key outbound policy" {
                $profile = @{
                    parameters = @{
                        apiKeyName = "X-Backend-API-Key"
                        apiKeyValue = "test-api-key"
                        takeFrom = "HEADER"
                    }
                }
                
                $result = New-OutboundApiKeyPolicy -Profile $profile
                
                $result | Should -Match "X-Backend-API-Key"
                $result | Should -Match "test-api-key"
                $result | Should -Match "set-header"
            }
            
            It "Should support query parameter placement" {
                $profile = @{
                    parameters = @{
                        apiKeyName = "api_key"
                        apiKeyValue = "query-key"
                        takeFrom = "QUERY"
                    }
                }
                
                $result = New-OutboundApiKeyPolicy -Profile $profile
                
                $result | Should -Match "set-query-parameter"
                $result | Should -Match "api_key"
            }
            
            It "Should include retry policy when requested" {
                $profile = @{
                    parameters = @{
                        apiKeyName = "X-API-Key"
                        apiKeyValue = "test-key"
                    }
                }
                
                $result = New-OutboundApiKeyPolicy -Profile $profile -IncludeRetry
                
                $result | Should -Match "retry"
            }
        }
        
        Context "New-OutboundOAuthPolicy" {
            It "Should generate valid OAuth outbound policy" {
                $profile = @{
                    parameters = @{
                        tokenEndpoint = "https://auth.test.com/oauth/token"
                        clientId = "test-client"
                        clientSecret = "test-secret"
                        scope = "api.access"
                    }
                }
                
                $result = New-OutboundOAuthPolicy -Profile $profile
                
                $result | Should -Match "send-request"
                $result | Should -Match "oauth/token"
                $result | Should -Match "client_credentials"
                $result | Should -Match "Bearer"
            }
            
            It "Should handle OAuth token extraction" {
                $profile = @{
                    parameters = @{
                        tokenEndpoint = "https://auth.test.com/oauth/token"
                        clientId = "client-id"
                        clientSecret = "client-secret"
                    }
                }
                
                $result = New-OutboundOAuthPolicy -Profile $profile
                
                $result | Should -Match "backendAccessToken"
                $result | Should -Match "access_token"
                $result | Should -Match "Authorization.*Bearer"
            }
        }
        
        Context "New-OutboundBasicAuthPolicy" {
            It "Should generate valid basic auth outbound policy" {
                $profile = @{
                    parameters = @{
                        username = "backend-user"
                        password = "backend-pass"
                    }
                }
                
                $result = New-OutboundBasicAuthPolicy -Profile $profile
                
                $result | Should -Match "Authorization"
                $result | Should -Match "Basic"
                $result | Should -Match "Convert.ToBase64String"
            }
        }
        
        Context "New-OutboundSSLPolicy" {
            It "Should generate valid SSL certificate outbound policy" {
                $profile = @{
                    parameters = @{
                        certFile = "client-cert.p12"
                        password = "cert-password"
                        trustAll = $false
                    }
                }
                
                $result = New-OutboundSSLPolicy -Profile $profile
                
                $result | Should -Match "SSL.*certificate"
                $result | Should -Match "trace"
            }
        }
        
        Context "Get-OutboundAuthenticationType" {
            It "Should detect API key authentication" {
                $profile = @{
                    parameters = @{
                        apiKeyName = "X-API-Key"
                        apiKeyValue = "test-key"
                    }
                }
                
                $result = Get-OutboundAuthenticationType -Profile $profile
                $result | Should -Be "apikey"
            }
            
            It "Should detect OAuth authentication" {
                $profile = @{
                    parameters = @{
                        tokenEndpoint = "https://auth.test.com/token"
                        clientId = "client-id"
                    }
                }
                
                $result = Get-OutboundAuthenticationType -Profile $profile
                $result | Should -Be "oauth"
            }
            
            It "Should detect basic authentication" {
                $profile = @{
                    parameters = @{
                        username = "user"
                        password = "pass"
                    }
                }
                
                $result = Get-OutboundAuthenticationType -Profile $profile
                $result | Should -Be "basic"
            }
            
            It "Should detect SSL authentication" {
                $profile = @{
                    parameters = @{
                        certFile = "client.p12"
                    }
                }
                
                $result = Get-OutboundAuthenticationType -Profile $profile
                $result | Should -Be "ssl"
            }
            
            It "Should use explicit type when provided" {
                $profile = @{
                    type = "custom"
                    parameters = @{}
                }
                
                $result = Get-OutboundAuthenticationType -Profile $profile
                $result | Should -Be "custom"
            }
            
            It "Should default to 'default' for unknown configurations" {
                $profile = @{
                    parameters = @{}
                }
                
                $result = Get-OutboundAuthenticationType -Profile $profile
                $result | Should -Be "default"
            }
        }
    }
    
    Context "Additional Conversion Functions" {
        
        Context "Convert-AxwayCorsProfile" {
            It "Should convert CORS profiles correctly" {
                $corsProfiles = @(
                    @{
                        name = "test_cors"
                        origins = @("https://app.test.com", "https://admin.test.com")
                        allowedHeaders = @("Authorization", "Content-Type")
                        exposedHeaders = @("X-Request-ID")
                        supportCredentials = $true
                        maxAgeSeconds = 3600
                    }
                )
                
                $result = Convert-AxwayCorsProfile -CorsProfiles $corsProfiles
                
                $result | Should -Not -BeNullOrEmpty
                $result.Keys | Should -Contain "test_cors"
                $result["test_cors"] | Should -Match "cors"
                $result["test_cors"] | Should -Match "app.test.com"
                $result["test_cors"] | Should -Match "preflight-result-max-age.*3600"
            }
        }
        
        Context "Convert-AxwayCustomProperties" {
            It "Should convert custom properties to Named Values" {
                $customProperties = @{
                    property1 = "value1"
                    property2 = "value2"
                    property3 = "123"
                }
                
                $result = Convert-AxwayCustomProperties -CustomProperties $customProperties
                
                $result | Should -Not -BeNullOrEmpty
                $result.Keys | Should -Contain "property1"
                $result.Keys | Should -Contain "property2"
                $result.Keys | Should -Contain "property3"
                
                $result["property1"].DisplayName | Should -Be "property1"
                $result["property1"].Value | Should -Be "value1"
                $result["property1"].Secret | Should -Be $false
            }
        }
        
        Context "Convert-AxwayQuotaSettings" {
            It "Should convert application quota settings" {
                $apiConfig = @{
                    applicationQuota = @{
                        restrictions = @(
                            @{
                                method = "GET"
                                type = "throttle"
                                config = @{
                                    period = "minute"
                                    per = 1
                                    messages = 100
                                }
                            }
                        )
                    }
                }
                
                $result = Convert-AxwayQuotaSettings -ApiConfig $apiConfig
                
                $result | Should -Not -BeNullOrEmpty
                $result.Keys | Should -Contain "applicationQuota"
                $result["applicationQuota"] | Should -Match "rate-limit-by-key"
                $result["applicationQuota"] | Should -Match "calls.*100"
            }
            
            It "Should convert system quota settings" {
                $apiConfig = @{
                    systemQuota = @{
                        restrictions = @(
                            @{
                                method = "*"
                                type = "throttle" 
                                config = @{
                                    period = "hour"
                                    per = 1
                                    messages = 10000
                                }
                            }
                        )
                    }
                }
                
                $result = Convert-AxwayQuotaSettings -ApiConfig $apiConfig
                
                $result | Should -Not -BeNullOrEmpty
                $result.Keys | Should -Contain "systemQuota"
                $result["systemQuota"] | Should -Match "rate-limit-by-key"
                $result["systemQuota"] | Should -Match "calls.*10000"
            }
        }
        
        Context "Convert-AxwayCertificates" {
            It "Should convert certificate configurations" {
                $certificates = @(
                    @{
                        certFile = "ca-cert.crt"
                        inbound = $false
                        outbound = $true
                    }
                    @{
                        certFile = "client-cert.p12"
                        inbound = $true
                        outbound = $false
                    }
                )
                
                $result = Convert-AxwayCertificates -Certificates $certificates
                
                $result | Should -Not -BeNullOrEmpty
                $result.OutboundCertificates.Count | Should -Be 1
                $result.InboundCertificates.Count | Should -Be 1
                $result.Instructions.Count | Should -Be 2
            }
        }
    }
    
    Context "Policy Generation and Validation" {
        
        Context "New-CombinedApimPolicy" {
            It "Should generate valid combined APIM policy" {
                $artifacts = @{
                    inboundPolicies = @{
                        "security" = "<inbound><check-header name=""X-API-Key"" /></inbound>"
                    }
                    outboundPolicies = @{
                        "backend" = "<!-- Backend OAuth -->"
                    }
                    corsConfiguration = @{
                        "cors" = "<cors />"
                    }
                }
                
                $result = New-CombinedApimPolicy -ConversionArtifacts $artifacts
                
                $result | Should -Match "<policies>"
                $result | Should -Match "<inbound>"
                $result | Should -Match "<backend>"
                $result | Should -Match "<outbound>"
                $result | Should -Match "<on-error>"
                $result | Should -Match "check-header"
                $result | Should -Match "Backend OAuth"
            }
        }
        
        Context "Policy XML Validation" {
            It "Should generate valid XML for API key policy" {
                $profile = @{
                    parameters = @{
                        apiKeyName = "X-API-Key"
                        apiKeyValue = "test-key"
                    }
                }
                
                $result = New-OutboundApiKeyPolicy -Profile $profile
                
                # Basic XML structure validation
                $result | Should -Match "<.*>"
                $result | Should -Match "set-header"
            }
            
            It "Should generate valid XML for OAuth policy" {
                $profile = @{
                    parameters = @{
                        tokenEndpoint = "https://auth.test.com/token"
                        clientId = "client"
                        clientSecret = "secret"
                    }
                }
                
                $result = New-OutboundOAuthPolicy -Profile $profile
                
                # Basic XML structure validation
                $result | Should -Match "<.*>"
                $result | Should -Match "send-request"
            }
        }
    }
    
    Context "Error Handling and Edge Cases" {
        
        It "Should handle null or empty configurations gracefully" {
            $emptyConfig = @{}
            
            { Get-AxwayApiConfiguration -Config $emptyConfig } | Should -Throw
        }
        
        It "Should handle missing authentication profiles" {
            $profile = @{
                authenticationProfile = "non_existent_profile"
            }
            
            $result = Get-OutboundAuthenticationType -Profile $profile
            $result | Should -Be "default"
        }
        
        It "Should handle malformed JSON input" {
            $malformedJson = '{"name": "Test", "invalid": }'
            
            { Get-AxwayApiConfiguration -Config $malformedJson } | Should -Throw
        }
        
        It "Should validate file path existence" {
            $nonExistentFile = "$testDataPath/non-existent-config.json"
            
            { Get-AxwayApiConfiguration -Config $nonExistentFile } | Should -Throw
        }
    }
    
    Context "Integration Tests" {
        
        It "Should perform end-to-end conversion without errors" {
            $completeConfig = @{
                name = "Integration Test API"
                path = "/api/integration"
                version = "1.0.0"
                organization = "Test Organization"
                backendBasepath = "https://backend.integration.com"
                securityProfiles = @(
                    @{
                        name = "_default"
                        isDefault = $true
                        devices = @(
                            @{
                                name = "API Key"
                                type = "apiKey"
                                properties = @{
                                    apiKeyFieldName = "X-API-Key"
                                    takeFrom = "HEADER"
                                }
                            }
                        )
                    }
                )
                outboundProfiles = @{
                    _default = @{
                        authenticationProfile = "backend_oauth"
                    }
                }
                authenticationProfiles = @(
                    @{
                        name = "backend_oauth"
                        type = "oauth"
                        parameters = @{
                            tokenEndpoint = "https://auth.integration.com/token"
                            clientId = "integration-client"
                            clientSecret = "integration-secret"
                        }
                    }
                )
                corsProfiles = @(
                    @{
                        name = "integration_cors"
                        origins = @("https://app.integration.com")
                        allowedHeaders = @("Authorization", "Content-Type")
                    }
                )
                customProperties = @{
                    testProperty = "testValue"
                }
            }
            
            $configFile = "$testDataPath/integration-config.json"
            $completeConfig | ConvertTo-Json -Depth 10 | Out-File $configFile -Encoding UTF8
            
            $result = Convert-AxwayApiConfiguration -AxwayConfig $configFile -OutputPath $testDataPath
            
            $result.Success | Should -Be $true
            $result.ArtifactsGenerated | Should -BeGreaterThan 4
            
            # Verify output files exist
            Test-Path "$testDataPath/apim-policy.xml" | Should -Be $true
            Test-Path "$testDataPath/api-definition.json" | Should -Be $true
            Test-Path "$testDataPath/named-values.json" | Should -Be $true
            Test-Path "$testDataPath/conversion-report.json" | Should -Be $true
        }
    }
}

AfterAll {
    # Cleanup test data
    if (Test-Path "$PSScriptRoot/test-data") {
        Remove-Item "$PSScriptRoot/test-data" -Recurse -Force -ErrorAction SilentlyContinue
    }
}
