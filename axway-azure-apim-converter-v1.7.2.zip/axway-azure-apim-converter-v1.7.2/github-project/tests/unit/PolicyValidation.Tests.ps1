using module "./../../scripts/modules/AxwayToApimConverter.psm1"

Describe "AxwayToApimConverter Unit Tests" {
    BeforeAll {
        # Import the module
        Import-Module "$PSScriptRoot/../../scripts/modules/AxwayToApimConverter.psm1" -Force
        
        # Sample Axway configurations for testing
        $script:sampleApiKeyConfig = @{
            securityProfiles = @(
                @{
                    name = "_default"
                    isDefault = $true
                    devices = @(
                        @{
                            name = "API Key"
                            type = "apiKey"
                            order = 0
                            properties = @{
                                apiKeyFieldName = "X-API-Key"
                                takeFrom = "HEADER"
                                removeCredentialsOnSuccess = "true"
                            }
                        }
                    )
                }
            )
        }
        
        $script:sampleOAuthConfig = @{
            securityProfiles = @(
                @{
                    name = "_default"
                    isDefault = $true
                    devices = @(
                        @{
                            name = "OAuth"
                            type = "oauth"
                            order = 1
                            properties = @{
                                tokenStore = "OAuth Access Token Store"
                                accessTokenLocation = "HEADER"
                                authorizationHeaderPrefix = "Bearer"
                                scopes = "resource.READ, resource.WRITE"
                                scopesMustMatch = "Any"
                                removeCredentialsOnSuccess = $true
                            }
                        }
                    )
                }
            )
        }
        
        $script:sampleBasicAuthConfig = @{
            securityProfiles = @(
                @{
                    name = "_default"
                    isDefault = $true
                    devices = @(
                        @{
                            name = "HTTP Basic"
                            type = "httpBasic"
                            order = 0
                            properties = @{
                                realm = "API Access"
                                removeCredentialsOnSuccess = $true
                            }
                        }
                    )
                }
            )
        }
    }
    
    Context "Get-AxwaySecurityProfile" {
        It "Should parse valid Axway API Key configuration" {
            $result = Get-AxwaySecurityProfile -Config $sampleApiKeyConfig
            
            $result | Should -Not -BeNullOrEmpty
            $result.Type | Should -Be "apiKey"
            $result.Name | Should -Be "API Key"
            $result.Properties.apiKeyFieldName | Should -Be "X-API-Key"
        }
        
        It "Should parse valid Axway OAuth configuration" {
            $result = Get-AxwaySecurityProfile -Config $sampleOAuthConfig
            
            $result | Should -Not -BeNullOrEmpty
            $result.Type | Should -Be "oauth"
            $result.Properties.accessTokenLocation | Should -Be "HEADER"
            $result.Properties.scopes | Should -Be "resource.READ, resource.WRITE"
        }
        
        It "Should throw error for invalid configuration" {
            { Get-AxwaySecurityProfile -Config @{} } | Should -Throw
        }
        
        It "Should handle JSON string input" {
            $jsonConfig = $sampleApiKeyConfig | ConvertTo-Json -Depth 5
            $result = Get-AxwaySecurityProfile -Config $jsonConfig
            
            $result.Type | Should -Be "apiKey"
        }
        
        It "Should handle simplified configuration format" {
            $simplifiedConfig = @{
                type = "apiKey"
                properties = @{
                    apiKeyFieldName = "ApiKey"
                    takeFrom = "QUERY"
                }
            }
            
            $result = Get-AxwaySecurityProfile -Config $simplifiedConfig
            $result.Type | Should -Be "apiKey"
        }
    }
    
    Context "Get-SecurityType" {
        It "Should correctly map Axway security types to APIM types" {
            $testCases = @(
                @{ AxwayType = "apiKey"; Expected = "apikey" }
                @{ AxwayType = "oauth"; Expected = "oauth" }
                @{ AxwayType = "oauthExternal"; Expected = "oauth" }
                @{ AxwayType = "httpBasic"; Expected = "basic" }
                @{ AxwayType = "awsSigning"; Expected = "aws" }
                @{ AxwayType = "authPolicy"; Expected = "custom" }
                @{ AxwayType = "passthrough"; Expected = "passthrough" }
            )
            
            foreach ($testCase in $testCases) {
                $config = [PSCustomObject]@{ Type = $testCase.AxwayType }
                $result = Get-SecurityType -Config $config
                $result | Should -Be $testCase.Expected
            }
        }
        
        It "Should default to 'custom' for unknown types" {
            $config = [PSCustomObject]@{ Type = "unknownType" }
            $result = Get-SecurityType -Config $config
            $result | Should -Be "custom"
        }
    }
    
    Context "Convert-AxwaySecurityToApim" {
        It "Should convert API Key configuration to XML policy" {
            $result = Convert-AxwaySecurityToApim -AxwayConfig $sampleApiKeyConfig -SecurityType "apikey"
            
            $result | Should -Not -BeNullOrEmpty
            $result | Should -BeOfType [string]
            $result | Should -Match "<policies>"
            $result | Should -Match "check-header.*X-API-Key"
            $result | Should -Match "X-Auth-Method.*api-key"
        }
        
        It "Should convert OAuth configuration to XML policy" {
            $result = Convert-AxwaySecurityToApim -AxwayConfig $sampleOAuthConfig -SecurityType "oauth"
            
            $result | Should -Not -BeNullOrEmpty
            $result | Should -Match "<policies>"
            $result | Should -Match "validate-jwt"
            $result | Should -Match "Authorization"
            $result | Should -Match "oauth"
        }
        
        It "Should include rate limiting when requested" {
            $result = Convert-AxwaySecurityToApim -AxwayConfig $sampleApiKeyConfig -SecurityType "apikey" -IncludeRateLimit
            
            $result | Should -Match "rate-limit-by-key"
        }
        
        It "Should include logging when requested" {
            $result = Convert-AxwaySecurityToApim -AxwayConfig $sampleApiKeyConfig -SecurityType "apikey" -IncludeLogging
            
            $result | Should -Match "trace.*authentication"
        }
        
        It "Should return JSON format when requested" {
            $result = Convert-AxwaySecurityToApim -AxwayConfig $sampleApiKeyConfig -SecurityType "apikey" -OutputFormat "json"
            
            $parsedResult = $result | ConvertFrom-Json
            $parsedResult.securityType | Should -Be "apikey"
            $parsedResult.policyXml | Should -Not -BeNullOrEmpty
        }
        
        It "Should return object format when requested" {
            $result = Convert-AxwaySecurityToApim -AxwayConfig $sampleApiKeyConfig -SecurityType "apikey" -OutputFormat "object"
            
            $result | Should -BeOfType [PSCustomObject]
            $result.SecurityType | Should -Be "apikey"
            $result.PolicyXml | Should -Not -BeNullOrEmpty
        }
        
        It "Should auto-detect security type" {
            $result = Convert-AxwaySecurityToApim -AxwayConfig $sampleApiKeyConfig
            
            $result | Should -Match "check-header.*X-API-Key"
        }
    }
    
    Context "Test-ApimPolicyValidation" {
        It "Should validate correct policy XML" {
            $validPolicy = @'
<policies>
    <inbound>
        <base />
        <check-header name="X-API-Key" failed-check-httpcode="401" />
    </inbound>
    <backend>
        <base />
    </backend>
    <outbound>
        <base />
    </outbound>
    <on-error>
        <base />
    </on-error>
</policies>
'@
            
            $result = Test-ApimPolicyValidation -PolicyXml $validPolicy
            
            $result.IsValid | Should -Be $true
            $result.Errors | Should -HaveCount 0
        }
        
        It "Should detect invalid XML structure" {
            $invalidPolicy = @'
<policies>
    <inbound>
        <check-header name="X-API-Key" />
    </inbound>
'@
            
            $result = Test-ApimPolicyValidation -PolicyXml $invalidPolicy
            
            $result.IsValid | Should -Be $false
            $result.Errors | Should -Not -BeNullOrEmpty
        }
        
        It "Should handle malformed XML in validation" {
            $malformedXml = "<policies><inbound><unclosed-tag>"
            
            $result = Test-ApimPolicyValidation -PolicyXml $malformedXml
            
            $result.IsValid | Should -Be $false
            $result.Errors | Should -Contain { $_.Message -match "Failed to parse XML" }
        }
    }
    
    Context "Edge Cases and Defaults" {
        It "Should handle missing properties with defaults" {
            $minimalConfig = @{
                securityProfiles = @(
                    @{
                        name = "_default"
                        isDefault = $true
                        devices = @(
                            @{
                                type = "apiKey"
                                properties = @{}
                            }
                        )
                    }
                )
            }
            
            $result = Convert-AxwaySecurityToApim -AxwayConfig $minimalConfig -SecurityType "apikey"
            
            $result | Should -Match "X-API-Key"  # Default field name
        }
        
        It "Should handle null values in properties" {
            $configWithNulls = @{
                securityProfiles = @(
                    @{
                        name = "_default"
                        isDefault = $true
                        devices = @(
                            @{
                                type = "oauth"
                                properties = @{
                                    accessTokenLocation = $null
                                    scopes = $null
                                }
                            }
                        )
                    }
                )
            }
            
            $result = Convert-AxwaySecurityToApim -AxwayConfig $configWithNulls -SecurityType "oauth"
            
            $result | Should -Not -BeNullOrEmpty
            # Should use defaults for null values
        }
        
        It "Should handle boolean string conversion" {
            $configWithStringBools = @{
                securityProfiles = @(
                    @{
                        name = "_default"
                        isDefault = $true
                        devices = @(
                            @{
                                type = "apiKey"
                                properties = @{
                                    removeCredentialsOnSuccess = "false"
                                }
                            }
                        )
                    }
                )
            }
            
            $result = Convert-AxwaySecurityToApim -AxwayConfig $configWithStringBools -SecurityType "apikey"
            
            $result | Should -Not -Match "set-header.*exists-action.*delete"
        }
    }
}

Describe "Policy XML Structure Tests" {
    Context "XML Schema Validation" {
        It "Should have proper XML structure" {
            $policy = Convert-AxwaySecurityToApim -AxwayConfig $sampleApiKeyConfig -SecurityType "apikey"
            $xml = [xml]$policy
            
            # Basic structure validation
            $xml.policies | Should -Not -BeNullOrEmpty
            $xml.policies.inbound | Should -Not -BeNullOrEmpty
            $xml.policies.backend | Should -Not -BeNullOrEmpty
            $xml.policies.outbound | Should -Not -BeNullOrEmpty
            $xml.policies.'on-error' | Should -Not -BeNullOrEmpty
        }
        
        It "Should contain base policies in all sections" {
            $policy = Convert-AxwaySecurityToApim -AxwayConfig $sampleApiKeyConfig -SecurityType "apikey"
            $xml = [xml]$policy
            
            $xml.policies.inbound.base | Should -Not -BeNullOrEmpty
            $xml.policies.backend.base | Should -Not -BeNullOrEmpty
            $xml.policies.outbound.base | Should -Not -BeNullOrEmpty
            $xml.policies.'on-error'.base | Should -Not -BeNullOrEmpty
        }
    }
    
    Context "Expression Syntax Validation" {
        It "Should use proper C# expression syntax" {
            $policy = Convert-AxwaySecurityToApim -AxwayConfig $sampleApiKeyConfig -SecurityType "apikey"
            
            # Check for common expression patterns
            $policy | Should -Match "@\(context\.Request\.Headers\.GetValueOrDefault"
        }
    }
}

Describe "Integration Scenarios" {
    Context "Real-world Configuration Patterns" {
        It "Should handle complex multi-scope OAuth configuration" {
            $complexOAuthConfig = @{
                securityProfiles = @(
                    @{
                        name = "_default"
                        isDefault = $true
                        devices = @(
                            @{
                                type = "oauthExternal"
                                properties = @{
                                    scopes = "api:read, api:write, admin:users, admin:settings"
                                    scopesMustMatch = "All"
                                    accessTokenLocation = "HEADER"
                                    authorizationHeaderPrefix = "Bearer"
                                    removeCredentialsOnSuccess = $true
                                }
                            }
                        )
                    }
                )
            }
            
            $policy = Convert-AxwaySecurityToApim -AxwayConfig $complexOAuthConfig -SecurityType "oauth" -IncludeRateLimit -IncludeLogging
            
            $policy | Should -Match "validate-jwt"
            $policy | Should -Match "scope.*match.*all"
            $policy | Should -Match "rate-limit-by-key"
            $policy | Should -Match "trace.*OAuth-Authentication"
        }
        
        It "Should handle API key with custom field name and query parameter" {
            $customApiKeyConfig = @{
                securityProfiles = @(
                    @{
                        name = "_default"
                        isDefault = $true
                        devices = @(
                            @{
                                type = "apiKey"
                                properties = @{
                                    apiKeyFieldName = "custom-auth-token"
                                    takeFrom = "QUERY"
                                    removeCredentialsOnSuccess = $false
                                }
                            }
                        )
                    }
                )
            }
            
            $policy = Convert-AxwaySecurityToApim -AxwayConfig $customApiKeyConfig -SecurityType "apikey"
            
            $policy | Should -Match "custom-auth-token"
            $policy | Should -Match "context.Request.Url.Query"
            $policy | Should -Not -Match "exists-action.*delete"
        }
        
        It "Should handle basic auth with custom realm" {
            $customBasicConfig = @{
                securityProfiles = @(
                    @{
                        name = "_default"
                        isDefault = $true
                        devices = @(
                            @{
                                type = "httpBasic"
                                properties = @{
                                    realm = "Enterprise API Gateway"
                                    removeCredentialsOnSuccess = $true
                                }
                            }
                        )
                    }
                )
            }
            
            $policy = Convert-AxwaySecurityToApim -AxwayConfig $customBasicConfig -SecurityType "basic"
            
            $policy | Should -Match "Enterprise API Gateway"
            $policy | Should -Match "authentication-basic"
        }
    }
    
    Context "Performance and Optimization" {
        It "Should not generate excessive policy elements" {
            $policy = Convert-AxwaySecurityToApim -AxwayConfig $sampleApiKeyConfig -SecurityType "apikey" -IncludeRateLimit -IncludeLogging
            $xml = [xml]$policy
            
            # Count policy elements to ensure reasonable complexity
            $allElements = $xml.SelectNodes("//*")
            $allElements.Count | Should -BeLessThan 50
        }
        
        It "Should generate minimal policy when features are disabled" {
            $policy = Convert-AxwaySecurityToApim -AxwayConfig $sampleApiKeyConfig -SecurityType "apikey"
            
            $policy | Should -Not -Match "rate-limit"
            $policy | Should -Not -Match "trace"
            $policy.Length | Should -BeLessThan 2000
        }
    }
}
