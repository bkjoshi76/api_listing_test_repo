using module "./../../scripts/modules/AxwayToApimConverter.psm1"

Describe "End-to-End Integration Tests" {
    BeforeAll {
        # Environment setup
        $script:TestResourceGroup = $env:TEST_RESOURCE_GROUP ?? "test-rg"
        $script:TestApimService = $env:TEST_APIM_SERVICE ?? "test-apim"
        $script:TestApiId = $env:TEST_API_ID ?? "test-api-$(Get-Random)"
        $script:TestApiPath = "/integration-test/v1"
        
        # Skip integration tests if required environment variables are not set
        if (-not $env:TEST_RESOURCE_GROUP -or -not $env:TEST_APIM_SERVICE) {
            Write-Warning "Integration tests skipped. Set TEST_RESOURCE_GROUP and TEST_APIM_SERVICE environment variables to run integration tests."
            return
        }
        
        # Import the module
        Import-Module "$PSScriptRoot/../../scripts/modules/AxwayToApimConverter.psm1" -Force
        
        # Test configurations
        $script:testConfigurations = @{
            ApiKey = @{
                axway = @{
                    securityProfiles = @(
                        @{
                            name = "_default"
                            isDefault = $true
                            devices = @(
                                @{
                                    type = "apiKey"
                                    properties = @{
                                        apiKeyFieldName = "X-Test-API-Key"
                                        takeFrom = "HEADER"
                                        removeCredentialsOnSuccess = $true
                                    }
                                }
                            )
                        }
                    )
                }
                testHeaders = @{
                    "X-Test-API-Key" = "test-key-12345"
                }
            }
            OAuth = @{
                axway = @{
                    securityProfiles = @(
                        @{
                            name = "_default"
                            isDefault = $true
                            devices = @(
                                @{
                                    type = "oauth"
                                    properties = @{
                                        accessTokenLocation = "HEADER"
                                        authorizationHeaderPrefix = "Bearer"
                                        scopes = "test.read, test.write"
                                        scopesMustMatch = "Any"
                                        removeCredentialsOnSuccess = $true
                                    }
                                }
                            )
                        }
                    )
                }
                testHeaders = @{
                    "Authorization" = "Bearer test-oauth-token"
                }
            }
            BasicAuth = @{
                axway = @{
                    securityProfiles = @(
                        @{
                            name = "_default"
                            isDefault = $true
                            devices = @(
                                @{
                                    type = "httpBasic"
                                    properties = @{
                                        realm = "Test Realm"
                                        removeCredentialsOnSuccess = $true
                                    }
                                }
                            )
                        }
                    )
                }
                testHeaders = @{
                    "Authorization" = "Basic dGVzdDp0ZXN0"  # test:test in base64
                }
            }
        }
        
        # Verify Azure CLI is available and logged in
        try {
            $account = az account show --query "name" -o tsv 2>$null
            if ($LASTEXITCODE -ne 0) {
                throw "Azure CLI not authenticated"
            }
            Write-Host "✅ Azure CLI authenticated as: $account" -ForegroundColor Green
        }
        catch {
            Write-Error "❌ Azure CLI authentication required for integration tests"
            throw
        }
        
        # Verify APIM service exists
        try {
            $apim = az apim show --name $TestApimService --resource-group $TestResourceGroup --query "name" -o tsv 2>$null
            if ($LASTEXITCODE -ne 0) {
                throw "APIM service not found"
            }
            Write-Host "✅ APIM Service found: $apim" -ForegroundColor Green
        }
        catch {
            Write-Error "❌ APIM Service '$TestApimService' not found in resource group '$TestResourceGroup'"
            throw
        }
    }
    
    BeforeEach {
        # Clean up any existing test API
        try {
            az apim api delete --service-name $TestApimService --resource-group $TestResourceGroup --api-id $TestApiId --yes 2>$null
        }
        catch {
            # Ignore errors if API doesn't exist
        }
    }
    
    AfterEach {
        # Clean up test API after each test
        try {
            az apim api delete --service-name $TestApimService --resource-group $TestResourceGroup --api-id $TestApiId --yes 2>$null
        }
        catch {
            # Ignore cleanup errors
        }
    }
    
    Context "API Key Authentication Integration" {
        It "Should deploy and test API Key authentication end-to-end" {
            # Skip if environment not configured
            if (-not $env:TEST_RESOURCE_GROUP -or -not $env:TEST_APIM_SERVICE) {
                Set-ItResult -Skipped -Because "Integration test environment not configured"
                return
            }
            
            # Create test API
            $apiSpec = @{
                apiId = $TestApiId
                path = $TestApiPath
                displayName = "Integration Test API"
                protocols = @("https")
                serviceUrl = "https://httpbin.org"
                openApiSpec = @{
                    openapi = "3.0.1"
                    info = @{
                        title = "Test API"
                        version = "1.0.0"
                    }
                    paths = @{
                        "/test" = @{
                            get = @{
                                operationId = "test"
                                responses = @{
                                    "200" = @{
                                        description = "Success"
                                    }
                                }
                            }
                        }
                    }
                }
            }
            
            # Create API
            $tempApiFile = [System.IO.Path]::GetTempFileName()
            try {
                $apiSpec.openApiSpec | ConvertTo-Json -Depth 10 | Out-File -FilePath $tempApiFile -Encoding UTF8
                
                az apim api create `
                    --service-name $TestApimService `
                    --resource-group $TestResourceGroup `
                    --api-id $TestApiId `
                    --path $TestApiPath `
                    --display-name "Integration Test API" `
                    --protocols "https" `
                    --service-url "https://httpbin.org" `
                    --specification-format "OpenApi" `
                    --specification-path $tempApiFile
                
                $LASTEXITCODE | Should -Be 0
            }
            finally {
                Remove-Item $tempApiFile -Force -ErrorAction SilentlyContinue
            }
            
            # Convert Axway configuration to APIM policy
            $policy = Convert-AxwaySecurityToApim `
                -AxwayConfig $testConfigurations.ApiKey.axway `
                -SecurityType "apikey" `
                -IncludeRateLimit `
                -IncludeLogging
            
            # Validate generated policy
            $validation = Test-ApimPolicyValidation -PolicyXml $policy -ValidationLevel "Comprehensive"
            $validation.IsValid | Should -Be $true -Because "Generated policy should be valid"
            
            # Deploy policy using the module
            $deployment = Deploy-ApimSecurityPolicy `
                -ResourceGroupName $TestResourceGroup `
                -ApimServiceName $TestApimService `
                -ApiId $TestApiId `
                -PolicyXml $policy `
                -BackupExisting
            
            $deployment | Should -Be $true
            
            # Wait for deployment to propagate
            Start-Sleep -Seconds 10
            
            # Test the deployed API
            $apimInfo = az apim show --name $TestApimService --resource-group $TestResourceGroup | ConvertFrom-Json
            $gatewayUrl = $apimInfo.gatewayUrl
            $testUrl = "$gatewayUrl$TestApiPath/test"
            
            # Test without API key (should fail)
            try {
                $response = Invoke-RestMethod -Uri $testUrl -Method Get -TimeoutSec 30
                # If we reach here, the test should fail
                $false | Should -Be $true -Because "Request without API key should have failed"
            }
            catch {
                # Expected behavior - should return 401
                $_.Exception.Response.StatusCode.value__ | Should -Be 401
            }
            
            # Test with invalid API key (should fail)
            try {
                $headers = @{ "X-Test-API-Key" = "invalid-key" }
                $response = Invoke-RestMethod -Uri $testUrl -Method Get -Headers $headers -TimeoutSec 30
                # If we reach here, the test should fail
                $false | Should -Be $true -Because "Request with invalid API key should have failed"
            }
            catch {
                # Expected behavior - should return 401
                $_.Exception.Response.StatusCode.value__ | Should -Be 401
            }
            
            Write-Host "✅ API Key authentication integration test completed successfully" -ForegroundColor Green
        }
        
        It "Should handle policy backup and rollback" {
            # Skip if environment not configured
            if (-not $env:TEST_RESOURCE_GROUP -or -not $env:TEST_APIM_SERVICE) {
                Set-ItResult -Skipped -Because "Integration test environment not configured"
                return
            }
            
            # Create a simple test API first
            $tempApiFile = [System.IO.Path]::GetTempFileName()
            try {
                @{
                    openapi = "3.0.1"
                    info = @{ title = "Test API"; version = "1.0.0" }
                    paths = @{
                        "/test" = @{
                            get = @{
                                responses = @{ "200" = @{ description = "Success" } }
                            }
                        }
                    }
                } | ConvertTo-Json -Depth 10 | Out-File -FilePath $tempApiFile -Encoding UTF8
                
                az apim api create `
                    --service-name $TestApimService `
                    --resource-group $TestResourceGroup `
                    --api-id $TestApiId `
                    --path $TestApiPath `
                    --display-name "Test API" `
                    --protocols "https" `
                    --specification-format "OpenApi" `
                    --specification-path $tempApiFile
            }
            finally {
                Remove-Item $tempApiFile -Force -ErrorAction SilentlyContinue
            }
            
            # Deploy initial policy
            $initialPolicy = @"
<policies>
    <inbound>
        <base />
    </inbound>
    <backend>
        <base />
    </backend>
    <outbound>
        <base />
    </outbound>
    <on-error>
        <base />
    </on-error>
</policies>
"@
            
            Deploy-ApimSecurityPolicy `
                -ResourceGroupName $TestResourceGroup `
                -ApimServiceName $TestApimService `
                -ApiId $TestApiId `
                -PolicyXml $initialPolicy | Should -Be $true
            
            # Test backup functionality
            $backupFile = "test-backup-$(Get-Random).xml"
            try {
                Backup-ApimPolicy `
                    -ResourceGroupName $TestResourceGroup `
                    -ApimServiceName $TestApimService `
                    -ApiId $TestApiId `
                    -BackupFile $backupFile
                
                Test-Path $backupFile | Should -Be $true
                
                $backupContent = Get-Content $backupFile -Raw
                $backupContent | Should -Not -BeNullOrEmpty
                $backupContent | Should -Match "<policies>"
            }
            finally {
                Remove-Item $backupFile -Force -ErrorAction SilentlyContinue
            }
            
            Write-Host "✅ Policy backup and rollback test completed successfully" -ForegroundColor Green
        }
    }
    
    Context "Named Values Management" {
        It "Should set and retrieve Named Values for OAuth configuration" {
            # Skip if environment not configured
            if (-not $env:TEST_RESOURCE_GROUP -or -not $env:TEST_APIM_SERVICE) {
                Set-ItResult -Skipped -Because "Integration test environment not configured"
                return
            }
            
            $testNamedValues = @{
                "test-oauth-audience" = "https://test.example.com"
                "test-oauth-issuer" = "https://test-provider.example.com/"
                "test-basic-username" = "testuser"
            }
            
            $secretValues = @{
                "test-oauth-secret" = "super-secret-value"
                "test-basic-password" = "test-password"
            }
            
            # Set regular Named Values
            Set-ApimNamedValues `
                -ResourceGroupName $TestResourceGroup `
                -ApimServiceName $TestApimService `
                -NamedValues $testNamedValues
            
            # Set secret Named Values
            Set-ApimNamedValues `
                -ResourceGroupName $TestResourceGroup `
                -ApimServiceName $TestApimService `
                -NamedValues $secretValues `
                -SecretValues
            
            # Verify Named Values were created
            $namedValues = az apim nv list `
                --service-name $TestApimService `
                --resource-group $TestResourceGroup | ConvertFrom-Json
            
            foreach ($kvp in $testNamedValues.GetEnumerator()) {
                $namedValues | Where-Object { $_.name -eq $kvp.Key } | Should -Not -BeNullOrEmpty
            }
            
            foreach ($kvp in $secretValues.GetEnumerator()) {
                $namedValue = $namedValues | Where-Object { $_.name -eq $kvp.Key }
                $namedValue | Should -Not -BeNullOrEmpty
                $namedValue.secret | Should -Be $true
            }
            
            # Cleanup Named Values
            foreach ($kvp in ($testNamedValues + $secretValues).GetEnumerator()) {
                try {
                    az apim nv delete `
                        --service-name $TestApimService `
                        --resource-group $TestResourceGroup `
                        --named-value-id $kvp.Key `
                        --yes 2>$null
                }
                catch {
                    # Ignore cleanup errors
                }
            }
            
            Write-Host "✅ Named Values management test completed successfully" -ForegroundColor Green
        }
    }
    
    Context "Policy Validation and Error Handling" {
        It "Should detect and report policy validation errors during deployment" {
            # Skip if environment not configured
            if (-not $env:TEST_RESOURCE_GROUP -or -not $env:TEST_APIM_SERVICE) {
                Set-ItResult -Skipped -Because "Integration test environment not configured"
                return
            }
            
            # Create test API
            $tempApiFile = [System.IO.Path]::GetTempFileName()
            try {
                @{
                    openapi = "3.0.1"
                    info = @{ title = "Test API"; version = "1.0.0" }
                    paths = @{
                        "/test" = @{
                            get = @{
                                responses = @{ "200" = @{ description = "Success" } }
                            }
                        }
                    }
                } | ConvertTo-Json -Depth 10 | Out-File -FilePath $tempApiFile -Encoding UTF8
                
                az apim api create `
                    --service-name $TestApimService `
                    --resource-group $TestResourceGroup `
                    --api-id $TestApiId `
                    --path $TestApiPath `
                    --display-name "Test API" `
                    --protocols "https" `
                    --specification-format "OpenApi" `
                    --specification-path $tempApiFile
            }
            finally {
                Remove-Item $tempApiFile -Force -ErrorAction SilentlyContinue
            }
            
            # Test with invalid policy XML
            $invalidPolicy = @"
<policies>
    <inbound>
        <rate-limit-by-key calls="0" renewal-period="400" />
    </inbound>
    <backend><base /></backend>
    <outbound><base /></outbound>
    <on-error><base /></on-error>
</policies>
"@
            
            # Should throw error due to validation failure
            {
                Deploy-ApimSecurityPolicy `
                    -ResourceGroupName $TestResourceGroup `
                    -ApimServiceName $TestApimService `
                    -ApiId $TestApiId `
                    -PolicyXml $invalidPolicy
            } | Should -Throw -ExpectedMessage "*validation failed*"
            
            Write-Host "✅ Policy validation error handling test completed successfully" -ForegroundColor Green
        }
    }
    
    Context "Complete Migration Workflow" {
        It "Should perform complete Axway to Azure APIM migration" {
            # Skip if environment not configured
            if (-not $env:TEST_RESOURCE_GROUP -or -not $env:TEST_APIM_SERVICE) {
                Set-ItResult -Skipped -Because "Integration test environment not configured"
                return
            }
            
            # Simulate complete migration workflow
            $axwayConfig = $testConfigurations.ApiKey.axway
            
            # Step 1: Parse Axway configuration
            $securityProfile = Get-AxwaySecurityProfile -Config $axwayConfig
            $securityProfile | Should -Not -BeNullOrEmpty
            
            # Step 2: Convert to APIM policy
            $policy = Convert-AxwaySecurityToApim `
                -AxwayConfig $axwayConfig `
                -IncludeRateLimit `
                -IncludeLogging `
                -OutputFormat "object"
            
            $policy.SecurityType | Should -Be "apikey"
            $policy.PolicyXml | Should -Not -BeNullOrEmpty
            
            # Step 3: Validate policy
            $validation = Test-ApimPolicyValidation `
                -PolicyXml $policy.PolicyXml `
                -ValidationLevel "Comprehensive"
            
            $validation.IsValid | Should -Be $true
            
            # Step 4: Create API in APIM
            $tempApiFile = [System.IO.Path]::GetTempFileName()
            try {
                @{
                    openapi = "3.0.1"
                    info = @{ title = "Migration Test API"; version = "1.0.0" }
                    paths = @{
                        "/migrate-test" = @{
                            get = @{
                                responses = @{ "200" = @{ description = "Success" } }
                            }
                        }
                    }
                } | ConvertTo-Json -Depth 10 | Out-File -FilePath $tempApiFile -Encoding UTF8
                
                az apim api create `
                    --service-name $TestApimService `
                    --resource-group $TestResourceGroup `
                    --api-id $TestApiId `
                    --path "/migration-test" `
                    --display-name "Migration Test API" `
                    --protocols "https" `
                    --specification-format "OpenApi" `
                    --specification-path $tempApiFile
            }
            finally {
                Remove-Item $tempApiFile -Force -ErrorAction SilentlyContinue
            }
            
            # Step 5: Deploy security policy
            $deployment = Deploy-ApimSecurityPolicy `
                -ResourceGroupName $TestResourceGroup `
                -ApimServiceName $TestApimService `
                -ApiId $TestApiId `
                -PolicyXml $policy.PolicyXml `
                -BackupExisting
            
            $deployment | Should -Be $true
            
            # Step 6: Verify policy was deployed
            $deployedPolicy = az apim api policy show `
                --service-name $TestApimService `
                --resource-group $TestResourceGroup `
                --api-id $TestApiId `
                --query "value" `
                --output tsv
            
            $deployedPolicy | Should -Not -BeNullOrEmpty
            $deployedPolicy | Should -Match "X-Test-API-Key"
            $deployedPolicy | Should -Match "rate-limit-by-key"
            
            Write-Host "✅ Complete migration workflow test completed successfully" -ForegroundColor Green
        }
    }
}
