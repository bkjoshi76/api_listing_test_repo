# Enhanced Integration Tests for Complete API Configuration Migration
# End-to-end testing of Axway to Azure APIM migration with real Azure resources

#Requires -Modules @{ ModuleName="Pester"; ModuleVersion="5.0.0" }

BeforeAll {
    # Import required modules
    $modulePath = "$PSScriptRoot/../../scripts/modules/AxwayToApimConverterEnhanced.psm1"
    if (Test-Path $modulePath) {
        Import-Module $modulePath -Force
    }
    else {
        throw "Enhanced module not found: $modulePath"
    }
    
    # Test configuration
    $script:TestConfig = @{
        ResourceGroupName = $env:APIM_TEST_RESOURCE_GROUP ?? "apim-test-rg"
        ApimServiceName = $env:APIM_TEST_SERVICE_NAME ?? "apim-test-$(Get-Random)"
        Location = $env:APIM_TEST_LOCATION ?? "East US"
        SubscriptionId = $env:AZURE_SUBSCRIPTION_ID
        TestOutputPath = "$PSScriptRoot/integration-test-output"
        TestDataPath = "$PSScriptRoot/integration-test-data"
    }
    
    # Create test directories
    @($script:TestConfig.TestOutputPath, $script:TestConfig.TestDataPath) | ForEach-Object {
        if (-not (Test-Path $_)) {
            New-Item -Path $_ -ItemType Directory -Force | Out-Null
        }
    }
    
    Write-Host "🧪 Integration Test Configuration:" -ForegroundColor Cyan
    Write-Host "  Resource Group: $($script:TestConfig.ResourceGroupName)" -ForegroundColor White
    Write-Host "  APIM Service: $($script:TestConfig.ApimServiceName)" -ForegroundColor White
    Write-Host "  Location: $($script:TestConfig.Location)" -ForegroundColor White
}

Describe "Complete API Configuration Migration - Integration Tests" {
    
    BeforeAll {
        # Skip integration tests if Azure CLI is not authenticated
        try {
            $account = az account show --query "name" -o tsv 2>$null
            if ($LASTEXITCODE -ne 0) {
                throw "Azure CLI not authenticated"
            }
            Write-Host "✅ Azure CLI authenticated as: $account" -ForegroundColor Green
        }
        catch {
            Write-Warning "Skipping integration tests - Azure CLI not authenticated"
            return
        }
        
        # Create test API configurations
        $script:CompleteApiConfig = @{
            name = "Integration Test Complete API"
            path = "/api/v1/integration-complete"
            state = "published"
            version = "1.0.0"
            organization = "Integration Test Organization"
            backendBasepath = "https://httpbin.org"
            apiDefinition = "test-openapi-spec.json"
            
            tags = @{
                environment = @("integration-test")
                version = @("v1", "current")
            }
            
            customProperties = @{
                testEnvironment = "integration"
                owner = "integration-test-suite"
                purpose = "automated-testing"
            }
            
            securityProfiles = @(
                @{
                    name = "_default"
                    isDefault = $true
                    devices = @(
                        @{
                            name = "API Key Authentication"
                            type = "apiKey"
                            order = 0
                            properties = @{
                                apiKeyFieldName = "X-Integration-API-Key"
                                takeFrom = "HEADER"
                                removeCredentialsOnSuccess = $true
                            }
                        }
                    )
                }
            )
            
            outboundProfiles = @{
                _default = @{
                    authenticationProfile = "backend_basic_auth"
                }
            }
            
            authenticationProfiles = @(
                @{
                    name = "backend_basic_auth"
                    type = "basic"
                    parameters = @{
                        username = "integration-test-user"
                        password = "integration-test-password"
                    }
                }
            )
            
            corsProfiles = @(
                @{
                    name = "integration_cors"
                    isDefault = $true
                    origins = @("https://integration.test.com", "http://localhost:3000")
                    allowedHeaders = @("Authorization", "Content-Type", "X-Integration-API-Key")
                    exposedHeaders = @("X-Request-ID", "X-Rate-Limit-Remaining")
                    supportCredentials = $true
                    maxAgeSeconds = 300
                }
            )
            
            applicationQuota = @{
                restrictions = @(
                    @{
                        method = "GET"
                        type = "throttle"
                        config = @{
                            period = "minute"
                            per = 1
                            messages = 100
                        }
                    }
                    @{
                        method = "POST,PUT,DELETE"
                        type = "throttle"
                        config = @{
                            period = "minute"
                            per = 1
                            messages = 50
                        }
                    }
                )
            }
            
            systemQuota = @{
                restrictions = @(
                    @{
                        method = "*"
                        type = "throttle"
                        config = @{
                            period = "second"
                            per = 1
                            messages = 1000
                        }
                    }
                )
            }
        }
        
        # Create test OpenAPI specification
        $openApiSpec = @{
            openapi = "3.0.1"
            info = @{
                title = "Integration Test API"
                version = "1.0.0"
                description = "API for integration testing"
            }
            paths = @{
                "/test" = @{
                    get = @{
                        operationId = "test-endpoint"
                        summary = "Test endpoint for integration testing"
                        responses = @{
                            "200" = @{
                                description = "Success"
                                content = @{
                                    "application/json" = @{
                                        schema = @{
                                            type = "object"
                                            properties = @{
                                                message = @{ type = "string" }
                                                timestamp = @{ type = "string" }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                "/secure" = @{
                    get = @{
                        operationId = "secure-endpoint"
                        summary = "Secure endpoint requiring authentication"
                        security = @(
                            @{ ApiKeyAuth = @() }
                        )
                        responses = @{
                            "200" = @{ description = "Success" }
                            "401" = @{ description = "Unauthorized" }
                        }
                    }
                }
            }
            components = @{
                securitySchemes = @{
                    ApiKeyAuth = @{
                        type = "apiKey"
                        in = "header"
                        name = "X-Integration-API-Key"
                    }
                }
            }
        }
        
        # Save test configurations
        $script:CompleteApiConfigFile = "$($script:TestConfig.TestDataPath)/complete-api-config.json"
        $script:CompleteApiConfig | ConvertTo-Json -Depth 10 | Out-File $script:CompleteApiConfigFile -Encoding UTF8
        
        $openApiSpecFile = "$($script:TestConfig.TestDataPath)/test-openapi-spec.json"
        $openApiSpec | ConvertTo-Json -Depth 10 | Out-File $openApiSpecFile -Encoding UTF8
    }
    
    Context "Prerequisites Validation" -Tag "Prerequisites" {
        
        It "Should validate Azure CLI authentication" {
            $account = az account show --query "name" -o tsv
            $LASTEXITCODE | Should -Be 0
            $account | Should -Not -BeNullOrEmpty
        }
        
        It "Should have required Azure subscription" {
            if ($script:TestConfig.SubscriptionId) {
                az account set --subscription $script:TestConfig.SubscriptionId
                $LASTEXITCODE | Should -Be 0
            }
            
            $subscription = az account show --query "id" -o tsv
            $subscription | Should -Not -BeNullOrEmpty
        }
        
        It "Should validate test configuration files" {
            Test-Path $script:CompleteApiConfigFile | Should -Be $true
            
            $config = Get-Content $script:CompleteApiConfigFile -Raw | ConvertFrom-Json
            $config.name | Should -Not -BeNullOrEmpty
            $config.path | Should -Not -BeNullOrEmpty
        }
    }
    
    Context "API Configuration Conversion" -Tag "Conversion" {
        
        It "Should convert complete API configuration successfully" {
            $result = Convert-AxwayApiConfiguration `
                -AxwayConfig $script:CompleteApiConfigFile `
                -OutputPath $script:TestConfig.TestOutputPath `
                -IncludeInfrastructure
            
            $result | Should -Not -BeNullOrEmpty
            $result.Success | Should -Be $true
            $result.ArtifactsGenerated | Should -BeGreaterThan 0
        }
        
        It "Should generate all expected output files" {
            $expectedFiles = @(
                "apim-policy.xml",
                "api-definition.json", 
                "named-values.json",
                "conversion-report.json"
            )
            
            foreach ($file in $expectedFiles) {
                $filePath = Join-Path $script:TestConfig.TestOutputPath $file
                Test-Path $filePath | Should -Be $true -Because "File $file should be generated"
            }
        }
        
        It "Should generate valid APIM policy XML" {
            $policyFile = Join-Path $script:TestConfig.TestOutputPath "apim-policy.xml"
            $policy = Get-Content $policyFile -Raw
            
            # Basic XML validation
            $policy | Should -Match "<policies>"
            $policy | Should -Match "<inbound>"
            $policy | Should -Match "<backend>" 
            $policy | Should -Match "<outbound>"
            $policy | Should -Match "<on-error>"
            
            # Security validation
            $policy | Should -Match "X-Integration-API-Key"
            $policy | Should -Match "check-header"
            
            # CORS validation
            $policy | Should -Match "<cors"
            $policy | Should -Match "allow-credentials"
            
            # Rate limiting validation
            $policy | Should -Match "rate-limit-by-key"
            
            # Backend authentication validation
            $policy | Should -Match "Authorization"
            $policy | Should -Match "Basic"
        }
        
        It "Should generate valid API definition" {
            $definitionFile = Join-Path $script:TestConfig.TestOutputPath "api-definition.json"
            $definition = Get-Content $definitionFile -Raw | ConvertFrom-Json
            
            $definition.ApiId | Should -Not -BeNullOrEmpty
            $definition.DisplayName | Should -Be "Integration Test Complete API"
            $definition.Path | Should -Be "/api/v1/integration-complete"
            $definition.ServiceUrl | Should -Be "https://httpbin.org"
            $definition.State | Should -Be "published"
        }
        
        It "Should generate comprehensive conversion report" {
            $reportFile = Join-Path $script:TestConfig.TestOutputPath "conversion-report.json"
            $report = Get-Content $reportFile -Raw | ConvertFrom-Json
            
            $report.MigrationTimestamp | Should -Not -BeNullOrEmpty
            $report.SourceConfiguration | Should -Match "complete-api-config.json"
            $report.Analysis | Should -Not -BeNullOrEmpty
            $report.ConversionResult | Should -Not -BeNullOrEmpty
        }
    }
    
    Context "Validation and Best Practices" -Tag "Validation" {
        
        It "Should validate conversion artifacts integrity" {
            $reportFile = Join-Path $script:TestConfig.TestOutputPath "conversion-report.json"
            
            if (Test-Path $reportFile) {
                $report = Get-Content $reportFile -Raw | ConvertFrom-Json
                
                # Validate report structure
                $report.MigrationTimestamp | Should -Not -BeNullOrEmpty
                $report.Analysis | Should -Not -BeNullOrEmpty
                $report.ConversionResult | Should -Not -BeNullOrEmpty
                
                # Validate no critical errors
                if ($report.ConversionResult.Errors) {
                    $criticalErrors = $report.ConversionResult.Errors | Where-Object { $_.Severity -eq "Critical" }
                    $criticalErrors.Count | Should -Be 0
                }
            }
        }
        
        It "Should generate final test report" {
            $testSummary = @{
                TestRun = @{
                    Timestamp = Get-Date
                    Duration = "Integration tests completed"
                    Environment = "Integration Test"
                }
                Configuration = $script:TestConfig
                Results = @{
                    ConversionSuccessful = Test-Path (Join-Path $script:TestConfig.TestOutputPath "conversion-report.json")
                    ArtifactsGenerated = (Get-ChildItem $script:TestConfig.TestOutputPath -File).Count
                    TestDataCreated = Test-Path $script:TestConfig.TestDataPath
                }
                Recommendations = @(
                    "Review conversion report for any warnings or recommendations",
                    "Validate security configurations in production environment", 
                    "Set up monitoring and alerting for the migrated API",
                    "Perform load testing in staging environment",
                    "Update client applications to use new APIM endpoints"
                )
            }
            
            $reportPath = Join-Path $script:TestConfig.TestOutputPath "integration-test-report.json"
            $testSummary | ConvertTo-Json -Depth 5 | Out-File $reportPath -Encoding UTF8
            
            Write-Host "✅ Integration test report saved to: $reportPath" -ForegroundColor Green
            Test-Path $reportPath | Should -Be $true
        }
    }
}

AfterAll {
    # Cleanup test directories (but preserve artifacts for review)
    Write-Host "🧹 Integration tests completed" -ForegroundColor Cyan
    Write-Host "📁 Test artifacts preserved in:" -ForegroundColor Yellow
    Write-Host "  Output: $($script:TestConfig.TestOutputPath)" -ForegroundColor White
    Write-Host "  Data: $($script:TestConfig.TestDataPath)" -ForegroundColor White
    
    if ($env:CLEANUP_TEST_DATA) {
        Write-Host "🗑️ Cleaning up test data..." -ForegroundColor Yellow
        Remove-Item $script:TestConfig.TestDataPath -Recurse -Force -ErrorAction SilentlyContinue
    }
    
    Write-Host "💡 Integration test notes:" -ForegroundColor Cyan
    Write-Host "  • Tests validate configuration conversion without requiring Azure APIM deployment" -ForegroundColor White
    Write-Host "  • For full end-to-end testing with Azure resources, deploy APIM service manually" -ForegroundColor White
    Write-Host "  • Review generated artifacts in output directory for validation" -ForegroundColor White
}
