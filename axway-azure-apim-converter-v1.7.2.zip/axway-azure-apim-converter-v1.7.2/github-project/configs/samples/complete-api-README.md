# Sample Complete Axway API Configuration Files

This directory contains comprehensive sample configurations demonstrating all aspects of Axway API configuration including outbound authentication, CORS, quotas, custom properties, and certificates.

## Files in this Directory

### 1. Complete API Configuration (`complete-api-config.json`)
Full enterprise API configuration with all features enabled

### 2. Outbound Authentication Samples
- `outbound-oauth.json` - OAuth to backend services
- `outbound-basic.json` - Basic authentication to legacy backends  
- `outbound-ssl.json` - SSL certificate authentication
- `outbound-custom.json` - Custom authentication policies

### 3. Multi-Environment Configurations
- `production-config.json` - Production environment settings
- `staging-config.json` - Staging environment settings
- `development-config.json` - Development environment settings

### 4. Specialized Scenarios
- `microservices-api.json` - Microservices with service mesh
- `legacy-migration.json` - Legacy system integration
- `multi-tenant.json` - Multi-tenant SaaS API

## Complete API Configuration Example

```json
{
  "name": "Complete Enterprise API",
  "path": "/api/v3/complete",
  "state": "published",
  "version": "3.0.0",
  "organization": "Enterprise Solutions",
  "apiRoutingKey": "v3",
  "vhost": "api.complete.enterprise.com",
  "backendBasepath": "https://backend.enterprise.com/v3",
  "overrideSpecBasePath": true,
  
  "summary": "Complete API demonstrating all migration features",
  "description": "Comprehensive API configuration showcasing all Axway features",
  "descriptionType": "markdownLocal",
  "descriptionMarkdown": [
    "../docs/overview.md",
    "ORIGINAL",
    "../docs/integration.md"
  ],
  
  "tags": {
    "environment": ["production"],
    "version": ["v3", "current", "stable"],
    "features": ["oauth", "cors", "quotas", "certificates"],
    "compliance": ["gdpr", "soc2", "hipaa"]
  },
  
  "customProperties": {
    "businessOwner": "API Platform Team",
    "technicalContact": "api-team@enterprise.com",
    "supportLevel": "24x7x365",
    "dataClassification": "restricted",
    "complianceFrameworks": "SOX,GDPR,HIPAA",
    "backupStrategy": "geo-replicated-hourly",
    "disasterRecovery": "rpo-15min-rto-1hr",
    "performanceSLA": "99.99-uptime-100ms-p95"
  },
  
  "inboundProfiles": {
    "_default": {
      "monitorAPI": true,
      "queryStringPassThrough": false,
      "monitorSubject": "authentication.subject.id",
      "securityProfile": "multi_auth",
      "corsProfile": "enterprise_cors"
    },
    "adminProfile": {
      "monitorAPI": true,
      "queryStringPassThrough": false,
      "monitorSubject": "authentication.subject.id",
      "securityProfile": "admin_only",
      "corsProfile": "admin_cors"
    }
  },
  
  "securityProfiles": [
    {
      "name": "multi_auth",
      "isDefault": true,
      "devices": [
        {
          "name": "API Key Primary",
          "type": "apiKey",
          "order": 0,
          "properties": {
            "apiKeyFieldName": "X-API-Key",
            "takeFrom": "HEADER",
            "removeCredentialsOnSuccess": true
          }
        },
        {
          "name": "OAuth Fallback",
          "type": "oauthExternal",
          "order": 1,
          "properties": {
            "tokenStore": "Azure AD B2C",
            "accessTokenLocation": "HEADER",
            "authorizationHeaderPrefix": "Bearer",
            "scopes": "api.read api.write api.admin",
            "scopesMustMatch": "Any",
            "removeCredentialsOnSuccess": true,
            "useClientRegistry": true,
            "subjectSelector": "${oauth.token.preferred_username}"
          }
        }
      ]
    },
    {
      "name": "admin_only",
      "isDefault": false,
      "devices": [
        {
          "name": "Admin OAuth",
          "type": "oauthExternal",
          "order": 0,
          "properties": {
            "tokenStore": "Azure AD Admin",
            "accessTokenLocation": "HEADER",
            "authorizationHeaderPrefix": "Bearer",
            "scopes": "api.admin admin.full",
            "scopesMustMatch": "All",
            "removeCredentialsOnSuccess": true,
            "useClientRegistry": true,
            "subjectSelector": "${oauth.token.email}"
          }
        }
      ]
    }
  ],
  
  "outboundProfiles": {
    "_default": {
      "authenticationProfile": "backend_service_oauth",
      "requestPolicy": "Add Request Context",
      "responsePolicy": "Security Response Filter",
      "routePolicy": "Intelligent Load Balancer",
      "faultHandlerPolicy": "Enterprise Error Handler"
    },
    "readOperations": {
      "authenticationProfile": "backend_read_oauth",
      "requestPolicy": "Add Read Context",
      "responsePolicy": "Cache Response Policy",
      "routePolicy": "Read Replicas Load Balancer",
      "faultHandlerPolicy": "Read Error Handler"
    },
    "writeOperations": {
      "authenticationProfile": "backend_write_oauth",
      "requestPolicy": "Add Write Context",
      "responsePolicy": "Transaction Response Policy",
      "routePolicy": "Primary Writer Load Balancer",
      "faultHandlerPolicy": "Write Error Handler"
    },
    "analyticsOperations": {
      "authenticationProfile": "analytics_service_key",
      "requestPolicy": "Add Analytics Context",
      "responsePolicy": "Analytics Response Policy",
      "routePolicy": "Analytics Service Router",
      "faultHandlerPolicy": "Analytics Error Handler"
    }
  },
  
  "authenticationProfiles": [
    {
      "name": "backend_service_oauth",
      "type": "oauth",
      "parameters": {
        "tokenEndpoint": "https://auth.enterprise.com/oauth/v2/token",
        "clientId": "${backend.service.oauth.clientId}",
        "clientSecret": "${backend.service.oauth.clientSecret}",
        "scope": "backend.api.access",
        "grantType": "client_credentials",
        "tokenCacheDuration": 3600,
        "retryAttempts": 3
      }
    },
    {
      "name": "backend_read_oauth",
      "type": "oauth",
      "parameters": {
        "tokenEndpoint": "https://auth.enterprise.com/oauth/v2/token",
        "clientId": "${backend.read.oauth.clientId}",
        "clientSecret": "${backend.read.oauth.clientSecret}",
        "scope": "backend.api.read",
        "grantType": "client_credentials",
        "tokenCacheDuration": 7200
      }
    },
    {
      "name": "backend_write_oauth",
      "type": "oauth", 
      "parameters": {
        "tokenEndpoint": "https://auth.enterprise.com/oauth/v2/token",
        "clientId": "${backend.write.oauth.clientId}",
        "clientSecret": "${backend.write.oauth.clientSecret}",
        "scope": "backend.api.write",
        "grantType": "client_credentials",
        "tokenCacheDuration": 1800
      }
    },
    {
      "name": "analytics_service_key",
      "type": "apikey",
      "parameters": {
        "apiKeyName": "X-Analytics-API-Key",
        "apiKeyValue": "${analytics.service.apiKey}",
        "takeFrom": "HEADER"
      }
    }
  ],
  
  "corsProfiles": [
    {
      "name": "enterprise_cors",
      "isDefault": true,
      "origins": [
        "https://app.enterprise.com",
        "https://portal.enterprise.com",
        "https://*.enterprise.com",
        "https://partner.*.enterprise.com"
      ],
      "allowedHeaders": [
        "Authorization",
        "Content-Type",
        "X-API-Key",
        "X-Requested-With",
        "X-Enterprise-Context",
        "X-Request-ID",
        "X-Client-Version",
        "Accept",
        "Accept-Language",
        "Cache-Control"
      ],
      "exposedHeaders": [
        "X-Request-ID",
        "X-Rate-Limit-Limit",
        "X-Rate-Limit-Remaining", 
        "X-Rate-Limit-Reset",
        "X-Response-Time",
        "X-API-Version",
        "X-Content-Version",
        "Link",
        "Location"
      ],
      "supportCredentials": true,
      "maxAgeSeconds": 3600
    },
    {
      "name": "admin_cors",
      "isDefault": false,
      "origins": [
        "https://admin.enterprise.com",
        "https://management.enterprise.com"
      ],
      "allowedHeaders": [
        "Authorization",
        "Content-Type",
        "X-Admin-Token",
        "X-Requested-With"
      ],
      "exposedHeaders": [
        "X-Request-ID",
        "X-Admin-Session-ID"
      ],
      "supportCredentials": true,
      "maxAgeSeconds": 1800
    }
  ],
  
  "caCerts": [
    {
      "certFile": "certificates/enterprise-root-ca.crt",
      "inbound": false,
      "outbound": true,
      "description": "Enterprise Root CA for backend services"
    },
    {
      "certFile": "certificates/backend-service-client.p12",
      "password": "${backend.client.cert.password}",
      "inbound": false,
      "outbound": true,
      "keystoreType": "PKCS12",
      "description": "Client certificate for backend service authentication"
    },
    {
      "certFile": "certificates/partner-ca-bundle.crt", 
      "inbound": true,
      "outbound": false,
      "description": "Partner CA bundle for client certificate validation"
    }
  ],
  
  "applicationQuota": {
    "description": "Per-application rate limiting with method-specific limits",
    "restrictions": [
      {
        "method": "GET",
        "type": "throttle",
        "config": {
          "period": "minute",
          "per": 1,
          "messages": 1000
        }
      },
      {
        "method": "POST,PUT,PATCH",
        "type": "throttle",
        "config": {
          "period": "minute", 
          "per": 1,
          "messages": 200
        }
      },
      {
        "method": "DELETE",
        "type": "throttle",
        "config": {
          "period": "minute",
          "per": 1,
          "messages": 50
        }
      },
      {
        "method": "*",
        "type": "quota",
        "config": {
          "period": "day",
          "per": 1,
          "messages": 100000
        }
      }
    ]
  },
  
  "systemQuota": {
    "description": "System-wide rate limiting and burst protection",
    "restrictions": [
      {
        "method": "*",
        "type": "throttle",
        "config": {
          "period": "second",
          "per": 1,
          "messages": 2000,
          "burstLimit": 5000
        }
      },
      {
        "method": "*",
        "type": "throttle", 
        "config": {
          "period": "hour",
          "per": 1,
          "messages": 1000000
        }
      },
      {
        "method": "POST,PUT,DELETE",
        "type": "throttle",
        "config": {
          "period": "minute",
          "per": 1,
          "messages": 10000
        }
      }
    ]
  },
  
  "clientOrganizations": [
    "Enterprise Solutions",
    "Partner Network", 
    "Internal Applications",
    "Mobile Applications",
    "Third Party Integrators"
  ],
  
  "applications": [
    {
      "name": "Enterprise Web Portal",
      "enabled": true,
      "state": "approved",
      "permissions": ["api.read", "api.write"],
      "appScopes": ["web-application", "user-interface"],
      "customProperties": {
        "applicationTier": "premium",
        "supportContact": "web-team@enterprise.com",
        "deploymentEnvironment": "production",
        "lastSecurityReview": "2024-01-15"
      }
    },
    {
      "name": "Mobile Customer App",
      "enabled": true,
      "state": "approved",
      "permissions": ["api.read"],
      "appScopes": ["mobile-application", "customer-facing"],
      "customProperties": {
        "applicationTier": "standard",
        "supportContact": "mobile-team@enterprise.com",
        "platformSupport": "iOS,Android",
        "minimumVersion": "2.1.0"
      }
    },
    {
      "name": "Partner Integration Service",
      "enabled": true,
      "state": "approved",
      "permissions": ["api.read", "api.write", "partner.access"],
      "appScopes": ["partner-integration", "b2b-service"],
      "customProperties": {
        "applicationTier": "enterprise", 
        "supportContact": "partner-team@enterprise.com",
        "slaLevel": "platinum",
        "dataResidency": "US,EU"
      }
    },
    {
      "name": "Analytics Dashboard",
      "enabled": true,
      "state": "approved",
      "permissions": ["api.read", "analytics.access"],
      "appScopes": ["internal-tool", "analytics"],
      "customProperties": {
        "applicationTier": "internal",
        "supportContact": "analytics-team@enterprise.com",
        "refreshInterval": "real-time",
        "dataRetention": "7-years"
      }
    }
  ],
  
  "methodOverrides": {
    "/customers/{id}": {
      "GET": {
        "outboundProfile": "readOperations",
        "quotaOverride": {
          "throttle": {
            "period": "minute",
            "per": 1,
            "messages": 2000
          }
        }
      },
      "PUT": {
        "outboundProfile": "writeOperations",
        "securityProfile": "admin_only"
      },
      "DELETE": {
        "outboundProfile": "writeOperations",
        "securityProfile": "admin_only"
      }
    },
    "/analytics/*": {
      "*": {
        "outboundProfile": "analyticsOperations",
        "quotaOverride": {
          "throttle": {
            "period": "second",
            "per": 1,
            "messages": 100
          }
        }
      }
    }
  },
  
  "monitoring": {
    "healthCheckEndpoint": "/health",
    "metricsEndpoint": "/metrics",
    "tracingEnabled": true,
    "samplingRate": 0.1,
    "alertingRules": [
      {
        "name": "High Error Rate",
        "condition": "error_rate > 5%",
        "window": "5m",
        "severity": "warning"
      },
      {
        "name": "High Latency",
        "condition": "p95_latency > 1000ms", 
        "window": "5m",
        "severity": "critical"
      }
    ]
  },
  
  "deployment": {
    "strategy": "blue-green",
    "healthCheckGracePeriod": "30s",
    "rollbackOnFailure": true,
    "canaryPercentage": 10,
    "environments": ["development", "staging", "production"],
    "approvalRequired": ["staging", "production"]
  }
}
```

## Usage Examples

### Convert Complete Configuration

```powershell
# Import enhanced module
Import-Module "./scripts/modules/AxwayToApimConverterEnhanced.psm1"

# Convert complete API configuration
$result = Convert-AxwayApiConfiguration `
    -AxwayConfig "./configs/samples/complete-api-config.json" `
    -OutputPath "./output/complete-api" `
    -IncludeInfrastructure

Write-Host "✅ Conversion completed with $($result.ArtifactsGenerated) artifacts"
```

### Deploy Complete Configuration

```powershell
# Deploy using enhanced script
./scripts/Deploy-CompleteAxwayToApim.ps1 `
    -AxwayConfigFile "./configs/samples/complete-api-config.json" `
    -ResourceGroupName "enterprise-rg" `
    -ApimServiceName "enterprise-apim" `
    -OutputPath "./deployment/complete-api" `
    -DeployInfrastructure `
    -BackupExisting
```

### Validate Complete Configuration

```powershell
# Run validation only
./scripts/Deploy-CompleteAxwayToApim.ps1 `
    -AxwayConfigFile "./configs/samples/complete-api-config.json" `
    -ResourceGroupName "enterprise-rg" `
    -ApimServiceName "enterprise-apim" `
    -ValidateOnly
```

## Configuration Schema

The complete API configuration follows this structure:

```mermaid
graph TD
    A[API Configuration] --> B[Basic Settings]
    A --> C[Inbound Security]
    A --> D[Outbound Authentication]
    A --> E[CORS Configuration]
    A --> F[Custom Properties]
    A --> G[Quotas & Rate Limits]
    A --> H[Certificates]
    A --> I[Applications]
    
    C --> C1[Security Profiles]
    C --> C2[Authentication Devices]
    
    D --> D1[Authentication Profiles]
    D --> D2[Outbound Profiles]
    
    G --> G1[Application Quota]
    G --> G2[System Quota]
    
    H --> H1[CA Certificates]
    H --> H2[Client Certificates]
```

This comprehensive configuration demonstrates all aspects of Axway API management and their equivalent implementation in Azure API Management.
