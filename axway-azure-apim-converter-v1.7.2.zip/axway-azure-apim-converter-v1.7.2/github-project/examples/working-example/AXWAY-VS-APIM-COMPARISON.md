# 🔄 Axway to Azure APIM Migration - Comparison Guide

## Overview

This document provides a comprehensive comparison between **Axway API Gateway** configurations and their **Azure API Management (APIM)** converted equivalents. The Conversion Tool transforms Axway JSON configurations into Azure APIM XML policy documents.

---

## 📊 Comparison Summary

| Example | Axway Config | APIM Policy | Auth Type | Key Features |
|---------|--------------|-------------|-----------|--------------|
| Simple API Key | [axway-simple-apikey.json](file:///c:/projects/axway-to-azure-apim-complete-migration-toolkit/github-project/examples/working-example/axway-simple-apikey.json) | [output-simple-apikey-policy.xml](file:///c:/projects/axway-to-azure-apim-complete-migration-toolkit/github-project/examples/working-example/output-simple-apikey-policy.xml) | API Key | Header validation, rate limiting |
| OAuth API | [axway-oauth-api.json](file:///c:/projects/axway-to-azure-apim-complete-migration-toolkit/github-project/examples/working-example/axway-oauth-api.json) | [output-oauth-api-policy.xml](file:///c:/projects/axway-to-azure-apim-complete-migration-toolkit/github-project/examples/working-example/output-oauth-api-policy.xml) | OAuth 2.0 | JWT validation, scope checking |
| Basic Auth | [axway-basic-auth-api.json](file:///c:/projects/axway-to-azure-apim-complete-migration-toolkit/github-project/examples/working-example/axway-basic-auth-api.json) | [output-basic-auth-policy.xml](file:///c:/projects/axway-to-azure-apim-complete-migration-toolkit/github-project/examples/working-example/output-basic-auth-policy.xml) | HTTP Basic | Credential validation, IP-based rate limiting |
| Petstore | [axway-petstore-official.json](file:///c:/projects/axway-to-azure-apim-complete-migration-toolkit/github-project/examples/working-example/axway-petstore-official.json) | [output-petstore-policy.xml](file:///c:/projects/axway-to-azure-apim-complete-migration-toolkit/github-project/examples/working-example/output-petstore-policy.xml) | API Key | Complex quotas, CA certs |

---

## 🔑 Example 1: API Key Authentication

### Axway Configuration

**File:** [axway-simple-apikey.json](file:///c:/projects/axway-to-azure-apim-complete-migration-toolkit/github-project/examples/working-example/axway-simple-apikey.json)

```json
{
    "name": "API-Key secured API",
    "path": "/api/v1/apikey",
    "securityProfiles": [
        {
            "name": "_default",
            "isDefault": true,
            "devices": [
                {
                    "name": "API Key",
                    "type": "apiKey",
                    "properties": {
                        "apiKeyFieldName": "KeyId",
                        "takeFrom": "HEADER",
                        "removeCredentialsOnSuccess": "true"
                    }
                }
            ]
        }
    ]
}
```

**Key Axway Features:**
- 🔹 Security device type: `apiKey`
- 🔹 Header field name: `KeyId`
- 🔹 Credential removal: `true`
- 🔹 Simple declarative configuration

### Azure APIM Policy

**File:** [output-simple-apikey-policy.xml](file:///c:/projects/axway-to-azure-apim-complete-migration-toolkit/github-project/examples/working-example/output-simple-apikey-policy.xml)

```xml
<policies>
    <inbound>
        <base />
        <!-- API Key Authentication -->
        <!-- Validate API key from header -->
        <check-header name="KeyId" failed-check-httpcode="401" 
                     failed-check-error-message="API key is missing or invalid" 
                     ignore-case="false"/>
        
        <set-variable name="apiKey" value="@(context.Request.Headers.GetValueOrDefault("KeyId",""))" />
        
        <!-- Rate limiting per API key -->
        <rate-limit-by-key calls="1000" renewal-period="60" 
                          counter-key="@(context.Request.Headers.GetValueOrDefault("KeyId","anonymous"))" />
        
        <!-- Log authentication event -->
        <trace source="API-Key-Authentication">
            @{
                return string.Format("API Key authentication successful for key: {0}", 
                    ((string)context.Request.Headers.GetValueOrDefault("KeyId","")).Substring(0, 
                    Math.Min(8, ((string)context.Request.Headers.GetValueOrDefault("KeyId","")).Length)) + "***");
            }
        </trace>
        
        <!-- Remove API key from request -->
        <set-header name="KeyId" exists-action="delete" />
        
        <!-- Add authentication context -->
        <set-header name="X-Authenticated" exists-action="override">
            <value>true</value>
        </set-header>
        <set-header name="X-Auth-Method" exists-action="override">
            <value>api-key</value>
        </set-header>
    </inbound>
</policies>
```

**Key APIM Features:**
- ✅ Header validation with `check-header`
- ✅ Rate limiting: 1000 calls/minute per API key
- ✅ Security logging with masked keys
- ✅ Credential removal before backend call
- ✅ Authentication context headers

### 🔄 Transformation Highlights

| Aspect | Axway | Azure APIM |
|--------|-------|------------|
| **Configuration Style** | Declarative JSON | Imperative XML policies |
| **Header Validation** | Implicit via security device | Explicit `check-header` policy |
| **Rate Limiting** | Not in config | Added: 1000 calls/60s |
| **Logging** | Not shown | Added: Masked key logging |
| **Credential Removal** | `removeCredentialsOnSuccess: true` | `set-header exists-action="delete"` |
| **Context Enrichment** | Not shown | Added: `X-Authenticated`, `X-Auth-Method` |

---

## 🔐 Example 2: OAuth 2.0 Authentication

### Axway Configuration

**File:** [axway-oauth-api.json](file:///c:/projects/axway-to-azure-apim-complete-migration-toolkit/github-project/examples/working-example/axway-oauth-api.json)

```json
{
  "name": "orders-api",
  "path": "/orders/v1",
  "securityProfiles": [
    {
      "_default": true,
      "devices": [
        {
          "name": "OAuth 2.0 Authentication",
          "type": "oauth",
          "properties": {
            "providerProfile": "azure-ad-provider",
            "tokenStore": "azure-ad-tokens",
            "scopes": "orders.read orders.write",
            "audience": "api://orders-api",
            "removeCredentialsOnSuccess": false
          }
        }
      ]
    }
  ],
  "corsProfiles": [
    {
      "name": "orders-cors",
      "isDefault": true,
      "origins": ["*"],
      "allowedHeaders": ["Content-Type", "Authorization"],
      "exposedHeaders": ["X-Request-ID"],
      "supportCredentials": false,
      "maxAgeSeconds": 1800
    }
  ]
}
```

**Key Axway Features:**
- 🔹 OAuth provider profile reference
- 🔹 Token store configuration
- 🔹 Scopes: `orders.read orders.write`
- 🔹 Audience validation
- 🔹 CORS configuration

### Azure APIM Policy

**File:** [output-oauth-api-policy.xml](file:///c:/projects/axway-to-azure-apim-complete-migration-toolkit/github-project/examples/working-example/output-oauth-api-policy.xml)

```xml
<policies>
    <inbound>
        <base />
        <!-- OAuth Token Validation -->
        <validate-jwt header-name="Authorization" 
                     failed-validation-httpcode="401" 
                     failed-validation-error-message="Unauthorized. Access token is missing or invalid.">
            <!-- Internal OAuth Configuration -->
            <openid-config url="{{oauth-openid-config-url}}" />
            <audiences>
                <audience>{{oauth-audience}}</audience>
            </audiences>
            <issuers>
                <issuer>{{oauth-issuer}}</issuer>
            </issuers>
            <required-claims>
                <claim name="scope" match="any" separator=" ">
                    <value>orders.read orders.write</value>
                </claim>
            </required-claims>
        </validate-jwt>
        
        <!-- Rate limiting per client -->
        <rate-limit-by-key calls="2000" renewal-period="60" 
                          counter-key="@(((Jwt)context.Variables["validated-jwt"]).Claims.GetValueOrDefault("client_id", "anonymous"))" />
        
        <!-- Extract token claims -->
        <set-variable name="userId" value="@(((Jwt)context.Variables["validated-jwt"]).Claims.GetValueOrDefault("sub", ""))" />
        <set-variable name="clientId" value="@(((Jwt)context.Variables["validated-jwt"]).Claims.GetValueOrDefault("client_id", ""))" />
        <set-variable name="tokenScopes" value="@(((Jwt)context.Variables["validated-jwt"]).Claims.GetValueOrDefault("scope", ""))" />
        
        <!-- Add authentication context -->
        <set-header name="X-User-ID" exists-action="override">
            <value>@((string)context.Variables["userId"])</value>
        </set-header>
        <set-header name="X-Client-ID" exists-action="override">
            <value>@((string)context.Variables["clientId"])</value>
        </set-header>
    </inbound>
</policies>
```

**Key APIM Features:**
- ✅ JWT validation with `validate-jwt`
- ✅ OpenID Connect configuration
- ✅ Audience and issuer validation
- ✅ Scope validation: `orders.read orders.write`
- ✅ Rate limiting: 2000 calls/minute per client
- ✅ Claims extraction (userId, clientId, scopes)
- ✅ Context headers for backend

### 🔄 Transformation Highlights

| Aspect | Axway | Azure APIM |
|--------|-------|------------|
| **OAuth Config** | Provider profile reference | OpenID Connect URL with named values |
| **Token Validation** | Implicit via provider | Explicit `validate-jwt` policy |
| **Scope Checking** | `scopes` property | `required-claims` with `scope` claim |
| **Audience** | `audience` property | `<audiences>` element |
| **Claims Extraction** | Not shown | Explicit extraction to variables |
| **Rate Limiting** | Not in config | Added: 2000 calls/60s per client_id |
| **Context Headers** | Not shown | Added: `X-User-ID`, `X-Client-ID` |

---

## 🔒 Example 3: HTTP Basic Authentication

### Axway Configuration

**File:** [axway-basic-auth-api.json](file:///c:/projects/axway-to-azure-apim-complete-migration-toolkit/github-project/examples/working-example/axway-basic-auth-api.json)

```json
{
    "name": "legacy-inventory-api",
    "path": "/inventory/v1",
    "securityProfiles": [
        {
            "_default": true,
            "devices": [
                {
                    "name": "HTTP Basic Authentication",
                    "type": "http_basic",
                    "properties": {
                        "realm": "Inventory API",
                        "removeCredentialsOnSuccess": true
                    }
                }
            ]
        }
    ],
    "customProperties": {
        "environment": "production",
        "team": "inventory",
        "legacy": "true",
        "migration-target": "oauth"
    }
}
```

**Key Axway Features:**
- 🔹 Security device type: `http_basic`
- 🔹 Realm: `Inventory API`
- 🔹 Credential removal enabled
- 🔹 Custom properties for metadata

### Azure APIM Policy

**File:** [output-basic-auth-policy.xml](file:///c:/projects/axway-to-azure-apim-complete-migration-toolkit/github-project/examples/working-example/output-basic-auth-policy.xml)

```xml
<policies>
    <inbound>
        <base />
        <!-- HTTP Basic Authentication -->
        <choose>
            <when condition="@(context.Request.Headers.GetValueOrDefault("Authorization","") == "")">
                <return-response>
                    <set-status code="401" reason="Unauthorized" />
                    <set-header name="WWW-Authenticate" exists-action="override">
                        <value>Basic realm="Inventory API"</value>
                    </set-header>
                    <set-body>@("Unauthorized")</set-body>
                </return-response>
            </when>
        </choose>
        
        <!-- Validate credentials using Named Values -->
        <authentication-basic username="{{basic-auth-username}}" password="{{basic-auth-password}}" />
        
        <!-- Rate limiting per IP for basic auth -->
        <rate-limit-by-key calls="500" renewal-period="60" 
                          counter-key="@(context.Request.IpAddress)" />
        
        <!-- Remove Authorization header -->
        <set-header name="Authorization" exists-action="delete" />
        
        <!-- Add authentication context -->
        <set-header name="X-Authenticated" exists-action="override">
            <value>true</value>
        </set-header>
        <set-header name="X-Auth-Method" exists-action="override">
            <value>basic</value>
        </set-header>
    </inbound>
</policies>
```

**Key APIM Features:**
- ✅ Authorization header check
- ✅ WWW-Authenticate header with realm
- ✅ Credential validation via named values
- ✅ Rate limiting: 500 calls/minute per IP
- ✅ Credential removal
- ✅ Authentication context headers

### 🔄 Transformation Highlights

| Aspect | Axway | Azure APIM |
|--------|-------|------------|
| **Auth Check** | Implicit | Explicit check with `choose` policy |
| **Realm** | `realm` property | `WWW-Authenticate` header |
| **Credential Storage** | Not shown | Named values (secure) |
| **Rate Limiting** | Not in config | Added: 500 calls/60s per IP |
| **Error Response** | Implicit | Explicit 401 with `return-response` |
| **Credential Removal** | `removeCredentialsOnSuccess: true` | `set-header exists-action="delete"` |

---

## 📦 Example 4: Complex Configuration (Petstore)

### Axway Configuration

**File:** [axway-petstore-official.json](file:///c:/projects/axway-to-azure-apim-complete-migration-toolkit/github-project/examples/working-example/axway-petstore-official.json)

**Key Features:**
- 🔹 API specification reference
- 🔹 Inbound/outbound profiles
- 🔹 Request/response policies
- 🔹 CA certificates (4 certs)
- 🔹 Application quotas (throttling)
- 🔹 System quotas
- 🔹 Client organizations
- 🔹 Application subscriptions

**Quota Configuration:**
```json
{
    "applicationQuota": {
        "restrictions": [
            {
                "method": "*",
                "type": "throttle",
                "config": {
                    "period": "second",
                    "per": 2,
                    "messages": 1000
                }
            }
        ]
    }
}
```

### Azure APIM Policy

**File:** [output-petstore-policy.xml](file:///c:/projects/axway-to-azure-apim-complete-migration-toolkit/github-project/examples/working-example/output-petstore-policy.xml)

The generated policy focuses on the **security profile** (API Key authentication) and adds:
- ✅ Header validation
- ✅ Rate limiting (1000 calls/60s)
- ✅ Security logging
- ✅ Credential removal
- ✅ Authentication context

### 🔄 Transformation Highlights

| Aspect | Axway | Azure APIM |
|--------|-------|------------|
| **Quotas** | Application & system quotas | Converted to rate-limit-by-key |
| **CA Certificates** | 4 outbound certs | Handled separately in APIM backend config |
| **Policies** | Request/response policy names | Not converted (custom logic) |
| **Applications** | Subscription model | Handled via APIM subscriptions |
| **API Spec** | Resource reference | Imported separately via OpenAPI |

> [!NOTE]
> Complex Axway features like custom request/response policies, CA certificates, and application subscriptions require **additional manual configuration** in Azure APIM beyond the generated policy XML.

---

## 🎯 Key Conversion Patterns

### 1. Authentication Mechanisms

| Axway Type | APIM Policy | Notes |
|------------|-------------|-------|
| `apiKey` | `check-header` + `set-variable` | Header validation |
| `oauth` | `validate-jwt` | JWT validation with claims |
| `http_basic` | `authentication-basic` | Credential validation |

### 2. Rate Limiting Strategy

| Axway | APIM |
|-------|------|
| Not typically in config | Always added in conversion |
| - | API Key: 1000 calls/60s per key |
| - | OAuth: 2000 calls/60s per client_id |
| - | Basic Auth: 500 calls/60s per IP |

### 3. Security Enhancements

All converted policies include:
- ✅ **Logging**: Masked credential logging
- ✅ **Error Handling**: Dedicated `on-error` section
- ✅ **Context Headers**: `X-Authenticated`, `X-Auth-Method`
- ✅ **Credential Removal**: Headers deleted before backend call

### 4. Named Values Pattern

APIM policies use **named values** for sensitive configuration:
- `{{oauth-openid-config-url}}`
- `{{oauth-audience}}`
- `{{oauth-issuer}}`
- `{{basic-auth-username}}`
- `{{basic-auth-password}}`

> [!IMPORTANT]
> These named values must be configured in Azure APIM before deploying the policies.

---

## 📋 Migration Checklist

When migrating from Axway to Azure APIM:

### Pre-Migration
- [ ] Review Axway configuration files
- [ ] Identify custom policies and request/response transformations
- [ ] Document CA certificates and backend configurations
- [ ] List all named values needed (OAuth URLs, credentials, etc.)

### Conversion
- [ ] Run Conversion Tool on Axway JSON files
- [ ] Review generated APIM policy XML
- [ ] Verify authentication mechanisms converted correctly
- [ ] Check rate limiting values are appropriate

### Post-Migration
- [ ] Configure named values in Azure APIM
- [ ] Import API specifications (OpenAPI/Swagger)
- [ ] Configure backend services
- [ ] Set up CA certificates if needed
- [ ] Create subscriptions for applications
- [ ] Test authentication flows
- [ ] Validate rate limiting behavior
- [ ] Review logging and monitoring

---

## 🔍 Key Differences

### Configuration Philosophy

| Aspect | Axway | Azure APIM |
|--------|-------|------------|
| **Style** | Declarative, JSON-based | Imperative, XML-based policies |
| **Abstraction** | High-level security devices | Low-level policy expressions |
| **Extensibility** | Custom policies by name | Inline C# expressions |
| **State Management** | Provider profiles, token stores | Named values, policy variables |

### Security Model

| Feature | Axway | Azure APIM |
|---------|-------|------------|
| **API Keys** | Security device with field name | Header check + subscription key |
| **OAuth** | Provider profile reference | OpenID Connect + JWT validation |
| **Basic Auth** | Realm configuration | Named values for credentials |
| **Credential Removal** | Boolean flag | Explicit header deletion |

### Rate Limiting

| Aspect | Axway | Azure APIM |
|--------|-------|------------|
| **Configuration** | Application/system quotas | `rate-limit-by-key` policy |
| **Granularity** | Per application, per API | Per key, per client, per IP |
| **Default Behavior** | Defined in quota config | Added during conversion |

---

## 💡 Best Practices

### 1. Review Generated Policies
Always review the generated APIM policies before deployment. The toolkit provides a solid foundation, but you may need to adjust:
- Rate limiting values
- Error messages
- Logging verbosity
- Context headers

### 2. Configure Named Values First
Before deploying policies, ensure all named values are configured:
```powershell
Set-AzApiManagementNamedValue `
    -Context $apimContext `
    -NamedValueId "oauth-openid-config-url" `
    -Value "https://login.microsoftonline.com/{tenant}/.well-known/openid-configuration" `
    -Secret
```

### 3. Test Incrementally
Test each authentication type separately:
1. Deploy policy
2. Test valid credentials
3. Test invalid credentials
4. Verify rate limiting
5. Check logging

### 4. Monitor and Adjust
Use Azure Monitor to track:
- Authentication failures
- Rate limit hits
- Response times
- Error rates

---

## 🚀 Next Steps

1. **Review Examples**: Study the [working-example](file:///c:/projects/axway-to-azure-apim-complete-migration-toolkit/github-project/examples/working-example) directory
2. **Run Conversion**: Use the PowerShell toolkit to convert your Axway configs
3. **Validate Policies**: Test generated XML in Azure APIM portal
4. **Deploy**: Use the deployment scripts to push policies to Azure
5. **Test**: Validate all authentication flows work as expected

---

## 📚 Additional Resources

- [README.md](file:///c:/projects/axway-to-azure-apim-complete-migration-toolkit/github-project/examples/working-example/README.md) - Complete working example walkthrough
- [PETSTORE-EXAMPLE.md](file:///c:/projects/axway-to-azure-apim-complete-migration-toolkit/github-project/examples/working-example/PETSTORE-EXAMPLE.md) - Detailed Petstore example
- Azure APIM Policy Reference: [Microsoft Docs](https://learn.microsoft.com/en-us/azure/api-management/api-management-policies)

---

**Ready to migrate your Axway APIs to Azure APIM!** 🎉
