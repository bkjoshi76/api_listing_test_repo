# 🚀 Complete Working Example - Axway to Azure APIM Migration

## Overview

This walkthrough demonstrates the **Axway to Azure APIM Conversion Tool** with three realistic API examples:
1. **Customer API** - API Key Authentication
2. **Orders API** - OAuth 2.0 Authentication  
3. **Inventory API** - HTTP Basic Authentication

---

## 📁 Sample Configurations Created

### Example 1: Customer API (API Key)
**File:** [axway-customer-api-apikey.json](file:///c:/projects/axway-to-azure-apim-complete-migration-toolkit/github-project/examples/working-example/axway-customer-api-apikey.json)

**Key Features:**
- ✅ API Key authentication from `X-API-Key` header
- ✅ CORS configuration with multiple origins
- ✅ Application and system-level quotas
- ✅ Custom properties for compliance tracking
- ✅ Rate limiting (1000 requests/hour)

**Configuration Highlights:**
```json
{
  "name": "customer-api",
  "path": "/customers/v1",
  "securityProfiles": [{
    "devices": [{
      "type": "apiKey",
      "properties": {
        "apiKeyFieldName": "X-API-Key",
        "takeFrom": "HEADER"
      }
    }]
  }],
  "customProperties": {
    "compliance": "PCI-DSS",
    "team": "customer-services"
  }
}
```

---

### Example 2: Orders API (OAuth 2.0)
**File:** [axway-oauth-api.json](file:///c:/projects/axway-to-azure-apim-complete-migration-toolkit/github-project/examples/working-example/axway-oauth-api.json)

**Key Features:**
- ✅ OAuth 2.0 with Azure AD integration
- ✅ Token validation with scopes
- ✅ Audience validation
- ✅ CORS enabled for all origins

---

### Example 3: Inventory API (Basic Auth)
**File:** [axway-basic-auth-api.json](file:///c:/projects/axway-to-azure-apim-complete-migration-toolkit/github-project/examples/working-example/axway-basic-auth-api.json)

**Key Features:**
- ✅ HTTP Basic Authentication
- ✅ Legacy system compatibility
- ✅ Migration target flagged for OAuth upgrade

---

## 🔄 Conversion Results

All three configurations were successfully converted using the PowerShell module.

### Generated Outputs

| API | Output File | Size | Features |
|-----|------------|------|----------|
| Customer API | [output-customer-api-policy.xml](file:///c:/projects/axway-to-azure-apim-complete-migration-toolkit/github-project/examples/working-example/output-customer-api-policy.xml) | 2.2 KB | API Key validation, rate limiting, logging |
| Orders API | [output-oauth-api-policy.xml](file:///c:/projects/axway-to-azure-apim-complete-migration-toolkit/github-project/examples/working-example/output-oauth-api-policy.xml) | 3.5 KB | JWT validation, scope checking, Azure AD |
| Inventory API | [output-basic-auth-policy.xml](file:///c:/projects/axway-to-azure-apim-complete-migration-toolkit/github-project/examples/working-example/output-basic-auth-policy.xml) | 2.3 KB | Basic auth, credential removal, logging |

---

## 📊 Generated Policy Analysis

### API Key Policy Features

The generated APIM policy includes:
- ✅ **Header validation** - Checks for `X-API-Key` header
- ✅ **Rate limiting** - 1000 calls/minute per API key
- ✅ **Security logging** - Masked key logging
- ✅ **Credential removal** - API key removed before backend call
- ✅ **Context headers** - Adds authentication metadata

---

## 🚀 Deployment Instructions

### Step 1: Validate the Generated Policies

```powershell
Test-ApimPolicyValidation `
    -PolicyXml (Get-Content "output-customer-api-policy.xml" -Raw) `
    -ValidationLevel "Comprehensive"
```

### Step 2: Deploy to Azure APIM

```powershell
Deploy-ApimSecurityPolicy `
    -ResourceGroupName "your-resource-group" `
    -ApimServiceName "your-apim-service" `
    -ApiId "customer-api-v1" `
    -PolicyXml (Get-Content "output-customer-api-policy.xml" -Raw) `
    -BackupExisting
```

---

## 📝 Sample Test Requests

### Testing Customer API (API Key)

```bash
# Valid request
curl -X GET https://your-apim.azure-api.net/customers/v1/123 \
  -H "X-API-Key: your-subscription-key"

# Expected: 200 OK
```

---

## 🎉 Conclusion

This working example demonstrates the **complete end-to-end migration** from Axway API Gateway to Azure API Management:

- ✅ **Realistic configurations** covering common scenarios
- ✅ **Automated conversion** using PowerShell toolkit
- ✅ **Production-ready policies** with security and performance optimizations
- ✅ **Complete documentation** for deployment and testing

**You're ready to migrate your Axway APIs to Azure APIM!** 🚀
