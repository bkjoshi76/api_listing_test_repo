/**
 * Main application entry point
 */

import { convertAxwayToApim, generateDeploymentCommands } from './js/converter.js';
import { getExample } from './js/examples.js';

// Application state
let currentConfig = null;
let currentResult = null;

// DOM Elements
const elements = {
    configInput: null,
    securityTypeSelect: null,
    includeRateLimitCheckbox: null,
    includeLoggingCheckbox: null,
    removeCredentialsCheckbox: null,
    convertBtn: null,
    statusMessage: null,
    outputSection: null,
    policyOutput: null,
    uploadFileBtn: null,
    fileInput: null,
    loadExampleBtn: null,
    exampleModal: null,
    closeModal: null,
    copyPolicyBtn: null,
    downloadPolicyBtn: null,
    themeToggle: null,
    toast: null
};

/**
 * Initialize application
 */
function init() {
    // Get DOM elements
    elements.configInput = document.getElementById('axway-config-input');
    elements.securityTypeSelect = document.getElementById('security-type');
    elements.includeRateLimitCheckbox = document.getElementById('include-rate-limit');
    elements.includeLoggingCheckbox = document.getElementById('include-logging');
    elements.removeCredentialsCheckbox = document.getElementById('remove-credentials');
    elements.convertBtn = document.getElementById('convert-btn');
    elements.statusMessage = document.getElementById('status-message');
    elements.outputSection = document.getElementById('output-section');
    elements.policyOutput = document.getElementById('policy-output');
    elements.uploadFileBtn = document.getElementById('upload-file-btn');
    elements.fileInput = document.getElementById('file-input');
    elements.loadExampleBtn = document.getElementById('load-example-btn');
    elements.exampleModal = document.getElementById('example-modal');
    elements.closeModal = document.getElementById('close-modal');
    elements.copyPolicyBtn = document.getElementById('copy-policy-btn');
    elements.downloadPolicyBtn = document.getElementById('download-policy-btn');
    elements.themeToggle = document.getElementById('theme-toggle');
    elements.toast = document.getElementById('toast');

    // Setup event listeners
    setupEventListeners();

    // Initialize theme
    initializeTheme();

    console.log('Application initialized');
}

/**
 * Setup event listeners
 */
function setupEventListeners() {
    // Convert button
    elements.convertBtn.addEventListener('click', handleConvert);

    // Upload file
    elements.uploadFileBtn.addEventListener('click', () => elements.fileInput.click());
    elements.fileInput.addEventListener('change', handleFileUpload);

    // Load example
    elements.loadExampleBtn.addEventListener('click', () => {
        elements.exampleModal.classList.add('active');
    });

    // Close modal
    elements.closeModal.addEventListener('click', () => {
        elements.exampleModal.classList.remove('active');
    });

    // Example cards
    document.querySelectorAll('.example-card').forEach(card => {
        card.addEventListener('click', (e) => {
            const exampleKey = e.currentTarget.dataset.example;
            loadExample(exampleKey);
            elements.exampleModal.classList.remove('active');
        });
    });

    // Copy policy
    elements.copyPolicyBtn.addEventListener('click', handleCopyPolicy);

    // Download policy
    elements.downloadPolicyBtn.addEventListener('click', handleDownloadPolicy);

    // Theme toggle
    elements.themeToggle.addEventListener('click', toggleTheme);

    // Tab switching
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const tabName = e.target.dataset.tab;
            switchTab(tabName);
        });
    });

    // Close modal on outside click
    elements.exampleModal.addEventListener('click', (e) => {
        if (e.target === elements.exampleModal) {
            elements.exampleModal.classList.remove('active');
        }
    });
}

/**
 * Handle convert button click
 */
function handleConvert() {
    try {
        // Get input
        const configText = elements.configInput.value.trim();
        if (!configText) {
            showStatus('Please enter an Axway configuration', 'error');
            return;
        }

        // Parse JSON
        let config;
        try {
            config = JSON.parse(configText);
        } catch (e) {
            showStatus('Invalid JSON format. Please check your configuration.', 'error');
            return;
        }

        // Get options
        const options = {
            securityType: elements.securityTypeSelect.value,
            includeRateLimit: elements.includeRateLimitCheckbox.checked,
            includeLogging: elements.includeLoggingCheckbox.checked,
            removeCredentials: elements.removeCredentialsCheckbox.checked
        };

        // Convert
        showStatus('Converting configuration...', 'info');
        const result = convertAxwayToApim(config, options);

        if (result.success) {
            currentConfig = config; // Store original config for comparison
            currentResult = result;
            displayResult(result);
            showStatus('Conversion successful!', 'success');
            showToast('Policy generated successfully!', 'success');
        } else {
            showStatus(`Conversion failed: ${result.error}`, 'error');
            showToast('Conversion failed', 'error');
        }
    } catch (error) {
        console.error('Conversion error:', error);
        showStatus(`Error: ${error.message}`, 'error');
        showToast('An error occurred', 'error');
    }
}

/**
 * Display conversion result
 */
function displayResult(result) {
    // Show output section
    elements.outputSection.style.display = 'block';

    // Display policy XML
    elements.policyOutput.textContent = result.policyXml;

    // Highlight syntax
    if (window.Prism) {
        Prism.highlightElement(elements.policyOutput);
    }

    // Populate comparison view
    if (currentConfig) {
        const originalConfigOutput = document.getElementById('original-config-output');
        const convertedPolicyOutput = document.getElementById('converted-policy-output');

        // Display original Axway config (formatted JSON)
        originalConfigOutput.textContent = JSON.stringify(currentConfig, null, 2);

        // Display converted APIM policy
        convertedPolicyOutput.textContent = result.policyXml;

        // Apply syntax highlighting
        if (window.Prism) {
            Prism.highlightElement(originalConfigOutput);
            Prism.highlightElement(convertedPolicyOutput);
        }
    }

    // Update metadata
    document.getElementById('meta-security-type').textContent = result.securityType.toUpperCase();
    document.getElementById('meta-api-name').textContent = result.metadata.apiName;
    document.getElementById('meta-rate-limit').textContent = result.metadata.options.includeRateLimit ? 'Enabled' : 'Disabled';
    document.getElementById('meta-logging').textContent = result.metadata.options.includeLogging ? 'Enabled' : 'Disabled';
    document.getElementById('meta-timestamp').textContent = new Date(result.metadata.convertedAt).toLocaleString();

    // Generate deployment commands
    const deploymentCommands = generateDeploymentCommands(result.metadata.apiName, result.securityType);
    const deploymentCodeBlock = document.getElementById('deployment-commands');
    deploymentCodeBlock.textContent = deploymentCommands;

    if (window.Prism) {
        Prism.highlightElement(deploymentCodeBlock);
    }

    // Scroll to output
    elements.outputSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

/**
 * Handle file upload
 */
function handleFileUpload(e) {
    const file = e.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
        try {
            const config = JSON.parse(event.target.result);
            elements.configInput.value = JSON.stringify(config, null, 2);
            showToast('File loaded successfully', 'success');
        } catch (error) {
            showToast('Invalid JSON file', 'error');
        }
    };
    reader.readAsText(file);
}

/**
 * Load example configuration
 */
function loadExample(key) {
    const example = getExample(key);
    if (example) {
        elements.configInput.value = JSON.stringify(example.config, null, 2);
        showToast(`Loaded: ${example.name}`, 'success');
    }
}

/**
 * Handle copy policy
 */
async function handleCopyPolicy() {
    if (!currentResult) return;

    try {
        await navigator.clipboard.writeText(currentResult.policyXml);
        showToast('Policy copied to clipboard!', 'success');
    } catch (error) {
        showToast('Failed to copy', 'error');
    }
}

/**
 * Handle download policy
 */
function handleDownloadPolicy() {
    if (!currentResult) return;

    const blob = new Blob([currentResult.policyXml], { type: 'application/xml' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'apim-policy.xml';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    showToast('Policy downloaded!', 'success');
}

/**
 * Switch tabs
 */
function switchTab(tabName) {
    // Update tab buttons
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.classList.remove('active');
        if (btn.dataset.tab === tabName) {
            btn.classList.add('active');
        }
    });

    // Update tab content
    document.querySelectorAll('.tab-content').forEach(content => {
        content.classList.remove('active');
    });
    document.getElementById(`tab-${tabName}`).classList.add('active');
}

/**
 * Show status message
 */
function showStatus(message, type = 'info') {
    elements.statusMessage.textContent = message;
    elements.statusMessage.className = `status-message ${type}`;
    elements.statusMessage.style.display = 'block';
}

/**
 * Show toast notification
 */
function showToast(message, type = 'success') {
    elements.toast.textContent = message;
    elements.toast.className = `toast ${type} show`;

    setTimeout(() => {
        elements.toast.classList.remove('show');
    }, 3000);
}

/**
 * Initialize theme
 */
function initializeTheme() {
    const savedTheme = localStorage.getItem('theme') || 'light';
    document.documentElement.setAttribute('data-theme', savedTheme);
    updateThemeIcon(savedTheme);
}

/**
 * Toggle theme
 */
function toggleTheme() {
    const currentTheme = document.documentElement.getAttribute('data-theme');
    const newTheme = currentTheme === 'dark' ? 'light' : 'dark';

    document.documentElement.setAttribute('data-theme', newTheme);
    localStorage.setItem('theme', newTheme);
    updateThemeIcon(newTheme);
}

/**
 * Update theme icon
 */
function updateThemeIcon(theme) {
    const icon = elements.themeToggle.querySelector('.icon');
    icon.textContent = theme === 'dark' ? '☀️' : '🌙';
}

// Initialize when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
} else {
    init();
}
