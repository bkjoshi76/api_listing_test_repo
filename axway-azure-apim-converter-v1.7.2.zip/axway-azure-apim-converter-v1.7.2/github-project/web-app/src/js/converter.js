/**
 * Axway to Azure APIM Converter
 * Core conversion engine ported from PowerShell module
 */

/**
 * Main conversion function
 * @param {Object} axwayConfig - Axway configuration object
 * @param {Object} options - Conversion options
 * @returns {Object} Conversion result with policy XML and metadata
 */
export function convertAxwayToApim(axwayConfig, options = {}) {
    try {
        // Parse configuration
        const config = parseAxwayConfig(axwayConfig);
        
        // Detect or use specified security type
        const securityType = options.securityType === 'auto' 
            ? detectSecurityType(config) 
            : options.securityType;
        
        // Generate policy based on type
        let policyXml;
        switch (securityType) {
            case 'apikey':
                policyXml = generateApiKeyPolicy(config, options);
                break;
            case 'oauth':
                policyXml = generateOAuthPolicy(config, options);
                break;
            case 'basic':
                policyXml = generateBasicAuthPolicy(config, options);
                break;
            case 'aws':
                policyXml = generateAwsSignaturePolicy(config, options);
                break;
            case 'passthrough':
                policyXml = generatePassthroughPolicy(config, options);
                break;
            case 'custom':
                policyXml = generateCustomAuthPolicy(config, options);
                break;
            default:
                throw new Error(`Unsupported security type: ${securityType}`);
        }
        
        return {
            success: true,
            securityType,
            policyXml,
            metadata: {
                apiName: config.name || 'Unknown API',
                convertedAt: new Date().toISOString(),
                options: options
            }
        };
    } catch (error) {
        return {
            success: false,
            error: error.message
        };
    }
}

/**
 * Parse Axway configuration
 */
function parseAxwayConfig(config) {
    // Handle security profiles structure
    if (config.securityProfiles && Array.isArray(config.securityProfiles)) {
        const defaultProfile = config.securityProfiles.find(p => p.isDefault || p.name === '_default') 
            || config.securityProfiles[0];
        
        if (!defaultProfile || !defaultProfile.devices || defaultProfile.devices.length === 0) {
            throw new Error('Security profile must contain at least one device');
        }
        
        const primaryDevice = defaultProfile.devices[0];
        
        return {
            ...config,
            type: primaryDevice.type,
            deviceName: primaryDevice.name,
            properties: primaryDevice.properties || {},
            profileName: defaultProfile.name
        };
    }
    
    return config;
}

/**
 * Detect security type from configuration
 */
function detectSecurityType(config) {
    const typeMapping = {
        'apiKey': 'apikey',
        'oauth': 'oauth',
        'oauthExternal': 'oauth',
        'httpBasic': 'basic',
        'awsSigning': 'aws',
        'authPolicy': 'custom',
        'passthrough': 'passthrough'
    };
    
    return typeMapping[config.type] || 'custom';
}

/**
 * Generate API Key policy
 */
export function generateApiKeyPolicy(config, options = {}) {
    const keyFieldName = config.properties?.apiKeyFieldName || 'KeyId';
    const takeFrom = config.properties?.takeFrom || 'HEADER';
    const removeCredentials = options.removeCredentials !== false;
    const includeRateLimit = options.includeRateLimit !== false;
    const includeLogging = options.includeLogging !== false;
    
    const rateLimitPolicy = includeRateLimit ? `
        <!-- Rate limiting per API key -->
        <rate-limit-by-key calls="1000" renewal-period="60" 
                          counter-key="@(context.Request.Headers.GetValueOrDefault(&quot;${keyFieldName}&quot;,&quot;anonymous&quot;))" />
` : '';
    
    const loggingPolicy = includeLogging ? `
        <!-- Log authentication event -->
        <trace source="API-Key-Authentication">
            @{
                return string.Format("API Key authentication successful for key: {0}", 
                    ((string)context.Request.Headers.GetValueOrDefault("${keyFieldName}","")).Substring(0, 
                    Math.Min(8, ((string)context.Request.Headers.GetValueOrDefault("${keyFieldName}","")).Length)) + "***");
            }
        </trace>
` : '';
    
    const removeCredentialsPolicy = removeCredentials ? `
        <!-- Remove API key from request -->
        <set-header name="${keyFieldName}" exists-action="delete" />
` : '';
    
    const validation = takeFrom === 'QUERY' ? `
        <!-- Validate API key from query parameter -->
        <choose>
            <when condition="@(context.Request.Url.Query.GetValueOrDefault(&quot;${keyFieldName}&quot;, &quot;&quot;) == &quot;&quot;)">
                <return-response>
                    <set-status code="401" reason="Unauthorized" />
                    <set-body>@("API key is required in query parameter: ${keyFieldName}")</set-body>
                </return-response>
            </when>
        </choose>
        
        <set-variable name="apiKey" value="@(context.Request.Url.Query.GetValueOrDefault(&quot;${keyFieldName}&quot;,&quot;&quot;))" />
` : `
        <!-- Validate API key from header -->
        <check-header name="${keyFieldName}" failed-check-httpcode="401" 
                     failed-check-error-message="API key is missing or invalid" 
                     ignore-case="false"/>
        
        <set-variable name="apiKey" value="@(context.Request.Headers.GetValueOrDefault(&quot;${keyFieldName}&quot;,&quot;&quot;))" />
`;
    
    return `<policies>
    <inbound>
        <base />
        <!-- API Key Authentication -->
        ${validation}
        ${rateLimitPolicy}
        ${loggingPolicy}
        ${removeCredentialsPolicy}
        
        <!-- Add authentication context -->
        <set-header name="X-Authenticated" exists-action="override">
            <value>true</value>
        </set-header>
        <set-header name="X-Auth-Method" exists-action="override">
            <value>api-key</value>
        </set-header>
    </inbound>
    <backend>
        <base />
    </backend>
    <outbound>
        <base />
        <!-- Remove internal headers -->
        <set-header name="X-Authenticated" exists-action="delete" />
        <set-header name="X-Auth-Method" exists-action="delete" />
    </outbound>
    <on-error>
        <base />
        <!-- Log authentication failures -->
        <trace source="API-Key-Authentication-Error">
            @{
                return string.Format("API Key authentication failed from IP: {0}, Path: {1}", 
                    context.Request.IpAddress, context.Request.Url.Path);
            }
        </trace>
    </on-error>
</policies>`;
}

/**
 * Generate OAuth policy
 */
export function generateOAuthPolicy(config, options = {}) {
    const isExternal = config.type === 'oauthExternal';
    const removeCredentials = options.removeCredentials !== false;
    const includeRateLimit = options.includeRateLimit !== false;
    const includeLogging = options.includeLogging !== false;
    
    const externalValidation = isExternal ? `
        <!-- External OAuth Provider Configuration -->
        <!-- Update these Named Values in APIM -->
        <openid-config url="{{oauth-external-openid-config}}" />
        <audiences>
            <audience>{{oauth-external-audience}}</audience>
        </audiences>
        <issuers>
            <issuer>{{oauth-external-issuer}}</issuer>
        </issuers>
` : `
        <!-- Internal OAuth Configuration -->
        <openid-config url="{{oauth-openid-config-url}}" />
        <audiences>
            <audience>{{oauth-audience}}</audience>
        </audiences>
        <issuers>
            <issuer>{{oauth-issuer}}</issuer>
        </issuers>
`;
    
    const rateLimitPolicy = includeRateLimit ? `
        <!-- Rate limiting per client -->
        <rate-limit-by-key calls="2000" renewal-period="60" 
                          counter-key="@(((Jwt)context.Variables[&quot;validated-jwt&quot;]).Claims.GetValueOrDefault(&quot;client_id&quot;, &quot;anonymous&quot;))" />
` : '';
    
    const loggingPolicy = includeLogging ? `
        <!-- Log OAuth authentication event -->
        <trace source="OAuth-Authentication">
            @{
                return string.Format("OAuth authentication successful for user: {0}, client: {1}", 
                    ((Jwt)context.Variables["validated-jwt"]).Claims.GetValueOrDefault("sub", "unknown"),
                    ((Jwt)context.Variables["validated-jwt"]).Claims.GetValueOrDefault("client_id", "unknown"));
            }
        </trace>
` : '';
    
    const removeCredentialsPolicy = removeCredentials ? `
        <!-- Remove Authorization header -->
        <set-header name="Authorization" exists-action="delete" />
` : '';
    
    return `<policies>
    <inbound>
        <base />
        <!-- OAuth Token Validation -->
        <validate-jwt header-name="Authorization" 
                     failed-validation-httpcode="401" 
                     failed-validation-error-message="Unauthorized. Access token is missing or invalid.">
            ${externalValidation}
            <required-claims>
                <claim name="scope" match="any" separator=" ">
                    <value>api.read</value>
                    <value>api.write</value>
                </claim>
            </required-claims>
        </validate-jwt>
        ${rateLimitPolicy}
        
        <!-- Extract token claims -->
        <set-variable name="userId" value="@(((Jwt)context.Variables[&quot;validated-jwt&quot;]).Claims.GetValueOrDefault(&quot;sub&quot;, &quot;&quot;))" />
        <set-variable name="clientId" value="@(((Jwt)context.Variables[&quot;validated-jwt&quot;]).Claims.GetValueOrDefault(&quot;client_id&quot;, &quot;&quot;))" />
        ${loggingPolicy}
        ${removeCredentialsPolicy}
        
        <!-- Add authentication context -->
        <set-header name="X-Authenticated" exists-action="override">
            <value>true</value>
        </set-header>
        <set-header name="X-Auth-Method" exists-action="override">
            <value>oauth</value>
        </set-header>
        <set-header name="X-User-ID" exists-action="override">
            <value>@((string)context.Variables["userId"])</value>
        </set-header>
    </inbound>
    <backend>
        <base />
    </backend>
    <outbound>
        <base />
        <!-- Remove internal headers -->
        <set-header name="X-Authenticated" exists-action="delete" />
        <set-header name="X-Auth-Method" exists-action="delete" />
        <set-header name="X-User-ID" exists-action="delete" />
    </outbound>
    <on-error>
        <base />
        <!-- Log OAuth failures -->
        <trace source="OAuth-Authentication-Error">
            @{
                return string.Format("OAuth authentication failed from IP: {0}, Error: {1}", 
                    context.Request.IpAddress, context.LastError?.Message ?? "Unknown error");
            }
        </trace>
    </on-error>
</policies>`;
}

/**
 * Generate Basic Auth policy
 */
export function generateBasicAuthPolicy(config, options = {}) {
    const realm = config.properties?.realm || 'API Access';
    const removeCredentials = options.removeCredentials !== false;
    const includeRateLimit = options.includeRateLimit !== false;
    const includeLogging = options.includeLogging !== false;
    
    const rateLimitPolicy = includeRateLimit ? `
        <!-- Rate limiting per IP for basic auth -->
        <rate-limit-by-key calls="500" renewal-period="60" 
                          counter-key="@(context.Request.IpAddress)" />
` : '';
    
    const loggingPolicy = includeLogging ? `
        <!-- Log basic auth event -->
        <trace source="Basic-Authentication">
            @{
                return string.Format("Basic authentication successful from IP: {0}", 
                    context.Request.IpAddress);
            }
        </trace>
` : '';
    
    const removeCredentialsPolicy = removeCredentials ? `
        <!-- Remove Authorization header -->
        <set-header name="Authorization" exists-action="delete" />
` : '';
    
    return `<policies>
    <inbound>
        <base />
        <!-- HTTP Basic Authentication -->
        <choose>
            <when condition="@(context.Request.Headers.GetValueOrDefault(&quot;Authorization&quot;,&quot;&quot;) == &quot;&quot;)">
                <return-response>
                    <set-status code="401" reason="Unauthorized" />
                    <set-header name="WWW-Authenticate" exists-action="override">
                        <value>Basic realm="${realm}"</value>
                    </set-header>
                    <set-body>@("Unauthorized")</set-body>
                </return-response>
            </when>
        </choose>
        
        <!-- Validate credentials using Named Values -->
        <authentication-basic username="{{basic-auth-username}}" password="{{basic-auth-password}}" />
        ${rateLimitPolicy}
        ${loggingPolicy}
        ${removeCredentialsPolicy}
        
        <!-- Add authentication context -->
        <set-header name="X-Authenticated" exists-action="override">
            <value>true</value>
        </set-header>
        <set-header name="X-Auth-Method" exists-action="override">
            <value>basic</value>
        </set-header>
    </inbound>
    <backend>
        <base />
    </backend>
    <outbound>
        <base />
        <!-- Remove internal headers -->
        <set-header name="X-Authenticated" exists-action="delete" />
        <set-header name="X-Auth-Method" exists-action="delete" />
    </outbound>
    <on-error>
        <base />
        <!-- Log basic auth failures -->
        <trace source="Basic-Authentication-Error">
            @{
                return string.Format("Basic authentication failed from IP: {0}", 
                    context.Request.IpAddress);
            }
        </trace>
    </on-error>
</policies>`;
}

/**
 * Generate Passthrough policy (no authentication)
 */
export function generatePassthroughPolicy(config, options = {}) {
    const includeRateLimit = options.includeRateLimit !== false;
    const includeLogging = options.includeLogging !== false;
    
    const rateLimitPolicy = includeRateLimit ? `
        <!-- Rate limiting for anonymous access -->
        <rate-limit-by-key calls="100" renewal-period="60" 
                          counter-key="@(context.Request.IpAddress)" />
` : '';
    
    const loggingPolicy = includeLogging ? `
        <!-- Log passthrough access -->
        <trace source="Passthrough-Access">
            @{
                return string.Format("Passthrough access from IP: {0}, Path: {1}", 
                    context.Request.IpAddress, context.Request.Url.Path);
            }
        </trace>
` : '';
    
    return `<policies>
    <inbound>
        <base />
        <!-- Passthrough - No authentication required -->
        ${rateLimitPolicy}
        ${loggingPolicy}
        
        <!-- Add context header -->
        <set-header name="X-Auth-Method" exists-action="override">
            <value>passthrough</value>
        </set-header>
    </inbound>
    <backend>
        <base />
    </backend>
    <outbound>
        <base />
        <!-- Remove internal headers -->
        <set-header name="X-Auth-Method" exists-action="delete" />
    </outbound>
    <on-error>
        <base />
    </on-error>
</policies>`;
}

/**
 * Generate AWS Signature policy
 */
export function generateAwsSignaturePolicy(config, options = {}) {
    return `<policies>
    <inbound>
        <base />
        <!-- AWS Signature Version 4 Validation -->
        <!-- Note: This is a simplified validation. For production, consider external validation service -->
        
        <set-variable name="authHeader" value="@(context.Request.Headers.GetValueOrDefault(&quot;Authorization&quot;,&quot;&quot;))" />
        <set-variable name="dateHeader" value="@(context.Request.Headers.GetValueOrDefault(&quot;X-Amz-Date&quot;,&quot;&quot;))" />
        
        <!-- Validate required headers -->
        <choose>
            <when condition="@(string.IsNullOrEmpty((string)context.Variables[&quot;authHeader&quot;]) || string.IsNullOrEmpty((string)context.Variables[&quot;dateHeader&quot;]))">
                <return-response>
                    <set-status code="401" reason="Unauthorized" />
                    <set-body>@("AWS signature headers missing")</set-body>
                </return-response>
            </when>
        </choose>
        
        <!-- Add authentication context -->
        <set-header name="X-Auth-Method" exists-action="override">
            <value>aws-signature</value>
        </set-header>
    </inbound>
    <backend>
        <base />
    </backend>
    <outbound>
        <base />
        <set-header name="X-Auth-Method" exists-action="delete" />
    </outbound>
    <on-error>
        <base />
    </on-error>
</policies>`;
}

/**
 * Generate Custom Auth policy
 */
export function generateCustomAuthPolicy(config, options = {}) {
    return `<policies>
    <inbound>
        <base />
        <!-- Custom Authentication Policy -->
        <!-- Calls external authentication service for validation -->
        
        <set-variable name="customToken" value="@(context.Request.Headers.GetValueOrDefault(&quot;X-Custom-Token&quot;,&quot;&quot;))" />
        
        <choose>
            <when condition="@(string.IsNullOrEmpty((string)context.Variables[&quot;customToken&quot;]))">
                <return-response>
                    <set-status code="401" reason="Unauthorized" />
                    <set-body>@("Custom authentication token is required")</set-body>
                </return-response>
            </when>
        </choose>
        
        <!-- Call external authentication service -->
        <send-request mode="new" response-variable-name="authValidation" timeout="20" ignore-error="false">
            <set-url>{{custom-auth-service-url}}</set-url>
            <set-method>POST</set-method>
            <set-header name="Content-Type" exists-action="override">
                <value>application/json</value>
            </set-header>
            <set-body>@{
                var token = (string)context.Variables["customToken"];
                return JsonConvert.SerializeObject(new { 
                    token = token,
                    apiPath = context.Request.Url.Path,
                    method = context.Request.Method
                });
            }</set-body>
        </send-request>
        
        <!-- Validate authentication response -->
        <choose>
            <when condition="@(((IResponse)context.Variables[&quot;authValidation&quot;]).StatusCode != 200)">
                <return-response>
                    <set-status code="401" reason="Unauthorized" />
                    <set-body>@("Authentication failed")</set-body>
                </return-response>
            </when>
        </choose>
        
        <!-- Add authentication context -->
        <set-header name="X-Auth-Method" exists-action="override">
            <value>custom</value>
        </set-header>
    </inbound>
    <backend>
        <base />
    </backend>
    <outbound>
        <base />
        <set-header name="X-Auth-Method" exists-action="delete" />
    </outbound>
    <on-error>
        <base />
    </on-error>
</policies>`;
}

/**
 * Generate deployment commands
 */
export function generateDeploymentCommands(apiName, securityType) {
    const apiId = apiName.toLowerCase().replace(/\s+/g, '-');
    
    return `# Step 1: Create API in Azure APIM
az apim api create \\
  --service-name "your-apim" \\
  --resource-group "your-rg" \\
  --api-id "${apiId}" \\
  --path "/api/v1" \\
  --display-name "${apiName}" \\
  --protocols "https" \\
  --subscription-required true

# Step 2: Deploy the Security Policy
az apim api policy create \\
  --resource-group "your-rg" \\
  --service-name "your-apim" \\
  --api-id "${apiId}" \\
  --xml-file "apim-policy.xml"

# Step 3: Test the API
curl -X GET "https://your-apim.azure-api.net/api/v1/test" \\
  -H "Ocp-Apim-Subscription-Key: your-subscription-key" \\
  -v`;
}
