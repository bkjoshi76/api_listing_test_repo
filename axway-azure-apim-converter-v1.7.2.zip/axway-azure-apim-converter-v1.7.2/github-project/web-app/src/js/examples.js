/**
 * Example Axway configurations for testing
 */

export const examples = {
    petstore: {
        name: "Petstore API Key",
        description: "Official Swagger Petstore with custom API key authentication",
        config: {
            "name": "petstore3",
            "path": "/api/v3",
            "state": "published",
            "version": "1.0.17",
            "organization": "orga",
            "backendBasepath": "https://petstore3.swagger.io",
            "securityProfiles": [
                {
                    "name": "_default",
                    "isDefault": true,
                    "devices": [
                        {
                            "name": "API Key",
                            "type": "apiKey",
                            "order": 1,
                            "properties": {
                                "apiKeyFieldName": "KeyId",
                                "takeFrom": "HEADER",
                                "removeCredentialsOnSuccess": true
                            }
                        }
                    ]
                }
            ],
            "customProperties": {
                "customProperty1": "public",
                "customProperty4": "true"
            }
        }
    },

    oauth: {
        name: "OAuth 2.0 External",
        description: "External OAuth provider with JWT validation",
        config: {
            "name": "orders-api",
            "path": "/orders/v1",
            "state": "published",
            "version": "v1",
            "organization": "Production",
            "backendBasepath": "https://backend.example.com/api/orders",
            "securityProfiles": [
                {
                    "name": "_default",
                    "isDefault": true,
                    "devices": [
                        {
                            "name": "OAuth 2.0 Authentication",
                            "type": "oauthExternal",
                            "order": 1,
                            "properties": {
                                "providerProfile": "azure-ad-provider",
                                "tokenStore": "azure-ad-tokens",
                                "scopes": "orders.read orders.write",
                                "audience": "api://orders-api",
                                "removeCredentialsOnSuccess": false
                            }
                        }
                    ]
                }
            ],
            "customProperties": {
                "environment": "production",
                "team": "order-processing",
                "security-level": "high"
            }
        }
    },

    basic: {
        name: "HTTP Basic Auth",
        description: "Simple username/password authentication",
        config: {
            "name": "internal-api",
            "path": "/internal/v1",
            "state": "published",
            "version": "1.0",
            "organization": "Internal",
            "backendBasepath": "https://internal.example.com/api",
            "securityProfiles": [
                {
                    "name": "_default",
                    "isDefault": true,
                    "devices": [
                        {
                            "name": "HTTP Basic Authentication",
                            "type": "httpBasic",
                            "order": 1,
                            "properties": {
                                "realm": "Internal API Access",
                                "removeCredentialsOnSuccess": true
                            }
                        }
                    ]
                }
            ]
        }
    },

    passthrough: {
        name: "Passthrough (No Auth)",
        description: "Public API with no authentication",
        config: {
            "name": "public-api",
            "path": "/public/v1",
            "state": "published",
            "version": "1.0",
            "organization": "Public",
            "backendBasepath": "https://public.example.com/api",
            "securityProfiles": [
                {
                    "name": "_default",
                    "isDefault": true,
                    "devices": [
                        {
                            "name": "No Authentication",
                            "type": "passthrough",
                            "order": 1,
                            "properties": {}
                        }
                    ]
                }
            ]
        }
    },

    simpleApiKey: {
        name: "Simple API Key",
        description: "Minimal API key configuration",
        config: {
            "name": "API-Key secured API",
            "path": "/api/v1/apikey",
            "state": "unpublished",
            "version": "1.0.0",
            "organization": "API Development",
            "securityProfiles": [
                {
                    "name": "_default",
                    "isDefault": true,
                    "devices": [
                        {
                            "name": "API Key",
                            "type": "apiKey",
                            "order": 0,
                            "properties": {
                                "apiKeyFieldName": "KeyId",
                                "takeFrom": "HEADER",
                                "removeCredentialsOnSuccess": "true"
                            }
                        }
                    ]
                }
            ]
        }
    },

    customerApi: {
        name: "Customer API (Advanced)",
        description: "Full-featured customer API with CORS and quotas",
        config: {
            "name": "customer-api",
            "path": "/customers/v1",
            "state": "published",
            "version": "v1",
            "organization": "Production",
            "backendBasepath": "https://backend.example.com/api/customers",
            "descriptionManual": "Customer Management API - Provides CRUD operations for customer data",
            "summary": "Customer API with API Key authentication",
            "securityProfiles": [
                {
                    "_default": true,
                    "devices": [
                        {
                            "name": "API Key Authentication",
                            "type": "apiKey",
                            "order": 1,
                            "properties": {
                                "apiKeyFieldName": "X-API-Key",
                                "takeFrom": "HEADER",
                                "removeCredentialsOnSuccess": true
                            }
                        }
                    ]
                }
            ],
            "customProperties": {
                "environment": "production",
                "team": "customer-services",
                "costCenter": "CC-1234",
                "compliance": "PCI-DSS"
            }
        }
    },

    oauthInternal: {
        name: "OAuth 2.0 Internal",
        description: "Internal OAuth with token store",
        config: {
            "name": "OAuth secured API",
            "path": "/api/v1/oauth",
            "state": "published",
            "version": "1.0.0",
            "organization": "API Development",
            "securityProfiles": [
                {
                    "name": "_default",
                    "isDefault": true,
                    "devices": [
                        {
                            "type": "oauth",
                            "name": "OAuth",
                            "order": 1,
                            "properties": {
                                "tokenStore": "OAuth Access Token Store",
                                "accessTokenLocation": "HEADER",
                                "authorizationHeaderPrefix": "Bearer",
                                "scopesMustMatch": "Any",
                                "scopes": "resource.WRITE, resource.READ",
                                "removeCredentialsOnSuccess": true,
                                "implicitGrantEnabled": true,
                                "authCodeGrantTypeEnabled": true
                            }
                        }
                    ]
                }
            ]
        }
    },

    customPolicy: {
        name: "Custom Auth Policy",
        description: "Custom authentication policy invocation",
        config: {
            "name": "Custom Policy secured API",
            "path": "/api/v1/custom-policy",
            "state": "published",
            "version": "1.0.0",
            "organization": "API Development",
            "securityProfiles": [
                {
                    "name": "_default",
                    "isDefault": true,
                    "devices": [
                        {
                            "type": "authPolicy",
                            "name": "Invoke Policy",
                            "order": 1,
                            "properties": {
                                "authenticationPolicy": "Custom authentication policy",
                                "useClientRegistry": true,
                                "subjectSelector": "authentication.subject.id"
                            }
                        }
                    ]
                }
            ]
        }
    }
};

/**
 * Get example by key
 */
export function getExample(key) {
    return examples[key] || null;
}

/**
 * Get all example keys
 */
export function getExampleKeys() {
    return Object.keys(examples);
}
