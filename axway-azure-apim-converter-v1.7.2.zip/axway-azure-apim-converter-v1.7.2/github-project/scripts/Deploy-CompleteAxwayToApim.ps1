# Enhanced Axway to Azure APIM Complete API Migration Script
# Supports full API configuration including outbound authentication

param(
    [Parameter(Mandatory = $true)]
    [string]$AxwayConfigFile,
    
    [Parameter(Mandatory = $true)]
    [string]$ResourceGroupName,
    
    [Parameter(Mandatory = $true)]
    [string]$ApimServiceName,
    
    [Parameter(Mandatory = $false)]
    [string]$OutputPath = "./migration-output",
    
    [Parameter(Mandatory = $false)]
    [switch]$DeployInfrastructure,
    
    [Parameter(Mandatory = $false)]
    [switch]$WhatIf,
    
    [Parameter(Mandatory = $false)]
    [switch]$BackupExisting,
    
    [Parameter(Mandatory = $false)]
    [switch]$ValidateOnly
)

# Enable verbose output
$VerbosePreference = "Continue"

Write-Host "🚀 Enhanced Axway to Azure APIM Complete API Migration" -ForegroundColor Cyan
Write-Host "=======================================================" -ForegroundColor Cyan

# Import enhanced module
$modulePath = "$PSScriptRoot/modules/AxwayToApimConverterEnhanced.psm1"
if (Test-Path $modulePath) {
    Import-Module $modulePath -Force
    Write-Host "✅ Enhanced converter module loaded" -ForegroundColor Green
}
else {
    Write-Host "❌ Enhanced module not found at: $modulePath" -ForegroundColor Red
    Write-Host "Falling back to standard module..." -ForegroundColor Yellow
    Import-Module "$PSScriptRoot/modules/AxwayToApimConverter.psm1" -Force
}

# Function to validate prerequisites
function Test-Prerequisites {
    Write-Host "🔍 Validating prerequisites..." -ForegroundColor Yellow
    
    # Check if Axway config file exists
    if (-not (Test-Path $AxwayConfigFile)) {
        throw "Axway configuration file not found: $AxwayConfigFile"
    }
    
    # Check Azure CLI
    try {
        $account = az account show --query "name" -o tsv 2>$null
        if ($LASTEXITCODE -eq 0) {
            Write-Host "✅ Azure CLI authenticated as: $account" -ForegroundColor Green
        }
        else {
            throw "Azure CLI not authenticated"
        }
    }
    catch {
        throw "Azure CLI not authenticated. Please run: az login"
    }
    
    # Check APIM service
    try {
        $apim = az apim show --name $ApimServiceName --resource-group $ResourceGroupName --query "name" -o tsv 2>$null
        if ($LASTEXITCODE -eq 0) {
            Write-Host "✅ APIM Service found: $apim" -ForegroundColor Green
        }
        else {
            throw "APIM service not found"
        }
    }
    catch {
        throw "APIM Service '$ApimServiceName' not found in resource group '$ResourceGroupName'"
    }
    
    # Create output directory
    if (-not (Test-Path $OutputPath)) {
        New-Item -Path $OutputPath -ItemType Directory -Force | Out-Null
        Write-Host "✅ Output directory created: $OutputPath" -ForegroundColor Green
    }
}

# Function to analyze Axway configuration
function Get-AxwayConfigurationAnalysis {
    param([string]$ConfigFile)
    
    Write-Host "📊 Analyzing Axway configuration..." -ForegroundColor Yellow
    
    $config = Get-Content $ConfigFile -Raw | ConvertFrom-Json
    
    $analysis = @{
        ApiName = $config.name
        ApiPath = $config.path
        ApiVersion = $config.version
        Organization = $config.organization
        HasInboundSecurity = $config.securityProfiles -ne $null
        HasOutboundAuth = $config.outboundProfiles -ne $null
        HasCors = $config.corsProfiles -ne $null
        HasCustomProperties = $config.customProperties -ne $null
        HasQuotas = ($config.applicationQuota -ne $null) -or ($config.systemQuota -ne $null)
        HasCertificates = $config.caCerts -ne $null
        BackendUrl = $config.backendBasepath
        State = $config.state ?? "unpublished"
        VirtualHost = $config.vhost
        ApiRoutingKey = $config.apiRoutingKey
    }
    
    # Display analysis
    Write-Host "  API Name: $($analysis.ApiName)" -ForegroundColor White
    Write-Host "  API Path: $($analysis.ApiPath)" -ForegroundColor White
    Write-Host "  Version: $($analysis.ApiVersion)" -ForegroundColor White
    Write-Host "  Organization: $($analysis.Organization)" -ForegroundColor White
    Write-Host "  Backend URL: $($analysis.BackendUrl)" -ForegroundColor White
    Write-Host "  State: $($analysis.State)" -ForegroundColor White
    
    if ($analysis.VirtualHost) {
        Write-Host "  Virtual Host: $($analysis.VirtualHost)" -ForegroundColor White
    }
    
    if ($analysis.ApiRoutingKey) {
        Write-Host "  API Routing Key: $($analysis.ApiRoutingKey)" -ForegroundColor White
    }
    
    Write-Host "  Features to migrate:" -ForegroundColor Cyan
    Write-Host "    🔐 Inbound Security: $(if($analysis.HasInboundSecurity){"✅ Yes"}else{"❌ No"})" -ForegroundColor $(if($analysis.HasInboundSecurity){"Green"}else{"Red"})
    Write-Host "    🔗 Outbound Auth: $(if($analysis.HasOutboundAuth){"✅ Yes"}else{"❌ No"})" -ForegroundColor $(if($analysis.HasOutboundAuth){"Green"}else{"Red"})
    Write-Host "    🌐 CORS: $(if($analysis.HasCors){"✅ Yes"}else{"❌ No"})" -ForegroundColor $(if($analysis.HasCors){"Green"}else{"Red"})
    Write-Host "    🏷️ Custom Properties: $(if($analysis.HasCustomProperties){"✅ Yes"}else{"❌ No"})" -ForegroundColor $(if($analysis.HasCustomProperties){"Green"}else{"Red"})
    Write-Host "    📊 Quotas: $(if($analysis.HasQuotas){"✅ Yes"}else{"❌ No"})" -ForegroundColor $(if($analysis.HasQuotas){"Green"}else{"Red"})
    Write-Host "    🔒 Certificates: $(if($analysis.HasCertificates){"✅ Yes"}else{"❌ No"})" -ForegroundColor $(if($analysis.HasCertificates){"Green"}else{"Red"})
    
    return $analysis
}

# Function to perform complete API migration
function Invoke-CompleteApiMigration {
    param(
        [object]$Analysis,
        [string]$ConfigFile,
        [string]$OutputPath
    )
    
    Write-Host "🔄 Starting complete API migration..." -ForegroundColor Cyan
    
    try {
        # Convert complete Axway configuration
        $conversionResult = Convert-AxwayApiConfiguration -AxwayConfig $ConfigFile -OutputPath $OutputPath -IncludeInfrastructure:$DeployInfrastructure
        
        if ($conversionResult.Success) {
            Write-Host "✅ Configuration conversion completed successfully!" -ForegroundColor Green
            Write-Host "  Generated artifacts: $($conversionResult.ArtifactsGenerated)" -ForegroundColor White
            Write-Host "  Output location: $($conversionResult.OutputPath)" -ForegroundColor White
            
            return $conversionResult
        }
        else {
            throw "Configuration conversion failed"
        }
    }
    catch {
        Write-Error "Complete API migration failed: $($_.Exception.Message)"
        throw
    }
}

# Function to deploy API to Azure APIM
function Deploy-ApiToApim {
    param(
        [object]$ConversionResult,
        [object]$Analysis
    )
    
    Write-Host "🚀 Deploying API to Azure APIM..." -ForegroundColor Cyan
    
    try {
        $apiId = ($Analysis.ApiName -replace "[^a-zA-Z0-9-]", "-").ToLower()
        
        # Step 1: Create/Update API
        Write-Host "  📝 Creating API definition..." -ForegroundColor Yellow
        
        $apiDefinitionFile = "$OutputPath/api-definition.json"
        if (Test-Path $apiDefinitionFile) {
            $apiDefinition = Get-Content $apiDefinitionFile -Raw | ConvertFrom-Json
            
            $createApiCmd = @"
az apim api create \
  --service-name $ApimServiceName \
  --resource-group $ResourceGroupName \
  --api-id $apiId \
  --path "$($Analysis.ApiPath)" \
  --display-name "$($Analysis.ApiName)" \
  --protocols "https" \
  --subscription-required true
"@
            
            if (-not $WhatIf) {
                Invoke-Expression $createApiCmd
                if ($LASTEXITCODE -eq 0) {
                    Write-Host "    ✅ API created successfully" -ForegroundColor Green
                }
                else {
                    throw "Failed to create API"
                }
            }
            else {
                Write-Host "    🔍 WhatIf: Would create API with command:" -ForegroundColor Yellow
                Write-Host "    $createApiCmd" -ForegroundColor Gray
            }
        }
        
        # Step 2: Deploy main policy
        Write-Host "  🔐 Deploying security and configuration policies..." -ForegroundColor Yellow
        
        $policyFile = "$OutputPath/apim-policy.xml"
        if (Test-Path $policyFile) {
            if ($BackupExisting) {
                $timestamp = Get-Date -Format "yyyyMMdd-HHmmss"
                $backupFile = "$OutputPath/policy-backup-$apiId-$timestamp.xml"
                
                try {
                    $existingPolicy = az apim api policy show `
                        --resource-group $ResourceGroupName `
                        --service-name $ApimServiceName `
                        --api-id $apiId `
                        --query "value" `
                        --output tsv 2>$null
                    
                    if ($LASTEXITCODE -eq 0 -and $existingPolicy) {
                        $existingPolicy | Out-File -FilePath $backupFile -Encoding UTF8
                        Write-Host "    💾 Existing policy backed up to: $backupFile" -ForegroundColor Green
                    }
                }
                catch {
                    Write-Warning "Could not backup existing policy: $($_.Exception.Message)"
                }
            }
            
            if (-not $WhatIf) {
                az apim api policy create `
                    --resource-group $ResourceGroupName `
                    --service-name $ApimServiceName `
                    --api-id $apiId `
                    --policy-format "rawxml" `
                    --policy-file $policyFile
                
                if ($LASTEXITCODE -eq 0) {
                    Write-Host "    ✅ Policy deployed successfully" -ForegroundColor Green
                }
                else {
                    throw "Failed to deploy policy"
                }
            }
            else {
                Write-Host "    🔍 WhatIf: Would deploy policy from: $policyFile" -ForegroundColor Yellow
            }
        }
        
        # Step 3: Configure Named Values
        Write-Host "  🏷️ Configuring Named Values..." -ForegroundColor Yellow
        
        $namedValuesFile = "$OutputPath/named-values.json"
        if (Test-Path $namedValuesFile) {
            $namedValues = Get-Content $namedValuesFile -Raw | ConvertFrom-Json
            
            foreach ($nvProperty in $namedValues.PSObject.Properties) {
                $nvName = $nvProperty.Name
                $nvConfig = $nvProperty.Value
                
                if (-not $WhatIf) {
                    $secretFlag = if ($nvConfig.Secret) { "--secret true" } else { "" }
                    
                    $cmd = "az apim nv create --service-name $ApimServiceName --resource-group $ResourceGroupName --named-value-id `"$nvName`" --display-name `"$($nvConfig.DisplayName)`" --value `"$($nvConfig.Value)`" $secretFlag"
                    
                    Invoke-Expression $cmd
                    
                    if ($LASTEXITCODE -eq 0) {
                        Write-Host "    ✅ Named Value created: $nvName" -ForegroundColor Green
                    }
                    else {
                        Write-Warning "Failed to create Named Value: $nvName"
                    }
                }
                else {
                    Write-Host "    🔍 WhatIf: Would create Named Value: $nvName = $($nvConfig.Value)" -ForegroundColor Yellow
                }
            }
        }
        
        # Step 4: Deploy infrastructure if requested
        if ($DeployInfrastructure -and (Test-Path "$OutputPath/api-infrastructure.json")) {
            Write-Host "  🏗️ Deploying infrastructure..." -ForegroundColor Yellow
            
            if (-not $WhatIf) {
                az deployment group create `
                    --resource-group $ResourceGroupName `
                    --template-file "$OutputPath/api-infrastructure.json" `
                    --parameters apimServiceName=$ApimServiceName
                
                if ($LASTEXITCODE -eq 0) {
                    Write-Host "    ✅ Infrastructure deployed successfully" -ForegroundColor Green
                }
                else {
                    Write-Warning "Infrastructure deployment had issues"
                }
            }
            else {
                Write-Host "    🔍 WhatIf: Would deploy infrastructure template" -ForegroundColor Yellow
            }
        }
        
        return $apiId
    }
    catch {
        Write-Error "API deployment failed: $($_.Exception.Message)"
        throw
    }
}

# Function to validate deployed API
function Test-DeployedApi {
    param(
        [string]$ApiId,
        [object]$Analysis
    )
    
    Write-Host "🧪 Validating deployed API..." -ForegroundColor Cyan
    
    try {
        # Get API information
        $apiInfo = az apim api show `
            --service-name $ApimServiceName `
            --resource-group $ResourceGroupName `
            --api-id $ApiId | ConvertFrom-Json
        
        if ($apiInfo) {
            Write-Host "  ✅ API deployed successfully:" -ForegroundColor Green
            Write-Host "    Name: $($apiInfo.displayName)" -ForegroundColor White
            Write-Host "    Path: $($apiInfo.path)" -ForegroundColor White
            Write-Host "    Service URL: $($apiInfo.serviceUrl)" -ForegroundColor White
        }
        
        # Check policy
        $policy = az apim api policy show `
            --service-name $ApimServiceName `
            --resource-group $ResourceGroupName `
            --api-id $ApiId `
            --query "value" `
            --output tsv 2>$null
        
        if ($LASTEXITCODE -eq 0 -and $policy) {
            Write-Host "  ✅ Policy deployed and active" -ForegroundColor Green
        }
        else {
            Write-Host "  ⚠️ Policy not found or not deployed" -ForegroundColor Yellow
        }
        
        # Get APIM gateway URL for testing
        $apimInfo = az apim show --name $ApimServiceName --resource-group $ResourceGroupName | ConvertFrom-Json
        $gatewayUrl = $apimInfo.gatewayUrl
        $testUrl = "$gatewayUrl$($Analysis.ApiPath)"
        
        Write-Host "  🔗 Test endpoint: $testUrl" -ForegroundColor Cyan
        
        return $true
    }
    catch {
        Write-Warning "API validation encountered issues: $($_.Exception.Message)"
        return $false
    }
}

# Function to generate migration report
function New-MigrationReport {
    param(
        [object]$Analysis,
        [object]$ConversionResult,
        [string]$ApiId,
        [string]$OutputPath
    )
    
    $report = @{
        MigrationTimestamp = Get-Date
        SourceConfiguration = $AxwayConfigFile
        TargetApimService = $ApimServiceName
        ResourceGroup = $ResourceGroupName
        ApiId = $ApiId
        Analysis = $Analysis
        ConversionResult = $ConversionResult
        OutputPath = $OutputPath
        ValidationResults = @{}
        NextSteps = @(
            "Test the API endpoints using the provided test URL",
            "Configure additional security settings if needed",
            "Update DNS if using custom virtual hosts",
            "Set up monitoring and alerting",
            "Update client applications with new endpoint URLs"
        )
    }
    
    $reportFile = "$OutputPath/migration-report.json"
    $report | ConvertTo-Json -Depth 10 | Out-File -FilePath $reportFile -Encoding UTF8
    
    Write-Host "📋 Migration report saved to: $reportFile" -ForegroundColor Green
    
    return $report
}

# Main execution
try {
    $startTime = Get-Date
    
    # Validate prerequisites
    Test-Prerequisites
    
    # Analyze Axway configuration
    $analysis = Get-AxwayConfigurationAnalysis -ConfigFile $AxwayConfigFile
    
    if ($ValidateOnly) {
        Write-Host "✅ Validation completed. Configuration is ready for migration." -ForegroundColor Green
        exit 0
    }
    
    # Convert API configuration
    $conversionResult = Invoke-CompleteApiMigration -Analysis $analysis -ConfigFile $AxwayConfigFile -OutputPath $OutputPath
    
    # Deploy to Azure APIM
    $apiId = Deploy-ApiToApim -ConversionResult $conversionResult -Analysis $analysis
    
    # Validate deployment
    $validationSuccess = Test-DeployedApi -ApiId $apiId -Analysis $analysis
    
    # Generate final report
    $migrationReport = New-MigrationReport -Analysis $analysis -ConversionResult $conversionResult -ApiId $apiId -OutputPath $OutputPath
    
    $endTime = Get-Date
    $duration = $endTime - $startTime
    
    # Success summary
    Write-Host ""
    Write-Host "🎉 Migration completed successfully!" -ForegroundColor Green
    Write-Host "⏱️ Duration: $($duration.TotalSeconds.ToString("F1")) seconds" -ForegroundColor Cyan
    Write-Host "📊 Summary:" -ForegroundColor Cyan
    Write-Host "  • API Name: $($analysis.ApiName)" -ForegroundColor White
    Write-Host "  • API ID: $apiId" -ForegroundColor White
    Write-Host "  • Features migrated: $($conversionResult.ArtifactsGenerated)" -ForegroundColor White
    Write-Host "  • Output directory: $OutputPath" -ForegroundColor White
    
    if (-not $WhatIf) {
        Write-Host ""
        Write-Host "🔗 Next Steps:" -ForegroundColor Cyan
        Write-Host "  1. Test your API endpoints" -ForegroundColor White
        Write-Host "  2. Review the generated policies and configurations" -ForegroundColor White
        Write-Host "  3. Configure monitoring and alerting" -ForegroundColor White
        Write-Host "  4. Update client applications" -ForegroundColor White
        Write-Host ""
        Write-Host "📋 Full migration report: $OutputPath/migration-report.json" -ForegroundColor Yellow
    }
    else {
        Write-Host ""
        Write-Host "🔍 WhatIf mode completed. No changes were made." -ForegroundColor Yellow
        Write-Host "📋 Review generated artifacts in: $OutputPath" -ForegroundColor Yellow
    }
    
    exit 0
}
catch {
    Write-Host ""
    Write-Host "❌ Migration failed!" -ForegroundColor Red
    Write-Host "Error: $($_.Exception.Message)" -ForegroundColor Red
    
    if ($_.Exception.InnerException) {
        Write-Host "Inner Error: $($_.Exception.InnerException.Message)" -ForegroundColor Red
    }
    
    Write-Host ""
    Write-Host "🔍 Troubleshooting:" -ForegroundColor Yellow
    Write-Host "  • Check your Azure CLI authentication" -ForegroundColor White
    Write-Host "  • Verify APIM service exists and you have permissions" -ForegroundColor White
    Write-Host "  • Validate the Axway configuration file format" -ForegroundColor White
    Write-Host "  • Review logs in the output directory" -ForegroundColor White
    
    exit 1
}
