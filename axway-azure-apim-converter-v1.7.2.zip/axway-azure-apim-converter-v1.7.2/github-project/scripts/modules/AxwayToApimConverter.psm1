# AxwayToApimConverter PowerShell Module
# Comprehensive toolkit for converting Axway Gateway security policies to Azure APIM

#requires -version 5.1

# Module metadata
$ModuleVersion = "2.1.0"
$ModuleAuthor = "Your Organization"
$ModuleDescription = "Axway Gateway to Azure APIM Security Policy Conversion Toolkit"

# Export functions
$FunctionsToExport = @(
    'Convert-AxwaySecurityToApim',
    'New-ApimPolicyXml',
    'Test-ApimPolicyValidation',
    'Get-AxwaySecurityProfile',
    'Set-ApimNamedValues',
    'Backup-ApimPolicy',
    'Deploy-ApimSecurityPolicy',
    'Test-SecurityConfiguration'
)

#region Core Conversion Functions

function Convert-AxwaySecurityToApim {
    <#
    .SYNOPSIS
        Converts Axway Gateway security configuration to Azure APIM policy XML
    
    .DESCRIPTION
        Analyzes Axway Gateway security profiles and generates equivalent Azure APIM policy XML
        with support for all major authentication types including API Key, OAuth, Basic Auth, and custom policies.
    
    .PARAMETER AxwayConfig
        Axway security configuration as JSON object or file path
    
    .PARAMETER SecurityType
        Override security type detection (apikey, oauth, basic, aws, custom, passthrough)
    
    .PARAMETER OutputFormat
        Output format: xml, json, or object (default: xml)
    
    .PARAMETER IncludeRateLimit
        Include rate limiting policies in the output
    
    .PARAMETER IncludeLogging
        Include comprehensive logging policies
    
    .EXAMPLE
        Convert-AxwaySecurityToApim -AxwayConfig $config -SecurityType "apikey"
    
    .EXAMPLE
        Convert-AxwaySecurityToApim -AxwayConfig "./axway-config.json" -IncludeRateLimit -IncludeLogging
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true, ValueFromPipeline = $true)]
        [object]$AxwayConfig,
        
        [Parameter(Mandatory = $false)]
        [ValidateSet("apikey", "oauth", "basic", "aws", "custom", "passthrough")]
        [string]$SecurityType,
        
        [Parameter(Mandatory = $false)]
        [ValidateSet("xml", "json", "object")]
        [string]$OutputFormat = "xml",
        
        [Parameter(Mandatory = $false)]
        [switch]$IncludeRateLimit,
        
        [Parameter(Mandatory = $false)]
        [switch]$IncludeLogging
    )
    
    begin {
        Write-Verbose "Starting Axway to APIM security conversion"
    }
    
    process {
        try {
            # Parse Axway configuration
            $config = Get-AxwaySecurityProfile -Config $AxwayConfig
            
            # Detect security type if not specified
            if (-not $SecurityType) {
                $SecurityType = Get-SecurityType -Config $config
                Write-Verbose "Detected security type: $SecurityType"
            }
            
            # Generate APIM policy based on type
            $policyXml = switch ($SecurityType) {
                "apikey" { New-ApiKeyPolicy -Config $config -IncludeRateLimit:$IncludeRateLimit -IncludeLogging:$IncludeLogging }
                "oauth" { New-OAuthPolicy -Config $config -IncludeRateLimit:$IncludeRateLimit -IncludeLogging:$IncludeLogging }
                "basic" { New-BasicAuthPolicy -Config $config -IncludeRateLimit:$IncludeRateLimit -IncludeLogging:$IncludeLogging }
                "aws" { New-AwsSignaturePolicy -Config $config -IncludeRateLimit:$IncludeRateLimit -IncludeLogging:$IncludeLogging }
                "custom" { New-CustomAuthPolicy -Config $config -IncludeRateLimit:$IncludeRateLimit -IncludeLogging:$IncludeLogging }
                "passthrough" { New-PassthroughPolicy -Config $config -IncludeRateLimit:$IncludeRateLimit -IncludeLogging:$IncludeLogging }
                default { throw "Unsupported security type: $SecurityType" }
            }
            
            # Return in requested format
            switch ($OutputFormat) {
                "xml" { return $policyXml }
                "json" { 
                    return @{
                        securityType = $SecurityType
                        policyXml = $policyXml
                        metadata = @{
                            convertedAt = Get-Date -Format "yyyy-MM-ddTHH:mm:ssZ"
                            moduleVersion = $ModuleVersion
                        }
                    } | ConvertTo-Json -Depth 5
                }
                "object" {
                    return [PSCustomObject]@{
                        SecurityType = $SecurityType
                        PolicyXml = $policyXml
                        Configuration = $config
                        Metadata = @{
                            ConvertedAt = Get-Date
                            ModuleVersion = $ModuleVersion
                        }
                    }
                }
            }
        }
        catch {
            Write-Error "Conversion failed: $($_.Exception.Message)"
            throw
        }
    }
    
    end {
        Write-Verbose "Conversion completed successfully"
    }
}

function Get-AxwaySecurityProfile {
    <#
    .SYNOPSIS
        Parses and validates Axway security configuration
    
    .PARAMETER Config
        Axway configuration as JSON string, object, or file path
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [object]$Config
    )
    
    try {
        # Handle different input types
        if ($Config -is [string]) {
            if (Test-Path $Config) {
                # File path
                $configContent = Get-Content -Path $Config -Raw | ConvertFrom-Json
            }
            else {
                # JSON string
                $configContent = $Config | ConvertFrom-Json
            }
        }
        elseif ($Config -is [PSCustomObject] -or $Config -is [hashtable]) {
            # Already parsed object
            $configContent = $Config
        }
        else {
            throw "Invalid configuration format. Expected JSON string, file path, or object."
        }
        
        # Validate required structure
        if (-not $configContent.securityProfiles) {
            # Try to detect if this is a simplified config format
            if ($configContent.type) {
                return $configContent
            }
            throw "Configuration must contain 'securityProfiles' array or 'type' property"
        }
        
        # Extract default security profile
        $defaultProfile = $configContent.securityProfiles | Where-Object { $_.isDefault -eq $true -or $_.name -eq "_default" }
        
        if (-not $defaultProfile) {
            $defaultProfile = $configContent.securityProfiles[0]
        }
        
        if (-not $defaultProfile.devices -or $defaultProfile.devices.Count -eq 0) {
            throw "Security profile must contain at least one device"
        }
        
        # Extract primary device (Axway only supports one device currently)
        $primaryDevice = $defaultProfile.devices[0]
        
        return [PSCustomObject]@{
            Type = $primaryDevice.type
            Name = $primaryDevice.name
            Properties = $primaryDevice.properties
            Order = $primaryDevice.order
            ProfileName = $defaultProfile.name
            IsDefault = $defaultProfile.isDefault
        }
    }
    catch {
        Write-Error "Failed to parse Axway configuration: $($_.Exception.Message)"
        throw
    }
}

function Get-SecurityType {
    <#
    .SYNOPSIS
        Detects security type from Axway configuration
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [PSCustomObject]$Config
    )
    
    $typeMapping = @{
        "apiKey" = "apikey"
        "oauth" = "oauth"
        "oauthExternal" = "oauth"
        "httpBasic" = "basic"
        "awsSigning" = "aws"
        "authPolicy" = "custom"
        "passthrough" = "passthrough"
    }
    
    $axwayType = $Config.Type
    if ($typeMapping.ContainsKey($axwayType)) {
        return $typeMapping[$axwayType]
    }
    
    Write-Warning "Unknown Axway security type: $axwayType. Defaulting to 'custom'"
    return "custom"
}

#endregion

#region Policy Generation Functions

function New-ApiKeyPolicy {
    [CmdletBinding()]
    param(
        [PSCustomObject]$Config,
        [switch]$IncludeRateLimit,
        [switch]$IncludeLogging
    )
    
    $keyFieldName = $Config.Properties.apiKeyFieldName ?? "X-API-Key"
    $takeFrom = $Config.Properties.takeFrom ?? "HEADER"
    $removeCredentials = [bool]($Config.Properties.removeCredentialsOnSuccess ?? $true)
    
    $rateLimitPolicy = if ($IncludeRateLimit) {
        @"
        <!-- Rate limiting per API key -->
        <rate-limit-by-key calls="1000" renewal-period="60" 
                          counter-key="@(context.Request.Headers.GetValueOrDefault("$keyFieldName","anonymous"))" />
"@
    } else { "" }
    
    $loggingPolicy = if ($IncludeLogging) {
        @"
        <!-- Log authentication event -->
        <trace source="API-Key-Authentication">
            @{{{
                return string.Format("API Key authentication successful for key: {{0}}", 
                    ((string)context.Request.Headers.GetValueOrDefault("$keyFieldName","")).Substring(0, 
                    Math.Min(8, ((string)context.Request.Headers.GetValueOrDefault("$keyFieldName","")).Length)) + "***");
            }}}
        </trace>
"@
    } else { "" }
    
    $removeCredentialsPolicy = if ($removeCredentials) {
        @"
        <!-- Remove API key from request -->
        <set-header name="$keyFieldName" exists-action="delete" />
"@
    } else { "" }
    
    $queryValidation = if ($takeFrom -eq "QUERY") {
        @"
        <!-- Validate API key from query parameter -->
        <choose>
            <when condition="@(context.Request.Url.Query.GetValueOrDefault("$keyFieldName", "") == "")">
                <return-response>
                    <set-status code="401" reason="Unauthorized" />
                    <set-body>@("API key is required in query parameter: $keyFieldName")</set-body>
                </return-response>
            </when>
        </choose>
        
        <set-variable name="apiKey" value="@(context.Request.Url.Query.GetValueOrDefault("$keyFieldName",""))" />
"@
    } else {
        @"
        <!-- Validate API key from header -->
        <check-header name="$keyFieldName" failed-check-httpcode="401" 
                     failed-check-error-message="API key is missing or invalid" 
                     ignore-case="false"/>
        
        <set-variable name="apiKey" value="@(context.Request.Headers.GetValueOrDefault("$keyFieldName",""))" />
"@
    }
    
    return @"
<policies>
    <inbound>
        <base />
        <!-- API Key Authentication -->
        $queryValidation
        
        $rateLimitPolicy
        
        $loggingPolicy
        
        $removeCredentialsPolicy
        
        <!-- Add authentication context -->
        <set-header name="X-Authenticated" exists-action="override">
            <value>true</value>
        </set-header>
        <set-header name="X-Auth-Method" exists-action="override">
            <value>api-key</value>
        </set-header>
    </inbound>
    <backend>
        <base />
    </backend>
    <outbound>
        <base />
        <!-- Remove internal headers -->
        <set-header name="X-Authenticated" exists-action="delete" />
        <set-header name="X-Auth-Method" exists-action="delete" />
    </outbound>
    <on-error>
        <base />
        <!-- Log authentication failures -->
        <trace source="API-Key-Authentication-Error">
            @{{{
                return string.Format("API Key authentication failed from IP: {{0}}, Path: {{1}}", 
                    context.Request.IpAddress, context.Request.Url.Path);
            }}}
        </trace>
    </on-error>
</policies>
"@
}

function New-OAuthPolicy {
    [CmdletBinding()]
    param(
        [PSCustomObject]$Config,
        [switch]$IncludeRateLimit,
        [switch]$IncludeLogging
    )
    
    $tokenLocation = $Config.Properties.accessTokenLocation ?? "HEADER"
    $prefix = $Config.Properties.authorizationHeaderPrefix ?? "Bearer"
    $scopes = ($Config.Properties.scopes -split "," | ForEach-Object { $_.Trim() }) -join '", "'
    $scopesMatch = $Config.Properties.scopesMustMatch ?? "Any"
    $removeCredentials = [bool]($Config.Properties.removeCredentialsOnSuccess ?? $true)
    $isExternal = $Config.Type -eq "oauthExternal"
    
    $scopeValidation = if ($scopesMatch -eq "All") {
        @"
                <claim name="scope" match="all">
                    <value>$scopes</value>
                </claim>
"@
    } else {
        @"
                <claim name="scope" match="any" separator=" ">
                    <value>$scopes</value>
                </claim>
"@
    }
    
    $externalValidation = if ($isExternal) {
        @"
        <!-- External OAuth Provider Configuration -->
        <!-- Update these Named Values in APIM -->
        <openid-config url="{{oauth-external-openid-config}}" />
        <audiences>
            <audience>{{oauth-external-audience}}</audience>
        </audiences>
        <issuers>
            <issuer>{{oauth-external-issuer}}</issuer>
        </issuers>
"@
    } else {
        @"
        <!-- Internal OAuth Configuration -->
        <openid-config url="{{oauth-openid-config-url}}" />
        <audiences>
            <audience>{{oauth-audience}}</audience>
        </audiences>
        <issuers>
            <issuer>{{oauth-issuer}}</issuer>
        </issuers>
"@
    }
    
    $rateLimitPolicy = if ($IncludeRateLimit) {
        @"
        <!-- Rate limiting per client -->
        <rate-limit-by-key calls="2000" renewal-period="60" 
                          counter-key="@(((Jwt)context.Variables["validated-jwt"]).Claims.GetValueOrDefault("client_id", "anonymous"))" />
"@
    } else { "" }
    
    $loggingPolicy = if ($IncludeLogging) {
        @"
        <!-- Log OAuth authentication event -->
        <trace source="OAuth-Authentication">
            @{{{
                return string.Format("OAuth authentication successful for user: {{0}}, client: {{1}}", 
                    ((Jwt)context.Variables["validated-jwt"]).Claims.GetValueOrDefault("sub", "unknown"),
                    ((Jwt)context.Variables["validated-jwt"]).Claims.GetValueOrDefault("client_id", "unknown"));
            }}}
        </trace>
"@
    } else { "" }
    
    $removeCredentialsPolicy = if ($removeCredentials) {
        @"
        <!-- Remove Authorization header -->
        <set-header name="Authorization" exists-action="delete" />
"@
    } else { "" }
    
    return @"
<policies>
    <inbound>
        <base />
        <!-- OAuth Token Validation -->
        <validate-jwt header-name="Authorization" 
                     failed-validation-httpcode="401" 
                     failed-validation-error-message="Unauthorized. Access token is missing or invalid.">
            $externalValidation
            <required-claims>
                $scopeValidation
            </required-claims>
        </validate-jwt>
        
        $rateLimitPolicy
        
        <!-- Extract token claims -->
        <set-variable name="userId" value="@(((Jwt)context.Variables["validated-jwt"]).Claims.GetValueOrDefault("sub", ""))" />
        <set-variable name="clientId" value="@(((Jwt)context.Variables["validated-jwt"]).Claims.GetValueOrDefault("client_id", ""))" />
        <set-variable name="tokenScopes" value="@(((Jwt)context.Variables["validated-jwt"]).Claims.GetValueOrDefault("scope", ""))" />
        
        $loggingPolicy
        
        $removeCredentialsPolicy
        
        <!-- Add authentication context -->
        <set-header name="X-Authenticated" exists-action="override">
            <value>true</value>
        </set-header>
        <set-header name="X-Auth-Method" exists-action="override">
            <value>oauth</value>
        </set-header>
        <set-header name="X-User-ID" exists-action="override">
            <value>@((string)context.Variables["userId"])</value>
        </set-header>
        <set-header name="X-Client-ID" exists-action="override">
            <value>@((string)context.Variables["clientId"])</value>
        </set-header>
    </inbound>
    <backend>
        <base />
    </backend>
    <outbound>
        <base />
        <!-- Remove internal headers -->
        <set-header name="X-Authenticated" exists-action="delete" />
        <set-header name="X-Auth-Method" exists-action="delete" />
        <set-header name="X-User-ID" exists-action="delete" />
        <set-header name="X-Client-ID" exists-action="delete" />
    </outbound>
    <on-error>
        <base />
        <!-- Log OAuth failures -->
        <trace source="OAuth-Authentication-Error">
            @{{{
                return string.Format("OAuth authentication failed from IP: {{0}}, Error: {{1}}", 
                    context.Request.IpAddress, context.LastError?.Message ?? "Unknown error");
            }}}
        </trace>
    </on-error>
</policies>
"@
}

function New-BasicAuthPolicy {
    [CmdletBinding()]
    param(
        [PSCustomObject]$Config,
        [switch]$IncludeRateLimit,
        [switch]$IncludeLogging
    )
    
    $realm = $Config.Properties.realm ?? "API Access"
    $removeCredentials = [bool]($Config.Properties.removeCredentialsOnSuccess ?? $true)
    
    $rateLimitPolicy = if ($IncludeRateLimit) {
        @"
        <!-- Rate limiting per IP for basic auth -->
        <rate-limit-by-key calls="500" renewal-period="60" 
                          counter-key="@(context.Request.IpAddress)" />
"@
    } else { "" }
    
    $loggingPolicy = if ($IncludeLogging) {
        @"
        <!-- Log basic auth event -->
        <trace source="Basic-Authentication">
            @{{{
                return string.Format("Basic authentication successful from IP: {{0}}", 
                    context.Request.IpAddress);
            }}}
        </trace>
"@
    } else { "" }
    
    $removeCredentialsPolicy = if ($removeCredentials) {
        @"
        <!-- Remove Authorization header -->
        <set-header name="Authorization" exists-action="delete" />
"@
    } else { "" }
    
    return @"
<policies>
    <inbound>
        <base />
        <!-- HTTP Basic Authentication -->
        <choose>
            <when condition="@(context.Request.Headers.GetValueOrDefault("Authorization","") == "")">
                <return-response>
                    <set-status code="401" reason="Unauthorized" />
                    <set-header name="WWW-Authenticate" exists-action="override">
                        <value>Basic realm="$realm"</value>
                    </set-header>
                    <set-body>@("Unauthorized")</set-body>
                </return-response>
            </when>
        </choose>
        
        <!-- Validate credentials using Named Values -->
        <authentication-basic username="{{basic-auth-username}}" password="{{basic-auth-password}}" />
        
        $rateLimitPolicy
        
        $loggingPolicy
        
        $removeCredentialsPolicy
        
        <!-- Add authentication context -->
        <set-header name="X-Authenticated" exists-action="override">
            <value>true</value>
        </set-header>
        <set-header name="X-Auth-Method" exists-action="override">
            <value>basic</value>
        </set-header>
    </inbound>
    <backend>
        <base />
    </backend>
    <outbound>
        <base />
        <!-- Remove internal headers -->
        <set-header name="X-Authenticated" exists-action="delete" />
        <set-header name="X-Auth-Method" exists-action="delete" />
    </outbound>
    <on-error>
        <base />
        <!-- Log basic auth failures -->
        <trace source="Basic-Authentication-Error">
            @{{{
                return string.Format("Basic authentication failed from IP: {{0}}", 
                    context.Request.IpAddress);
            }}}
        </trace>
    </on-error>
</policies>
"@
}

function New-PassthroughPolicy {
    [CmdletBinding()]
    param(
        [PSCustomObject]$Config,
        [switch]$IncludeRateLimit,
        [switch]$IncludeLogging
    )
    
    $rateLimitPolicy = if ($IncludeRateLimit) {
        @"
        <!-- Rate limiting for anonymous access -->
        <rate-limit-by-key calls="100" renewal-period="60" 
                          counter-key="@(context.Request.IpAddress)" />
"@
    } else { "" }
    
    $loggingPolicy = if ($IncludeLogging) {
        @"
        <!-- Log passthrough access -->
        <trace source="Passthrough-Access">
            @{{{
                return string.Format("Passthrough access from IP: {{0}}, Path: {{1}}", 
                    context.Request.IpAddress, context.Request.Url.Path);
            }}}
        </trace>
"@
    } else { "" }
    
    return @"
<policies>
    <inbound>
        <base />
        <!-- Passthrough - No authentication required -->
        
        $rateLimitPolicy
        
        $loggingPolicy
        
        <!-- Add context header -->
        <set-header name="X-Auth-Method" exists-action="override">
            <value>passthrough</value>
        </set-header>
    </inbound>
    <backend>
        <base />
    </backend>
    <outbound>
        <base />
        <!-- Remove internal headers -->
        <set-header name="X-Auth-Method" exists-action="delete" />
    </outbound>
    <on-error>
        <base />
    </on-error>
</policies>
"@
}

function New-AwsSignaturePolicy {
    [CmdletBinding()]
    param(
        [PSCustomObject]$Config,
        [switch]$IncludeRateLimit,
        [switch]$IncludeLogging
    )
    
    $accessKey = $Config.Properties.accessKey ?? "{{aws-access-key}}"
    $region = $Config.Properties.region ?? "us-east-1"
    $service = $Config.Properties.service ?? "execute-api"
    
    return @"
<policies>
    <inbound>
        <base />
        <!-- AWS Signature Version 4 Validation -->
        <!-- Note: This is a simplified validation. For production, consider external validation service -->
        
        <set-variable name="authHeader" value="@(context.Request.Headers.GetValueOrDefault("Authorization",""))" />
        <set-variable name="dateHeader" value="@(context.Request.Headers.GetValueOrDefault("X-Amz-Date",""))" />
        
        <!-- Validate required headers -->
        <choose>
            <when condition="@(string.IsNullOrEmpty((string)context.Variables["authHeader"]) || string.IsNullOrEmpty((string)context.Variables["dateHeader"]))">
                <return-response>
                    <set-status code="401" reason="Unauthorized" />
                    <set-body>@("AWS signature headers missing")</set-body>
                </return-response>
            </when>
        </choose>
        
        <!-- Validate timestamp (within 15 minutes) -->
        <choose>
            <when condition="@{{
                var dateStr = (string)context.Variables["dateHeader"];
                if (DateTime.TryParseExact(dateStr, "yyyyMMddTHHmmssZ", null, DateTimeStyles.AssumeUniversal, out DateTime requestTime))
                {{
                    var timeDiff = Math.Abs((DateTime.UtcNow - requestTime).TotalMinutes);
                    return timeDiff > 15;
                }}
                return true;
            }}">
                <return-response>
                    <set-status code="401" reason="Unauthorized" />
                    <set-body>@("Request timestamp is too old")</set-body>
                </return-response>
            </when>
        </choose>
        
        <!-- Extract and validate access key -->
        <set-variable name="accessKey" value="@{{
            var auth = (string)context.Variables["authHeader"];
            if (auth.StartsWith("AWS4-HMAC-SHA256 "))
            {{
                var parts = auth.Substring("AWS4-HMAC-SHA256 ".Length).Split(',');
                foreach (var part in parts)
                {{
                    var kv = part.Trim().Split('=');
                    if (kv.Length == 2 && kv[0] == "Credential")
                    {{
                        return kv[1].Split('/')[0];
                    }}
                }}
            }}
            return "";
        }}" />
        
        <choose>
            <when condition="@((string)context.Variables["accessKey"] != "$accessKey")">
                <return-response>
                    <set-status code="401" reason="Unauthorized" />
                    <set-body>@("Invalid AWS access key")</set-body>
                </return-response>
            </when>
        </choose>
        
        <!-- Add authentication context -->
        <set-header name="X-Auth-Method" exists-action="override">
            <value>aws-signature</value>
        </set-header>
    </inbound>
    <backend>
        <base />
    </backend>
    <outbound>
        <base />
        <set-header name="X-Auth-Method" exists-action="delete" />
    </outbound>
    <on-error>
        <base />
    </on-error>
</policies>
"@
}

function New-CustomAuthPolicy {
    [CmdletBinding()]
    param(
        [PSCustomObject]$Config,
        [switch]$IncludeRateLimit,
        [switch]$IncludeLogging
    )
    
    $authPolicy = $Config.Properties.authenticationPolicy ?? "Custom Authentication Service"
    $subjectSelector = $Config.Properties.subjectSelector ?? "authentication.subject.id"
    
    return @"
<policies>
    <inbound>
        <base />
        <!-- Custom Authentication Policy -->
        <!-- Calls external authentication service for validation -->
        
        <set-variable name="customToken" value="@(context.Request.Headers.GetValueOrDefault("X-Custom-Token",""))" />
        
        <choose>
            <when condition="@(string.IsNullOrEmpty((string)context.Variables["customToken"]))">
                <return-response>
                    <set-status code="401" reason="Unauthorized" />
                    <set-body>@("Custom authentication token is required")</set-body>
                </return-response>
            </when>
        </choose>
        
        <!-- Call external authentication service -->
        <send-request mode="new" response-variable-name="authValidation" timeout="20" ignore-error="false">
            <set-url>{{custom-auth-service-url}}</set-url>
            <set-method>POST</set-method>
            <set-header name="Content-Type" exists-action="override">
                <value>application/json</value>
            </set-header>
            <set-header name="Authorization" exists-action="override">
                <value>Bearer {{custom-auth-service-token}}</value>
            </set-header>
            <set-body>@{{
                var token = (string)context.Variables["customToken"];
                return JsonConvert.SerializeObject(new {{ 
                    token = token,
                    apiPath = context.Request.Url.Path,
                    method = context.Request.Method,
                    policy = "$authPolicy"
                }});
            }}</set-body>
        </send-request>
        
        <!-- Validate authentication response -->
        <choose>
            <when condition="@(((IResponse)context.Variables["authValidation"]).StatusCode != 200)">
                <return-response>
                    <set-status code="401" reason="Unauthorized" />
                    <set-body>@("Authentication failed")</set-body>
                </return-response>
            </when>
        </choose>
        
        <!-- Extract subject information -->
        <set-variable name="authResult" value="@(((IResponse)context.Variables["authValidation"]).Body.As<JObject>())" />
        <set-variable name="subjectId" value="@{{
            var result = (JObject)context.Variables["authResult"];
            return result["authentication"]?["subject"]?["id"]?.ToString() ?? "";
        }}" />
        
        <!-- Add authentication context -->
        <set-header name="X-Auth-Method" exists-action="override">
            <value>custom</value>
        </set-header>
        <set-header name="X-Subject-ID" exists-action="override">
            <value>@((string)context.Variables["subjectId"])</value>
        </set-header>
        
        <!-- Remove custom token -->
        <set-header name="X-Custom-Token" exists-action="delete" />
    </inbound>
    <backend>
        <base />
    </backend>
    <outbound>
        <base />
        <set-header name="X-Auth-Method" exists-action="delete" />
        <set-header name="X-Subject-ID" exists-action="delete" />
    </outbound>
    <on-error>
        <base />
    </on-error>
</policies>
"@
}

#endregion

#region Validation and Testing Functions

function Test-ApimPolicyValidation {
    <#
    .SYNOPSIS
        Validates Azure APIM policy XML for common issues
    
    .PARAMETER PolicyXml
        The policy XML to validate
    
    .PARAMETER ValidationLevel
        Validation level: Basic, Standard, or Comprehensive
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$PolicyXml,
        
        [Parameter(Mandatory = $false)]
        [ValidateSet("Basic", "Standard", "Comprehensive")]
        [string]$ValidationLevel = "Standard"
    )
    
    $validationResults = @()
    
    try {
        # Parse XML
        $xml = [xml]$PolicyXml
        
        # Basic structure validation
        if (-not $xml.policies) {
            $validationResults += [PSCustomObject]@{
                Level = "Error"
                Category = "Structure"
                Message = "Missing root 'policies' element"
            }
        }
        
        # Check for required sections
        $requiredSections = @("inbound", "backend", "outbound", "on-error")
        foreach ($section in $requiredSections) {
            if (-not $xml.policies.$section) {
                $validationResults += [PSCustomObject]@{
                    Level = "Warning"
                    Category = "Structure"
                    Message = "Missing '$section' section"
                }
            }
        }
        
        # Expression validation
        $expressions = Select-Xml -Xml $xml -XPath "//*[contains(text(), '@(') or contains(text(), '@{')]"
        foreach ($expr in $expressions) {
            $exprText = $expr.Node.InnerText
            if ($exprText -match '@\([^)]*["`][^)`]*\)') {
                $validationResults += [PSCustomObject]@{
                    Level = "Error"
                    Category = "Expression"
                    Message = "Expression may contain unescaped quotes: $exprText"
                }
            }
        }
        
        # Policy-specific validations
        if ($ValidationLevel -in @("Standard", "Comprehensive")) {
            # Rate limit validation
            $rateLimits = Select-Xml -Xml $xml -XPath "//rate-limit-by-key"
            foreach ($rl in $rateLimits) {
                $calls = $rl.Node.Attributes["calls"]?.Value
                $period = $rl.Node.Attributes["renewal-period"]?.Value
                
                if ($calls -and [int]$calls -le 0) {
                    $validationResults += [PSCustomObject]@{
                        Level = "Error"
                        Category = "RateLimit"
                        Message = "Rate limit calls must be greater than 0"
                    }
                }
                
                if ($period -and ([int]$period -lt 1 -or [int]$period -gt 300)) {
                    $validationResults += [PSCustomObject]@{
                        Level = "Error"
                        Category = "RateLimit"
                        Message = "Rate limit renewal period must be between 1-300 seconds"
                    }
                }
            }
            
            # JWT validation checks
            $jwtValidations = Select-Xml -Xml $xml -XPath "//validate-jwt"
            foreach ($jwt in $jwtValidations) {
                if (-not $jwt.Node.SelectSingleNode(".//audiences") -and -not $jwt.Node.Attributes["require-scheme"]) {
                    $validationResults += [PSCustomObject]@{
                        Level = "Warning"
                        Category = "JWT"
                        Message = "JWT validation should specify audiences"
                    }
                }
            }
        }
        
        if ($ValidationLevel -eq "Comprehensive") {
            # Performance checks
            $sendRequests = Select-Xml -Xml $xml -XPath "//send-request"
            if ($sendRequests.Count -gt 3) {
                $validationResults += [PSCustomObject]@{
                    Level = "Warning"
                    Category = "Performance"
                    Message = "Multiple send-request calls may impact performance"
                }
            }
            
            # Security checks
            $headers = Select-Xml -Xml $xml -XPath "//set-header"
            foreach ($header in $headers) {
                $headerName = $header.Node.Attributes["name"]?.Value
                if ($headerName -match "(?i)(password|secret|key|token)" -and $header.Node.Attributes["exists-action"]?.Value -ne "delete") {
                    $validationResults += [PSCustomObject]@{
                        Level = "Warning"
                        Category = "Security"
                        Message = "Potential sensitive header exposure: $headerName"
                    }
                }
            }
        }
        
        return [PSCustomObject]@{
            IsValid = ($validationResults | Where-Object Level -eq "Error").Count -eq 0
            Errors = $validationResults | Where-Object Level -eq "Error"
            Warnings = $validationResults | Where-Object Level -eq "Warning"
            AllResults = $validationResults
        }
    }
    catch {
        return [PSCustomObject]@{
            IsValid = $false
            Errors = @([PSCustomObject]@{
                Level = "Error"
                Category = "Parse"
                Message = "Failed to parse XML: $($_.Exception.Message)"
            })
            Warnings = @()
            AllResults = @()
        }
    }
}

function Test-SecurityConfiguration {
    <#
    .SYNOPSIS
        Tests a security configuration against Azure APIM
    
    .PARAMETER ApimServiceName
        Azure APIM service name
    
    .PARAMETER ResourceGroupName
        Azure resource group name
    
    .PARAMETER ApiId
        API identifier
    
    .PARAMETER TestConfig
        Test configuration object
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$ApimServiceName,
        
        [Parameter(Mandatory = $true)]
        [string]$ResourceGroupName,
        
        [Parameter(Mandatory = $true)]
        [string]$ApiId,
        
        [Parameter(Mandatory = $true)]
        [hashtable]$TestConfig
    )
    
    $testResults = @()
    
    try {
        # Get the API base URL
        $apimInfo = az apim show --name $ApimServiceName --resource-group $ResourceGroupName | ConvertFrom-Json
        $gatewayUrl = $apimInfo.gatewayUrl
        
        $api = az apim api show --service-name $ApimServiceName --resource-group $ResourceGroupName --api-id $ApiId | ConvertFrom-Json
        $baseUrl = "$gatewayUrl$($api.path)"
        
        # Test without authentication (should fail)
        try {
            $response = Invoke-RestMethod -Uri "$baseUrl/test" -Method Get -TimeoutSec 30
            $testResults += [PSCustomObject]@{
                Test = "No Authentication"
                Result = "FAIL"
                Expected = "401 Unauthorized"
                Actual = "Request succeeded unexpectedly"
            }
        }
        catch {
            if ($_.Exception.Response.StatusCode -eq 401) {
                $testResults += [PSCustomObject]@{
                    Test = "No Authentication"
                    Result = "PASS"
                    Expected = "401 Unauthorized"
                    Actual = "401 Unauthorized"
                }
            }
            else {
                $testResults += [PSCustomObject]@{
                    Test = "No Authentication"
                    Result = "FAIL"
                    Expected = "401 Unauthorized"
                    Actual = $_.Exception.Message
                }
            }
        }
        
        # Test with valid authentication
        if ($TestConfig.AuthType -eq "apikey" -and $TestConfig.ApiKey) {
            $headers = @{ $TestConfig.ApiKeyHeader = $TestConfig.ApiKey }
            
            try {
                $response = Invoke-RestMethod -Uri "$baseUrl/test" -Method Get -Headers $headers -TimeoutSec 30
                $testResults += [PSCustomObject]@{
                    Test = "Valid API Key"
                    Result = "PASS"
                    Expected = "200 OK"
                    Actual = "200 OK"
                }
            }
            catch {
                $testResults += [PSCustomObject]@{
                    Test = "Valid API Key"
                    Result = "FAIL"
                    Expected = "200 OK"
                    Actual = $_.Exception.Message
                }
            }
        }
        
        # Test with invalid authentication
        if ($TestConfig.AuthType -eq "apikey") {
            $headers = @{ $TestConfig.ApiKeyHeader = "invalid-key" }
            
            try {
                $response = Invoke-RestMethod -Uri "$baseUrl/test" -Method Get -Headers $headers -TimeoutSec 30
                $testResults += [PSCustomObject]@{
                    Test = "Invalid API Key"
                    Result = "FAIL"
                    Expected = "401 Unauthorized"
                    Actual = "Request succeeded unexpectedly"
                }
            }
            catch {
                if ($_.Exception.Response.StatusCode -eq 401) {
                    $testResults += [PSCustomObject]@{
                        Test = "Invalid API Key"
                        Result = "PASS"
                        Expected = "401 Unauthorized"
                        Actual = "401 Unauthorized"
                    }
                }
                else {
                    $testResults += [PSCustomObject]@{
                        Test = "Invalid API Key"
                        Result = "FAIL"
                        Expected = "401 Unauthorized"
                        Actual = $_.Exception.Message
                    }
                }
            }
        }
        
        return [PSCustomObject]@{
            ServiceName = $ApimServiceName
            ApiId = $ApiId
            TestsRun = $testResults.Count
            TestsPassed = ($testResults | Where-Object Result -eq "PASS").Count
            TestsFailed = ($testResults | Where-Object Result -eq "FAIL").Count
            Results = $testResults
        }
    }
    catch {
        Write-Error "Security configuration test failed: $($_.Exception.Message)"
        throw
    }
}

#endregion

#region Deployment Functions

function Deploy-ApimSecurityPolicy {
    <#
    .SYNOPSIS
        Deploys a security policy to Azure APIM
    
    .PARAMETER ResourceGroupName
        Azure resource group name
    
    .PARAMETER ApimServiceName
        Azure APIM service name
    
    .PARAMETER ApiId
        API identifier
    
    .PARAMETER PolicyXml
        Policy XML content
    
    .PARAMETER BackupExisting
        Whether to backup existing policy
    #>
    [CmdletBinding(SupportsShouldProcess)]
    param(
        [Parameter(Mandatory = $true)]
        [string]$ResourceGroupName,
        
        [Parameter(Mandatory = $true)]
        [string]$ApimServiceName,
        
        [Parameter(Mandatory = $true)]
        [string]$ApiId,
        
        [Parameter(Mandatory = $true)]
        [string]$PolicyXml,
        
        [Parameter(Mandatory = $false)]
        [switch]$BackupExisting
    )
    
    try {
        # Backup existing policy if requested
        if ($BackupExisting) {
            $timestamp = Get-Date -Format "yyyyMMdd-HHmmss"
            $backupFile = "policy-backup-$ApiId-$timestamp.xml"
            
            Write-Verbose "Creating backup of existing policy: $backupFile"
            Backup-ApimPolicy -ResourceGroupName $ResourceGroupName -ApimServiceName $ApimServiceName -ApiId $ApiId -BackupFile $backupFile
        }
        
        # Validate policy XML
        $validation = Test-ApimPolicyValidation -PolicyXml $PolicyXml -ValidationLevel "Standard"
        if (-not $validation.IsValid) {
            $errorMessages = ($validation.Errors | ForEach-Object { $_.Message }) -join "; "
            throw "Policy validation failed: $errorMessages"
        }
        
        if ($validation.Warnings.Count -gt 0) {
            Write-Warning "Policy validation warnings:"
            $validation.Warnings | ForEach-Object { Write-Warning "  $($_.Category): $($_.Message)" }
        }
        
        # Deploy policy
        if ($PSCmdlet.ShouldProcess("API $ApiId in $ApimServiceName", "Deploy Security Policy")) {
            $tempFile = [System.IO.Path]::GetTempFileName()
            try {
                $PolicyXml | Out-File -FilePath $tempFile -Encoding UTF8
                
                Write-Verbose "Deploying policy to API: $ApiId"
                $result = az apim api policy create `
                    --resource-group $ResourceGroupName `
                    --service-name $ApimServiceName `
                    --api-id $ApiId `
                    --policy-format "rawxml" `
                    --policy-file $tempFile 2>&1
                
                if ($LASTEXITCODE -ne 0) {
                    throw "Azure CLI deployment failed: $result"
                }
                
                Write-Host "✅ Security policy deployed successfully to API: $ApiId" -ForegroundColor Green
                return $true
            }
            finally {
                if (Test-Path $tempFile) {
                    Remove-Item $tempFile -Force
                }
            }
        }
    }
    catch {
        Write-Error "Policy deployment failed: $($_.Exception.Message)"
        throw
    }
}

function Backup-ApimPolicy {
    <#
    .SYNOPSIS
        Backs up an existing APIM policy
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$ResourceGroupName,
        
        [Parameter(Mandatory = $true)]
        [string]$ApimServiceName,
        
        [Parameter(Mandatory = $true)]
        [string]$ApiId,
        
        [Parameter(Mandatory = $true)]
        [string]$BackupFile
    )
    
    try {
        Write-Verbose "Backing up existing policy for API: $ApiId"
        
        $policy = az apim api policy show `
            --resource-group $ResourceGroupName `
            --service-name $ApimServiceName `
            --api-id $ApiId `
            --query "value" `
            --output tsv 2>$null
        
        if ($LASTEXITCODE -eq 0 -and $policy) {
            $policy | Out-File -FilePath $BackupFile -Encoding UTF8
            Write-Host "✅ Policy backed up to: $BackupFile" -ForegroundColor Green
        }
        else {
            Write-Warning "No existing policy found for API: $ApiId"
        }
    }
    catch {
        Write-Warning "Failed to backup existing policy: $($_.Exception.Message)"
    }
}

function Set-ApimNamedValues {
    <#
    .SYNOPSIS
        Sets Named Values in Azure APIM for security configuration
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$ResourceGroupName,
        
        [Parameter(Mandatory = $true)]
        [string]$ApimServiceName,
        
        [Parameter(Mandatory = $true)]
        [hashtable]$NamedValues,
        
        [Parameter(Mandatory = $false)]
        [switch]$SecretValues
    )
    
    foreach ($kvp in $NamedValues.GetEnumerator()) {
        try {
            Write-Verbose "Setting Named Value: $($kvp.Key)"
            
            if ($SecretValues) {
                az apim nv create `
                    --service-name $ApimServiceName `
                    --resource-group $ResourceGroupName `
                    --named-value-id $kvp.Key `
                    --display-name $kvp.Key `
                    --value $kvp.Value `
                    --secret true
            }
            else {
                az apim nv create `
                    --service-name $ApimServiceName `
                    --resource-group $ResourceGroupName `
                    --named-value-id $kvp.Key `
                    --display-name $kvp.Key `
                    --value $kvp.Value
            }
            
            if ($LASTEXITCODE -eq 0) {
                Write-Host "✅ Named Value set: $($kvp.Key)" -ForegroundColor Green
            }
            else {
                Write-Error "Failed to set Named Value: $($kvp.Key)"
            }
        }
        catch {
            Write-Error "Error setting Named Value $($kvp.Key): $($_.Exception.Message)"
        }
    }
}

#endregion

# Export module members
Export-ModuleMember -Function $FunctionsToExport

# Module initialization
Write-Host "AxwayToApimConverter module loaded. Version: $ModuleVersion" -ForegroundColor Green
Write-Host "Use 'Get-Command -Module AxwayToApimConverter' to see available functions" -ForegroundColor Cyan
