# Enhanced AxwayToApimConverter PowerShell Module
# Complete API Configuration and Outbound Authentication Support

#requires -version 5.1

# Module metadata
$ModuleVersion = "2.2.0"
$ModuleAuthor = "Your Organization"
$ModuleDescription = "Complete Axway Gateway to Azure APIM Conversion Tool with API Configuration and Outbound Auth"

# Export functions - Enhanced list
$FunctionsToExport = @(
    'Convert-AxwayApiConfiguration',
    'Convert-AxwayOutboundAuthentication', 
    'Convert-AxwaySecurityToApim',
    'New-ApimPolicyXml',
    'Test-ApimPolicyValidation',
    'Get-AxwayApiConfiguration',
    'Get-AxwaySecurityProfile',
    'Get-AxwayOutboundProfile',
    'Set-ApimNamedValues',
    'Backup-ApimPolicy',
    'Deploy-ApimApi',
    'Deploy-ApimSecurityPolicy',
    'Test-SecurityConfiguration',
    'Convert-AxwayCorsProfile',
    'Convert-AxwayCustomProperties',
    'Convert-AxwayQuotaSettings'
)

#region Enhanced Core Conversion Functions

function Convert-AxwayApiConfiguration {
    <#
    .SYNOPSIS
        Converts complete Axway API configuration to Azure APIM format
    
    .DESCRIPTION
        Analyzes a complete Axway API configuration and generates equivalent Azure APIM 
        API definition, policies, and backend configuration. Supports all Axway API features.
    
    .PARAMETER AxwayConfig
        Complete Axway API configuration as JSON object or file path
    
    .PARAMETER OutputPath
        Output directory for generated APIM artifacts
    
    .PARAMETER IncludeInfrastructure
        Generate ARM templates for required infrastructure
    
    .EXAMPLE
        Convert-AxwayApiConfiguration -AxwayConfig "./samples/complete-api-config.json" -OutputPath "./output"
    
    .EXAMPLE
        $config | Convert-AxwayApiConfiguration -IncludeInfrastructure
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true, ValueFromPipeline = $true)]
        [object]$AxwayConfig,
        
        [Parameter(Mandatory = $false)]
        [string]$OutputPath = ".",
        
        [Parameter(Mandatory = $false)]
        [switch]$IncludeInfrastructure
    )
    
    begin {
        Write-Verbose "Starting complete Axway API configuration conversion"
        
        if (-not (Test-Path $OutputPath)) {
            New-Item -Path $OutputPath -ItemType Directory -Force | Out-Null
        }
    }
    
    process {
        try {
            # Parse Axway configuration
            $apiConfig = Get-AxwayApiConfiguration -Config $AxwayConfig
            
            Write-Host "🔄 Converting API: $($apiConfig.name)" -ForegroundColor Cyan
            
            # Generate conversion report
            $conversionReport = @{
                ApiName = $apiConfig.name
                ConvertedAt = Get-Date
                SourceConfig = $apiConfig
                GeneratedArtifacts = @{}
                Warnings = @()
                Errors = @()
            }
            
            # 1. Convert API Definition
            $apiDefinition = Convert-ApiDefinition -Config $apiConfig
            $conversionReport.GeneratedArtifacts["apiDefinition"] = $apiDefinition
            
            # 2. Convert Inbound Security
            if ($apiConfig.securityProfiles) {
                Write-Host "  🔐 Converting inbound security profiles..." -ForegroundColor Yellow
                $inboundPolicies = @{}
                
                foreach ($profile in $apiConfig.securityProfiles) {
                    $policy = Convert-AxwaySecurityToApim -AxwayConfig @{securityProfiles = @($profile)} -IncludeRateLimit -IncludeLogging
                    $inboundPolicies[$profile.name] = $policy
                }
                
                $conversionReport.GeneratedArtifacts["inboundPolicies"] = $inboundPolicies
            }
            
            # 3. Convert Outbound Authentication
            if ($apiConfig.outboundProfiles) {
                Write-Host "  🔗 Converting outbound authentication profiles..." -ForegroundColor Yellow
                $outboundPolicies = Convert-AxwayOutboundAuthentication -OutboundProfiles $apiConfig.outboundProfiles
                $conversionReport.GeneratedArtifacts["outboundPolicies"] = $outboundPolicies
            }
            
            # 4. Convert CORS Profiles
            if ($apiConfig.corsProfiles) {
                Write-Host "  🌐 Converting CORS profiles..." -ForegroundColor Yellow
                $corsConfig = Convert-AxwayCorsProfile -CorsProfiles $apiConfig.corsProfiles
                $conversionReport.GeneratedArtifacts["corsConfiguration"] = $corsConfig
            }
            
            # 5. Convert Custom Properties
            if ($apiConfig.customProperties) {
                Write-Host "  🏷️ Converting custom properties..." -ForegroundColor Yellow
                $customProps = Convert-AxwayCustomProperties -CustomProperties $apiConfig.customProperties
                $conversionReport.GeneratedArtifacts["customProperties"] = $customProps
            }
            
            # 6. Convert Quota Settings
            if ($apiConfig.applicationQuota -or $apiConfig.systemQuota) {
                Write-Host "  📊 Converting quota settings..." -ForegroundColor Yellow
                $quotaConfig = Convert-AxwayQuotaSettings -ApiConfig $apiConfig
                $conversionReport.GeneratedArtifacts["quotaConfiguration"] = $quotaConfig
            }
            
            # 7. Convert Certificate Settings
            if ($apiConfig.caCerts) {
                Write-Host "  🔒 Converting certificate settings..." -ForegroundColor Yellow
                $certConfig = Convert-AxwayCertificates -Certificates $apiConfig.caCerts
                $conversionReport.GeneratedArtifacts["certificateConfiguration"] = $certConfig
            }
            
            # 8. Generate Combined Policy
            Write-Host "  📋 Generating combined APIM policy..." -ForegroundColor Yellow
            $combinedPolicy = New-CombinedApimPolicy -ConversionArtifacts $conversionReport.GeneratedArtifacts
            
            # 9. Save artifacts to files
            Write-Host "  💾 Saving conversion artifacts..." -ForegroundColor Yellow
            Save-ConversionArtifacts -Report $conversionReport -OutputPath $OutputPath -CombinedPolicy $combinedPolicy
            
            # 10. Generate infrastructure if requested
            if ($IncludeInfrastructure) {
                Write-Host "  🏗️ Generating infrastructure templates..." -ForegroundColor Yellow
                $infraConfig = New-InfrastructureTemplates -ApiConfig $apiConfig -OutputPath $OutputPath
                $conversionReport.GeneratedArtifacts["infrastructure"] = $infraConfig
            }
            
            Write-Host "✅ Conversion completed successfully!" -ForegroundColor Green
            
            return [PSCustomObject]@{
                Success = $true
                Report = $conversionReport
                OutputPath = $OutputPath
                ArtifactsGenerated = $conversionReport.GeneratedArtifacts.Keys.Count
            }
        }
        catch {
            Write-Error "API configuration conversion failed: $($_.Exception.Message)"
            throw
        }
    }
    
    end {
        Write-Verbose "API configuration conversion completed"
    }
}

function Convert-AxwayOutboundAuthentication {
    <#
    .SYNOPSIS
        Converts Axway outbound authentication profiles to Azure APIM backend policies
    
    .DESCRIPTION
        Analyzes Axway outbound authentication configurations and generates equivalent 
        Azure APIM backend authentication policies for API-to-backend communication.
    
    .PARAMETER OutboundProfiles
        Axway outbound authentication profiles
    
    .PARAMETER IncludeRetry
        Include retry policies for backend communication
    
    .EXAMPLE
        Convert-AxwayOutboundAuthentication -OutboundProfiles $profiles -IncludeRetry
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [object]$OutboundProfiles,
        
        [Parameter(Mandatory = $false)]
        [switch]$IncludeRetry
    )
    
    $outboundPolicies = @{}
    
    foreach ($profileName in $OutboundProfiles.PSObject.Properties.Name) {
        $profile = $OutboundProfiles.$profileName
        
        Write-Verbose "Converting outbound profile: $profileName"
        
        # Check if authentication profile exists
        if ($profile.authenticationProfile -and $profile.authenticationProfile -ne "_default") {
            # Generate backend authentication policy
            $backendPolicy = New-OutboundAuthenticationPolicy -Profile $profile -IncludeRetry:$IncludeRetry
            $outboundPolicies[$profileName] = $backendPolicy
        }
        else {
            # Default passthrough backend policy
            $outboundPolicies[$profileName] = New-DefaultBackendPolicy -Profile $profile -IncludeRetry:$IncludeRetry
        }
    }
    
    return $outboundPolicies
}

function Get-AxwayApiConfiguration {
    <#
    .SYNOPSIS
        Parses and validates complete Axway API configuration
    
    .PARAMETER Config
        Axway API configuration as JSON string, object, or file path
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [object]$Config
    )
    
    try {
        # Handle different input types
        if ($Config -is [string]) {
            if (Test-Path $Config) {
                # File path
                $configContent = Get-Content -Path $Config -Raw | ConvertFrom-Json
            }
            else {
                # JSON string
                $configContent = $Config | ConvertFrom-Json
            }
        }
        elseif ($Config -is [PSCustomObject] -or $Config -is [hashtable]) {
            # Already parsed object
            $configContent = $Config
        }
        else {
            throw "Invalid configuration format. Expected JSON string, file path, or object."
        }
        
        # Validate required fields
        $requiredFields = @("name", "path", "version", "organization")
        foreach ($field in $requiredFields) {
            if (-not $configContent.$field) {
                throw "Missing required field: $field"
            }
        }
        
        # Set defaults for optional fields
        if (-not $configContent.state) { $configContent.state = "unpublished" }
        if (-not $configContent.backendBasepath) { $configContent.backendBasepath = "" }
        if (-not $configContent.descriptionType) { $configContent.descriptionType = "original" }
        
        return $configContent
    }
    catch {
        Write-Error "Failed to parse Axway API configuration: $($_.Exception.Message)"
        throw
    }
}

function Get-AxwayOutboundProfile {
    <#
    .SYNOPSIS
        Extracts and validates outbound authentication profile from Axway configuration
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$ProfileName,
        
        [Parameter(Mandatory = $true)]
        [object]$OutboundProfiles
    )
    
    if ($OutboundProfiles.$ProfileName) {
        return $OutboundProfiles.$ProfileName
    }
    elseif ($OutboundProfiles._default) {
        return $OutboundProfiles._default
    }
    else {
        throw "Outbound profile '$ProfileName' not found and no default profile available"
    }
}

#endregion

#region Outbound Authentication Policy Generation

function New-OutboundAuthenticationPolicy {
    <#
    .SYNOPSIS
        Generates Azure APIM backend authentication policy from Axway outbound profile
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [object]$Profile,
        
        [Parameter(Mandatory = $false)]
        [switch]$IncludeRetry
    )
    
    # Determine authentication type from profile
    $authType = Get-OutboundAuthenticationType -Profile $Profile
    
    $retryPolicy = if ($IncludeRetry) {
        @"
        <!-- Backend retry policy -->
        <retry condition="@(context.Response.StatusCode >= 500 || context.Response.StatusCode == 429)" 
               count="3" 
               interval="2" 
               max-interval="30" 
               delta="1">
"@
    } else { "" }
    
    $retryPolicyClose = if ($IncludeRetry) { "</retry>" } else { "" }
    
    switch ($authType) {
        "apikey" {
            return New-OutboundApiKeyPolicy -Profile $Profile -IncludeRetry:$IncludeRetry
        }
        "oauth" {
            return New-OutboundOAuthPolicy -Profile $Profile -IncludeRetry:$IncludeRetry
        }
        "basic" {
            return New-OutboundBasicAuthPolicy -Profile $Profile -IncludeRetry:$IncludeRetry
        }
        "ssl" {
            return New-OutboundSSLPolicy -Profile $Profile -IncludeRetry:$IncludeRetry
        }
        "custom" {
            return New-OutboundCustomPolicy -Profile $Profile -IncludeRetry:$IncludeRetry
        }
        default {
            return New-DefaultBackendPolicy -Profile $Profile -IncludeRetry:$IncludeRetry
        }
    }
}

function New-OutboundApiKeyPolicy {
    [CmdletBinding()]
    param(
        [object]$Profile,
        [switch]$IncludeRetry
    )
    
    $apiKeyName = $Profile.parameters.apiKeyName ?? "X-API-Key"
    $apiKeyValue = $Profile.parameters.apiKeyValue ?? "{{backend-api-key}}"
    $apiKeyLocation = $Profile.parameters.takeFrom ?? "HEADER"
    
    $retryPolicy = if ($IncludeRetry) {
        @"
        <retry condition="@(context.Response.StatusCode >= 500 || context.Response.StatusCode == 429)" 
               count="3" interval="2" max-interval="30" delta="1">
"@
    } else { "" }
    
    $retryPolicyClose = if ($IncludeRetry) { "</retry>" } else { "" }
    
    if ($apiKeyLocation -eq "QUERY") {
        $authPolicy = @"
            <!-- Add API key to query parameters -->
            <set-query-parameter name="$apiKeyName" exists-action="override">
                <value>$apiKeyValue</value>
            </set-query-parameter>
"@
    }
    else {
        $authPolicy = @"
            <!-- Add API key to backend request headers -->
            <set-header name="$apiKeyName" exists-action="override">
                <value>$apiKeyValue</value>
            </set-header>
"@
    }
    
    return @"
        <!-- Backend API Key Authentication -->
        $retryPolicy
        $authPolicy
        
        <!-- Log backend authentication -->
        <trace source="Backend-ApiKey-Auth">
            Backend API Key authentication configured for $apiKeyName
        </trace>
        $retryPolicyClose
"@
}

function New-OutboundOAuthPolicy {
    [CmdletBinding()]
    param(
        [object]$Profile,
        [switch]$IncludeRetry
    )
    
    $providerProfile = $Profile.parameters.providerProfile ?? "{{oauth-provider-profile}}"
    $ownerId = $Profile.parameters.ownerId ?? "{{oauth-owner-id}}"
    $tokenEndpoint = $Profile.parameters.tokenEndpoint ?? "{{oauth-token-endpoint}}"
    $clientId = $Profile.parameters.clientId ?? "{{oauth-client-id}}"
    $clientSecret = $Profile.parameters.clientSecret ?? "{{oauth-client-secret}}"
    $scope = $Profile.parameters.scope ?? ""
    
    $retryPolicy = if ($IncludeRetry) {
        @"
        <retry condition="@(context.Response.StatusCode >= 500 || context.Response.StatusCode == 429)" 
               count="3" interval="2" max-interval="30" delta="1">
"@
    } else { "" }
    
    $retryPolicyClose = if ($IncludeRetry) { "</retry>" } else { "" }
    
    return @"
        <!-- Backend OAuth Authentication -->
        $retryPolicy
        
        <!-- Obtain OAuth token for backend -->
        <send-request mode="new" response-variable-name="tokenResponse" timeout="20" ignore-error="false">
            <set-url>$tokenEndpoint</set-url>
            <set-method>POST</set-method>
            <set-header name="Content-Type" exists-action="override">
                <value>application/x-www-form-urlencoded</value>
            </set-header>
            <set-header name="Authorization" exists-action="override">
                <value>Basic @(Convert.ToBase64String(Encoding.UTF8.GetBytes("$clientId" + ":" + "$clientSecret")))</value>
            </set-header>
            <set-body>@{
                var body = "grant_type=client_credentials";
                if (!string.IsNullOrEmpty("$scope")) {
                    body += "&scope=$scope";
                }
                return body;
            }</set-body>
        </send-request>
        
        <!-- Extract and use access token -->
        <choose>
            <when condition="@(((IResponse)context.Variables["tokenResponse"]).StatusCode == 200)">
                <set-variable name="backendAccessToken" value="@{
                    var response = ((IResponse)context.Variables["tokenResponse"]).Body.As<JObject>();
                    return response["access_token"].ToString();
                }" />
                
                <set-header name="Authorization" exists-action="override">
                    <value>@("Bearer " + (string)context.Variables["backendAccessToken"])</value>
                </set-header>
                
                <trace source="Backend-OAuth-Auth">
                    Backend OAuth token obtained successfully
                </trace>
            </when>
            <otherwise>
                <trace source="Backend-OAuth-Auth-Error">
                    Failed to obtain backend OAuth token
                </trace>
                <return-response>
                    <set-status code="502" reason="Bad Gateway" />
                    <set-body>@("Failed to authenticate with backend service")</set-body>
                </return-response>
            </otherwise>
        </choose>
        
        $retryPolicyClose
"@
}

function New-OutboundBasicAuthPolicy {
    [CmdletBinding()]
    param(
        [object]$Profile,
        [switch]$IncludeRetry
    )
    
    $username = $Profile.parameters.username ?? "{{backend-basic-username}}"
    $password = $Profile.parameters.password ?? "{{backend-basic-password}}"
    
    $retryPolicy = if ($IncludeRetry) {
        @"
        <retry condition="@(context.Response.StatusCode >= 500 || context.Response.StatusCode == 429)" 
               count="3" interval="2" max-interval="30" delta="1">
"@
    } else { "" }
    
    $retryPolicyClose = if ($IncludeRetry) { "</retry>" } else { "" }
    
    return @"
        <!-- Backend Basic Authentication -->
        $retryPolicy
        
        <set-header name="Authorization" exists-action="override">
            <value>@("Basic " + Convert.ToBase64String(Encoding.UTF8.GetBytes("$username" + ":" + "$password")))</value>
        </set-header>
        
        <trace source="Backend-Basic-Auth">
            Backend basic authentication configured
        </trace>
        
        $retryPolicyClose
"@
}

function New-OutboundSSLPolicy {
    [CmdletBinding()]
    param(
        [object]$Profile,
        [switch]$IncludeRetry
    )
    
    $certFile = $Profile.parameters.certFile ?? ""
    $password = $Profile.parameters.password ?? ""
    $trustAll = $Profile.parameters.trustAll ?? $false
    
    $retryPolicy = if ($IncludeRetry) {
        @"
        <retry condition="@(context.Response.StatusCode >= 500 || context.Response.StatusCode == 429)" 
               count="3" interval="2" max-interval="30" delta="1">
"@
    } else { "" }
    
    $retryPolicyClose = if ($IncludeRetry) { "</retry>" } else { "" }
    
    return @"
        <!-- Backend SSL Certificate Authentication -->
        $retryPolicy
        
        <!-- Note: SSL client certificate authentication is configured at the backend service level in APIM -->
        <!-- Certificate should be uploaded to APIM and referenced in backend configuration -->
        
        <trace source="Backend-SSL-Auth">
            Backend SSL certificate authentication configured
        </trace>
        
        <!-- Add custom headers for SSL authentication context -->
        <set-header name="X-SSL-Client-Cert" exists-action="override">
            <value>{{backend-ssl-cert-reference}}</value>
        </set-header>
        
        $retryPolicyClose
"@
}

function New-OutboundCustomPolicy {
    [CmdletBinding()]
    param(
        [object]$Profile,
        [switch]$IncludeRetry
    )
    
    $customPolicy = $Profile.parameters.customPolicy ?? "Default Custom Backend Policy"
    
    $retryPolicy = if ($IncludeRetry) {
        @"
        <retry condition="@(context.Response.StatusCode >= 500 || context.Response.StatusCode == 429)" 
               count="3" interval="2" max-interval="30" delta="1">
"@
    } else { "" }
    
    $retryPolicyClose = if ($IncludeRetry) { "</retry>" } else { "" }
    
    return @"
        <!-- Custom Backend Authentication -->
        $retryPolicy
        
        <!-- Custom authentication logic - replace with actual implementation -->
        <send-request mode="new" response-variable-name="customAuthResponse" timeout="20" ignore-error="false">
            <set-url>{{custom-backend-auth-service-url}}</set-url>
            <set-method>POST</set-method>
            <set-header name="Content-Type" exists-action="override">
                <value>application/json</value>
            </set-header>
            <set-body>@{
                return JsonConvert.SerializeObject(new {
                    apiPath = context.Request.Url.Path,
                    method = context.Request.Method,
                    policy = "$customPolicy"
                });
            }</set-body>
        </send-request>
        
        <!-- Apply custom authentication result -->
        <choose>
            <when condition="@(((IResponse)context.Variables["customAuthResponse"]).StatusCode == 200)">
                <set-variable name="customAuthResult" value="@(((IResponse)context.Variables["customAuthResponse"]).Body.As<JObject>())" />
                
                <!-- Apply custom headers based on response -->
                <set-header name="X-Custom-Auth-Token" exists-action="override">
                    <value>@{
                        var result = (JObject)context.Variables["customAuthResult"];
                        return result["token"]?.ToString() ?? "";
                    }</value>
                </set-header>
                
                <trace source="Backend-Custom-Auth">
                    Custom backend authentication successful
                </trace>
            </when>
            <otherwise>
                <trace source="Backend-Custom-Auth-Error">
                    Custom backend authentication failed
                </trace>
                <return-response>
                    <set-status code="502" reason="Bad Gateway" />
                    <set-body>@("Failed to authenticate with backend service using custom policy")</set-body>
                </return-response>
            </otherwise>
        </choose>
        
        $retryPolicyClose
"@
}

function New-DefaultBackendPolicy {
    [CmdletBinding()]
    param(
        [object]$Profile,
        [switch]$IncludeRetry
    )
    
    $retryPolicy = if ($IncludeRetry) {
        @"
        <retry condition="@(context.Response.StatusCode >= 500 || context.Response.StatusCode == 429)" 
               count="3" interval="2" max-interval="30" delta="1">
"@
    } else { "" }
    
    $retryPolicyClose = if ($IncludeRetry) { "</retry>" } else { "" }
    
    return @"
        <!-- Default Backend Policy - No Authentication -->
        $retryPolicy
        
        <!-- Add standard backend headers -->
        <set-header name="X-Forwarded-For" exists-action="override">
            <value>@(context.Request.IpAddress)</value>
        </set-header>
        
        <set-header name="X-Forwarded-Proto" exists-action="override">
            <value>@(context.Request.Url.Scheme)</value>
        </set-header>
        
        <!-- Log backend call -->
        <trace source="Backend-Default">
            Default backend policy applied - no authentication
        </trace>
        
        $retryPolicyClose
"@
}

function Get-OutboundAuthenticationType {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [object]$Profile
    )
    
    # Determine authentication type from profile parameters
    if ($Profile.parameters) {
        if ($Profile.parameters.apiKeyName -or $Profile.parameters.apiKeyValue) {
            return "apikey"
        }
        elseif ($Profile.parameters.providerProfile -or $Profile.parameters.tokenEndpoint) {
            return "oauth"
        }
        elseif ($Profile.parameters.username -and $Profile.parameters.password) {
            return "basic"
        }
        elseif ($Profile.parameters.certFile) {
            return "ssl"
        }
        elseif ($Profile.parameters.customPolicy) {
            return "custom"
        }
    }
    
    # Check for type field
    if ($Profile.type) {
        return $Profile.type.ToLower()
    }
    
    # Default to passthrough
    return "default"
}

#endregion

#region Additional Conversion Functions

function Convert-AxwayCorsProfile {
    <#
    .SYNOPSIS
        Converts Axway CORS profiles to Azure APIM CORS policy configuration
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [object]$CorsProfiles
    )
    
    $corsConfig = @{}
    
    foreach ($profile in $CorsProfiles) {
        $origins = $profile.origins -join ", "
        $allowedHeaders = $profile.allowedHeaders -join ", "
        $exposedHeaders = $profile.exposedHeaders -join ", "
        $supportCredentials = $profile.supportCredentials ?? $false
        $maxAgeSeconds = $profile.maxAgeSeconds ?? 0
        
        $corsPolicy = @"
        <cors allow-credentials="$($supportCredentials.ToString().ToLower())">
            <allowed-origins>
$(foreach ($origin in $profile.origins) {
    "                <origin>$origin</origin>"
})
            </allowed-origins>
            <allowed-methods>
                <method>GET</method>
                <method>POST</method>
                <method>PUT</method>
                <method>DELETE</method>
                <method>PATCH</method>
                <method>OPTIONS</method>
            </allowed-methods>
            <allowed-headers>
$(foreach ($header in $profile.allowedHeaders) {
    "                <header>$header</header>"
})
            </allowed-headers>
$(if ($profile.exposedHeaders -and $profile.exposedHeaders.Count -gt 0) {
    "            <expose-headers>"
    foreach ($header in $profile.exposedHeaders) {
        "                <header>$header</header>"
    }
    "            </expose-headers>"
})
$(if ($maxAgeSeconds -gt 0) {
    "            <preflight-result-max-age>$maxAgeSeconds</preflight-result-max-age>"
})
        </cors>
"@
        
        $corsConfig[$profile.name] = $corsPolicy
    }
    
    return $corsConfig
}

function Convert-AxwayCustomProperties {
    <#
    .SYNOPSIS
        Converts Axway custom properties to Azure APIM Named Values
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [object]$CustomProperties
    )
    
    $namedValues = @{}
    
    foreach ($property in $CustomProperties.PSObject.Properties) {
        $namedValues[$property.Name] = @{
            DisplayName = $property.Name
            Value = $property.Value
            Secret = $false
            Tags = @("custom-property", "axway-migration")
        }
    }
    
    return $namedValues
}

function Convert-AxwayQuotaSettings {
    <#
    .SYNOPSIS
        Converts Axway quota settings to Azure APIM rate limiting policies
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [object]$ApiConfig
    )
    
    $quotaPolicies = @{}
    
    # Convert Application Quota
    if ($ApiConfig.applicationQuota -and $ApiConfig.applicationQuota.restrictions) {
        $appQuotaPolicy = New-QuotaPolicy -QuotaConfig $ApiConfig.applicationQuota -QuotaType "application"
        $quotaPolicies["applicationQuota"] = $appQuotaPolicy
    }
    
    # Convert System Quota
    if ($ApiConfig.systemQuota -and $ApiConfig.systemQuota.restrictions) {
        $systemQuotaPolicy = New-QuotaPolicy -QuotaConfig $ApiConfig.systemQuota -QuotaType "system"
        $quotaPolicies["systemQuota"] = $systemQuotaPolicy
    }
    
    return $quotaPolicies
}

function New-QuotaPolicy {
    [CmdletBinding()]
    param(
        [object]$QuotaConfig,
        [string]$QuotaType
    )
    
    $policies = @()
    
    foreach ($restriction in $QuotaConfig.restrictions) {
        $method = $restriction.method ?? "*"
        $type = $restriction.type ?? "throttle"
        $config = $restriction.config
        
        $period = $config.period ?? "hour"
        $per = $config.per ?? 1
        $messages = $config.messages ?? 1000
        
        # Convert period to seconds
        $periodSeconds = switch ($period) {
            "second" { $per }
            "minute" { $per * 60 }
            "hour" { $per * 3600 }
            "day" { $per * 86400 }
            default { $per * 3600 }
        }
        
        $counterKey = switch ($QuotaType) {
            "application" { "@(context.Subscription?.Key ?? context.Request.IpAddress)" }
            "system" { "@("system-quota")" }
            default { "@(context.Request.IpAddress)" }
        }
        
        $policy = @"
        <!-- $QuotaType Quota for method: $method -->
        <rate-limit-by-key calls="$messages" 
                          renewal-period="$periodSeconds" 
                          counter-key="$counterKey" />
"@
        
        $policies += $policy
    }
    
    return $policies -join "`n"
}

function Convert-AxwayCertificates {
    <#
    .SYNOPSIS
        Converts Axway certificate configuration to Azure APIM certificate settings
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [array]$Certificates
    )
    
    $certConfig = @{
        InboundCertificates = @()
        OutboundCertificates = @()
        Instructions = @()
    }
    
    foreach ($cert in $Certificates) {
        $certInfo = @{
            CertFile = $cert.certFile
            UseForInbound = $cert.inbound ?? $cert.useForInbound ?? $false
            UseForOutbound = $cert.outbound ?? $cert.useForOutbound ?? $true
        }
        
        if ($certInfo.UseForInbound) {
            $certConfig.InboundCertificates += $certInfo
        }
        
        if ($certInfo.UseForOutbound) {
            $certConfig.OutboundCertificates += $certInfo
        }
        
        $certConfig.Instructions += "Upload certificate '$($cert.certFile)' to Azure APIM and configure for $(if($certInfo.UseForInbound){"inbound "})$(if($certInfo.UseForOutbound){"outbound"}) use"
    }
    
    return $certConfig
}

function Convert-ApiDefinition {
    <#
    .SYNOPSIS
        Converts Axway API definition configuration to Azure APIM API format
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [object]$Config
    )
    
    $apiDefinition = @{
        ApiId = ($Config.name -replace "[^a-zA-Z0-9-]", "-").ToLower()
        DisplayName = $Config.name
        Path = $Config.path
        ServiceUrl = $Config.backendBasepath
        Protocols = @("https")
        SubscriptionRequired = $true
        State = $Config.state ?? "unpublished"
        Description = Get-ApiDescription -Config $Config
        Version = $Config.version ?? "1.0.0"
        ApiVersion = $Config.apiRoutingKey
        VirtualHost = $Config.vhost
    }
    
    # Handle API specification
    if ($Config.apiDefinition -or $Config.apiSpecification) {
        $apiDefinition.SpecificationFormat = "openapi+json"
        $apiDefinition.SpecificationPath = $Config.apiDefinition ?? $Config.apiSpecification
    }
    
    return $apiDefinition
}

function Get-ApiDescription {
    [CmdletBinding()]
    param(
        [object]$Config
    )
    
    switch ($Config.descriptionType) {
        "manual" { return $Config.descriptionManual ?? "" }
        "url" { return "Documentation URL: $($Config.descriptionUrl)" }
        "markdown" { return "Markdown file: $($Config.descriptionMarkdown)" }
        "markdownLocal" { return "Local markdown files: $($Config.markdownLocal -join ", ")" }
        default { return $Config.summary ?? "API migrated from Axway Gateway" }
    }
}

function New-CombinedApimPolicy {
    <#
    .SYNOPSIS
        Generates a combined Azure APIM policy from all conversion artifacts
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [object]$ConversionArtifacts
    )
    
    $inboundPolicies = @()
    $backendPolicies = @()
    $outboundPolicies = @()
    $onErrorPolicies = @()
    
    # Collect inbound policies
    if ($ConversionArtifacts.inboundPolicies) {
        foreach ($policy in $ConversionArtifacts.inboundPolicies.Values) {
            if ($policy -match '<inbound>(.*?)</inbound>') {
                $inboundPolicies += $matches[1]
            }
        }
    }
    
    # Collect backend policies
    if ($ConversionArtifacts.outboundPolicies) {
        foreach ($policy in $ConversionArtifacts.outboundPolicies.Values) {
            $backendPolicies += $policy
        }
    }
    
    # Add CORS configuration
    if ($ConversionArtifacts.corsConfiguration) {
        $corsPolicy = $ConversionArtifacts.corsConfiguration.Values | Select-Object -First 1
        $inboundPolicies += $corsPolicy
    }
    
    # Add quota policies
    if ($ConversionArtifacts.quotaConfiguration) {
        foreach ($quotaPolicy in $ConversionArtifacts.quotaConfiguration.Values) {
            $inboundPolicies += $quotaPolicy
        }
    }
    
    # Combine all policies
    $combinedPolicy = @"
<policies>
    <inbound>
        <base />
$($inboundPolicies -join "`n        ")
    </inbound>
    <backend>
        <base />
$($backendPolicies -join "`n        ")
    </backend>
    <outbound>
        <base />
$($outboundPolicies -join "`n        ")
    </outbound>
    <on-error>
        <base />
$($onErrorPolicies -join "`n        ")
    </on-error>
</policies>
"@
    
    return $combinedPolicy
}

function Save-ConversionArtifacts {
    <#
    .SYNOPSIS
        Saves all conversion artifacts to the specified output directory
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [object]$Report,
        
        [Parameter(Mandatory = $true)]
        [string]$OutputPath,
        
        [Parameter(Mandatory = $true)]
        [string]$CombinedPolicy
    )
    
    # Save main policy file
    $CombinedPolicy | Out-File -FilePath "$OutputPath/apim-policy.xml" -Encoding UTF8
    
    # Save API definition
    if ($Report.GeneratedArtifacts.apiDefinition) {
        $Report.GeneratedArtifacts.apiDefinition | ConvertTo-Json -Depth 5 | Out-File -FilePath "$OutputPath/api-definition.json" -Encoding UTF8
    }
    
    # Save Named Values configuration
    if ($Report.GeneratedArtifacts.customProperties) {
        $Report.GeneratedArtifacts.customProperties | ConvertTo-Json -Depth 3 | Out-File -FilePath "$OutputPath/named-values.json" -Encoding UTF8
    }
    
    # Save conversion report
    $Report | ConvertTo-Json -Depth 10 | Out-File -FilePath "$OutputPath/conversion-report.json" -Encoding UTF8
    
    # Save certificate instructions
    if ($Report.GeneratedArtifacts.certificateConfiguration) {
        $Report.GeneratedArtifacts.certificateConfiguration.Instructions | Out-File -FilePath "$OutputPath/certificate-instructions.txt" -Encoding UTF8
    }
    
    Write-Host "✅ Artifacts saved to: $OutputPath" -ForegroundColor Green
}

function New-InfrastructureTemplates {
    <#
    .SYNOPSIS
        Generates Azure infrastructure templates for the migrated API
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [object]$ApiConfig,
        
        [Parameter(Mandatory = $true)]
        [string]$OutputPath
    )
    
    # Generate ARM template for the specific API
    $armTemplate = @{
        '$schema' = "https://schema.management.azure.com/schemas/2019-04-01/deploymentTemplate.json#"
        contentVersion = "1.0.0.0"
        parameters = @{
            apimServiceName = @{
                type = "string"
                metadata = @{
                    description = "Name of the API Management service"
                }
            }
        }
        resources = @(
            @{
                type = "Microsoft.ApiManagement/service/apis"
                apiVersion = "2021-08-01"
                name = "[concat(parameters('apimServiceName'), '/$($ApiConfig.name -replace "[^a-zA-Z0-9-]", "-")')]"
                properties = @{
                    displayName = $ApiConfig.name
                    path = $ApiConfig.path
                    serviceUrl = $ApiConfig.backendBasepath
                    protocols = @("https")
                }
            }
        )
    }
    
    $armTemplate | ConvertTo-Json -Depth 10 | Out-File -FilePath "$OutputPath/api-infrastructure.json" -Encoding UTF8
    
    return @{
        ArmTemplate = "api-infrastructure.json"
        Instructions = "Deploy using: az deployment group create --resource-group <rg-name> --template-file api-infrastructure.json"
    }
}

#endregion

# Export module members
Export-ModuleMember -Function $FunctionsToExport

# Module initialization
Write-Host "Enhanced AxwayToApimConverter module loaded. Version: $ModuleVersion" -ForegroundColor Green
Write-Host "New features: Complete API Configuration + Outbound Authentication support" -ForegroundColor Cyan
Write-Host "Use 'Get-Command -Module AxwayToApimConverter' to see available functions" -ForegroundColor Yellow
