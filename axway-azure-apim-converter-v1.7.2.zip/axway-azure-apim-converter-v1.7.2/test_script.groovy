import com.vordel.circuit.Message;

def invoke(msg) {
    // This is a sample Groovy script
    return true;
}
