# Method-Level Inbound Profiles - Python vs Web Converter Comparison

## Test Input

Configuration with method-level inbound profiles:
- **Operation**: `findPetsByStatus`
- **Security Profile**: API-Key (header: `KeyId`)
- **CORS Profile**: Custom CORS with specific origins and headers

## Python Converter Output (v1.2.0)

```xml
<policies>
  <inbound>
    <base/>
    <!-- Method-Level Inbound Overrides -->
    <choose>
      <when condition="@(context.Operation.Id == &quot;findPetsByStatus&quot;)">
        <check-header name="KeyId" failed-check-httpcode="401" failed-check-error-message="Unauthorized" ignore-case="false"/>
        <cors allow-credentials="false">
          <allowed-origins>
            <origin>*</origin>
          </allowed-origins>
          <allowed-headers>
            <header>Authorization</header>
          </allowed-headers>
          <exposed-headers>
            <header>via</header>
          </exposed-headers>
        </cors>
      </when>
    </choose>

  </inbound>
  <backend>
    <base/>
  </backend>
  <outbound>
    <base/>
  </outbound>
  <on-error>
    <base/>
  </on-error>
  <!-- Conversion Statistics: 0/0 filters converted (0% success rate) -->
</policies>
```

## Web Converter Output (v1.7.0)

```xml
<policies>
  <inbound>
    <base/>
    <!-- Method-Level Inbound Overrides -->
    <choose>
      <when condition="@(context.Operation.Id == &quot;findPetsByStatus&quot;)">
        <check-header name="KeyId" failed-check-httpcode="401" failed-check-error-message="Unauthorized" ignore-case="false"/>
        <cors allow-credentials="false">
          <allowed-origins>
            <origin>*</origin>
          </allowed-origins>
          <allowed-headers>
            <header>Authorization</header>
          </allowed-headers>
          <exposed-headers>
            <header>via</header>
          </exposed-headers>
        </cors>
      </when>
    </choose>

  </inbound>
  <backend>
    <base/>
  </backend>
  <outbound>
    <base/>
  </outbound>
  <on-error>
    <base/>
  </on-error>
  <!-- Conversion Statistics: 0/0 filters converted (0% success rate) -->
</policies>
```

## Comparison Results

### ✅ **PERFECT PARITY ACHIEVED**

Both converters generate **identical XML output** for method-level inbound profiles:

| Feature | Python v1.2.0 | Web v1.7.0 | Match |
|---------|--------------|------------|-------|
| `<choose>` block | ✓ | ✓ | ✅ |
| Operation ID condition | ✓ | ✓ | ✅ |
| API Key check-header | ✓ | ✓ | ✅ |
| CORS policy | ✓ | ✓ | ✅ |
| CORS allowed-origins | ✓ | ✓ | ✅ |
| CORS allowed-headers | ✓ | ✓ | ✅ |
| CORS exposed-headers | ✓ | ✓ | ✅ |
| XML formatting | ✓ | ✓ | ✅ |
| Comment placement | ✓ | ✓ | ✅ |

### Key Features Verified

1. **Conditional Logic**: Both generate `<choose>` blocks with `<when>` conditions based on `context.Operation.Id`
2. **Security Policy**: API Key validation via `<check-header>` with correct header name (`KeyId`)
3. **CORS Configuration**: Complete CORS policy with:
   - `allow-credentials="false"`
   - Allowed origins: `*`
   - Allowed headers: `Authorization`
   - Exposed headers: `via`
4. **XML Structure**: Identical indentation, element ordering, and attribute formatting

### Conclusion

✅ **The fix in v1.7.0 successfully achieves 100% parity with the Python converter** for method-level inbound profiles. The web converter now correctly processes `inboundProfiles` and generates operation-specific security and CORS policies.
