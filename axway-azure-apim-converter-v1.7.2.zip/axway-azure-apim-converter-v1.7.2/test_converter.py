#!/usr/bin/env python3
"""
Simple test script for the Axway to Azure APIM converter
Avoids Unicode encoding issues by using simple ASCII output
"""

import sys
import os
from pathlib import Path

# Set UTF-8 encoding for output
if sys.platform == 'win32':
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')

# Add src to path
sys.path.insert(0, str(Path(__file__).parent / 'src'))

from strategic_filter_converter_xml import StrategicFilterConverter

def test_converter():
    """Test the converter with available example files"""
    
    print("=" * 80)
    print("TESTING AXWAY TO AZURE APIM CONVERTER")
    print("=" * 80)
    print()
    
    # Initialize converter
    converter = StrategicFilterConverter()
    print("[OK] Converter initialized successfully")
    print()
    
    # Find example YAML files
    examples_dir = Path(__file__).parent / 'examples' / 'enterprise_policies'
    
    if not examples_dir.exists():
        print(f"[ERROR] Examples directory not found: {examples_dir}")
        return False
    
    yaml_files = list(examples_dir.glob('*.yaml')) + list(examples_dir.glob('*.yml'))
    
    if not yaml_files:
        print(f"[ERROR] No YAML files found in: {examples_dir}")
        return False
    
    print(f"[OK] Found {len(yaml_files)} example policy files:")
    for f in yaml_files:
        print(f"  - {f.name}")
    print()
    
    # Create output directory
    output_dir = Path(__file__).parent / 'policies' / 'xml'
    output_dir.mkdir(parents=True, exist_ok=True)
    print(f"[OK] Output directory: {output_dir}")
    print()
    
    # Test conversions
    print("=" * 80)
    print("RUNNING CONVERSIONS")
    print("=" * 80)
    print()
    
    success_count = 0
    total_count = len(yaml_files)
    
    for yaml_file in yaml_files:
        output_file = output_dir / f"{yaml_file.stem}-converted.xml"
        
        print(f"Converting: {yaml_file.name}")
        print(f"  Input:  {yaml_file}")
        print(f"  Output: {output_file}")
        
        try:
            result = converter.convert_yaml_to_xml(str(yaml_file), str(output_file))
            
            if result.get('success'):
                print(f"  [SUCCESS] Conversion completed")
                if output_file.exists():
                    size = output_file.stat().st_size
                    print(f"  [OK] Generated XML file ({size} bytes)")
                    success_count += 1
                else:
                    print(f"  [WARNING] Output file not created")
            else:
                error = result.get('error', 'Unknown error')
                print(f"  [FAILED] {error}")
        except Exception as e:
            print(f"  [ERROR] {str(e)}")
        
        print()
    
    # Summary
    print("=" * 80)
    print("TEST SUMMARY")
    print("=" * 80)
    print(f"Total policies tested: {total_count}")
    print(f"Successful conversions: {success_count}")
    print(f"Failed conversions: {total_count - success_count}")
    print(f"Success rate: {(success_count/total_count*100):.1f}%")
    print()
    
    if success_count > 0:
        print("[OK] Generated XML files:")
        for xml_file in sorted(output_dir.glob('*-converted.xml')):
            print(f"  - {xml_file.name}")
        print()
        print("[OK] Converter is working correctly!")
        return True
    else:
        print("[ERROR] No successful conversions")
        return False

if __name__ == '__main__':
    success = test_converter()
    sys.exit(0 if success else 1)
