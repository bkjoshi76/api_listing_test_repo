# Deploy-Backend.ps1
# Deploys the Axway Converter Python Backend to Azure Functions

param(
    [Parameter(Mandatory = $true)]
    [string]$ResourceGroupName,

    [Parameter(Mandatory = $true)]
    [string]$Location = "eastus2",

    [Parameter(Mandatory = $true)]
    [string]$AppName = "axway-converter-func",

    [Parameter(Mandatory = $true)]
    [string]$StorageAccountName
)

$ErrorActionPreference = "Stop"

Write-Host "🚀 Deploying Axway Converter Backend to Azure Functions..." -ForegroundColor Cyan

# 1. Check Prerequisites
Write-Host "🔍 Checking prerequisites..." -ForegroundColor Yellow
if (-not (Get-Command "az" -ErrorAction SilentlyContinue)) {
    throw "Azure CLI (az) is not installed."
}
if (-not (Get-Command "func" -ErrorAction SilentlyContinue)) {
    Write-Warning "Azure Functions Core Tools (func) is not installed. Deployment will rely on 'az functionapp'."
}

# 2. Prepare Deployment Package
Write-Host "📦 Preparing deployment package..." -ForegroundColor Yellow
$tempDir = Join-Path $PSScriptRoot "temp_deploy"
if (Test-Path $tempDir) { Remove-Item $tempDir -Recurse -Force }
New-Item -Path $tempDir -ItemType Directory | Out-Null

# Copy Converter Script
Copy-Item (Join-Path $PSScriptRoot "../scripts/fully_validated_converter.py") $tempDir

# Create host.json
$hostJson = @{
    version         = "2.0"
    logging         = @{
        applicationInsights = @{
            samplingSettings = @{
                isEnabled     = $true
                excludedTypes = "Request"
            }
        }
    }
    extensionBundle = @{
        id      = "Microsoft.Azure.Functions.ExtensionBundle"
        version = "[4.*, 5.0.0)"
    }
}
$hostJson | ConvertTo-Json -Depth 5 | Out-File (Join-Path $tempDir "host.json") -Encoding UTF8

# Create requirements.txt
"azure-functions`npyyaml" | Out-File (Join-Path $tempDir "requirements.txt") -Encoding UTF8

# Create Function Directory
$funcDir = Join-Path $tempDir "Convert"
New-Item -Path $funcDir -ItemType Directory | Out-Null

# Create function.json
$functionJson = @{
    scriptFile = "__init__.py"
    bindings   = @(
        @{
            authLevel = "function"
            type      = "httpTrigger"
            direction = "in"
            name      = "req"
            methods   = @("post")
        },
        @{
            type      = "http"
            direction = "out"
            name      = "$return"
        }
    )
}
$functionJson | ConvertTo-Json -Depth 5 | Out-File (Join-Path $funcDir "function.json") -Encoding UTF8

# Create __init__.py wrapper
$initPy = @"
import logging
import azure.functions as func
import json
import sys
import os

# Add parent dir to path to import converter
sys.path.append(os.path.dirname(os.path.dirname(os.path.realpath(__file__))))
from fully_validated_converter import AxwayToApimConverter

def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')

    try:
        req_body = req.get_json()
    except ValueError:
        return func.HttpResponse(
             "Invalid JSON body",
             status_code=400
        )

    try:
        converter = AxwayToApimConverter()
        # The converter expects a dict, which req_body is
        xml_output = converter.convert_to_apim_xml(req_body)
        
        return func.HttpResponse(
            xml_output,
            mimetype="application/xml",
            status_code=200
        )
    except Exception as e:
        logging.error(f"Conversion error: {str(e)}")
        return func.HttpResponse(
            f"Conversion failed: {str(e)}",
            status_code=500
        )
"@
$initPy | Out-File (Join-Path $funcDir "__init__.py") -Encoding UTF8

# Zip Package
$zipPath = Join-Path $PSScriptRoot "backend_deploy.zip"
Compress-Archive -Path "$tempDir/*" -DestinationPath $zipPath -Force
Write-Host "✅ Deployment package created: $zipPath" -ForegroundColor Green

# 3. Create Azure Resources
Write-Host "🏗️ Creating/Updating Azure Resources..." -ForegroundColor Yellow

# Resource Group
az group create --name $ResourceGroupName --location $Location | Out-Null

# Storage Account
Write-Host "  Creating Storage Account '$StorageAccountName'..." -ForegroundColor Gray
az storage account create --name $StorageAccountName --resource-group $ResourceGroupName --location $Location --sku Standard_LRS | Out-Null

# Function App
Write-Host "  Creating Function App '$AppName'..." -ForegroundColor Gray
az functionapp create --resource-group $ResourceGroupName --consumption-plan-location $Location --runtime python --runtime-version 3.9 --functions-version 4 --name $AppName --storage-account $StorageAccountName --os-type Linux | Out-Null

# 4. Deploy
Write-Host "🚀 Deploying Function App..." -ForegroundColor Yellow
# Wait a bit for resources to settle
Start-Sleep -Seconds 10

az functionapp deployment source config-zip --resource-group $ResourceGroupName --name $AppName --src $zipPath | Out-Null

Write-Host "✅ Deployment complete!" -ForegroundColor Green
Write-Host "🌍 Function URL: https://$AppName.azurewebsites.net/api/Convert" -ForegroundColor Cyan

# Cleanup
Remove-Item $tempDir -Recurse -Force
Remove-Item $zipPath -Force
