# Deploy-WebUI.ps1
# Deploys the Axway Converter Web UI to Azure Static Web Apps

param(
    [Parameter(Mandatory = $true)]
    [string]$ResourceGroupName,

    [Parameter(Mandatory = $true)]
    [string]$Location = "eastus2",

    [Parameter(Mandatory = $true)]
    [string]$AppName = "axway-converter-web",

    [Parameter(Mandatory = $false)]
    [string]$Sku = "Free"
)

$ErrorActionPreference = "Stop"

Write-Host "🚀 Deploying Axway Converter Web UI to Azure..." -ForegroundColor Cyan

# 1. Check Prerequisites
Write-Host "🔍 Checking prerequisites..." -ForegroundColor Yellow
if (-not (Get-Command "az" -ErrorAction SilentlyContinue)) {
    throw "Azure CLI (az) is not installed."
}
if (-not (Get-Command "npm" -ErrorAction SilentlyContinue)) {
    throw "Node.js (npm) is not installed."
}

# 2. Build Web App
Write-Host "📦 Building Web Application..." -ForegroundColor Yellow
$webDir = Join-Path $PSScriptRoot "../web"
Push-Location $webDir

try {
    Write-Host "  Running npm install..." -ForegroundColor Gray
    npm install | Out-Null
    
    Write-Host "  Running npm run build..." -ForegroundColor Gray
    npm run build | Out-Null
}
finally {
    Pop-Location
}

$distDir = Join-Path $webDir "dist"
if (-not (Test-Path $distDir)) {
    throw "Build failed. 'dist' directory not found."
}
Write-Host "✅ Build successful." -ForegroundColor Green

# 3. Create Resource Group
Write-Host "🏗️ Creating/Updating Resource Group '$ResourceGroupName'..." -ForegroundColor Yellow
az group create --name $ResourceGroupName --location $Location | Out-Null

# 4. Create Static Web App
Write-Host "🌐 Creating Azure Static Web App '$AppName'..." -ForegroundColor Yellow
# Note: Creating a SWA usually requires a repo token for CI/CD, but for manual deployment we create it and then deploy.
# We use 'az staticwebapp create' with a dummy repo URL if needed, or just create the resource.
# Actually, for manual deployment (no GitHub), we just need the resource.
# However, CLI creation often expects a repo. 
# A better approach for manual deployment is to create it without source control link if possible, or use 'az staticwebapp create' and then 'az staticwebapp deploy'.

# Check if exists
$swa = az staticwebapp show --name $AppName --resource-group $ResourceGroupName 2>$null | ConvertFrom-Json

if (-not $swa) {
    Write-Host "  Creating new Static Web App..." -ForegroundColor Gray
    # Creating without a repo link allows for manual deployment via token
    az staticwebapp create --name $AppName --resource-group $ResourceGroupName --location $Location --sku $Sku --source https://github.com/placeholder/repo --branch main --token "manual-deployment" | Out-Null
    # Note: The CLI might enforce repo connection. 
    # Alternative: Use 'az staticwebapp create' and let it fail on repo or use a disconnected mode if available.
    # Actually, the standard way to deploy from local is getting a deployment token.
}

# 5. Deploy Content
Write-Host "🚀 Deploying content..." -ForegroundColor Yellow
$deploymentToken = az staticwebapp secrets list --name $AppName --resource-group $ResourceGroupName --query "properties.apiKey" -o tsv

if (-not $deploymentToken) {
    throw "Failed to retrieve deployment token."
}

# Use SWA CLI if available, or Azure CLI 'az staticwebapp deploy' (in preview/available)
# 'az staticwebapp deploy' uploads local content.
az staticwebapp deploy --name $AppName --resource-group $ResourceGroupName --source $distDir --deployment-token $deploymentToken | Out-Null

Write-Host "✅ Deployment complete!" -ForegroundColor Green
$appUrl = az staticwebapp show --name $AppName --resource-group $ResourceGroupName --query "defaultHostname" -o tsv
Write-Host "🌍 App URL: https://$appUrl" -ForegroundColor Cyan
