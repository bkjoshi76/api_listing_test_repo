import sys
import xml.etree.ElementTree as ET

def normalize_xml(xml_string):
    """Normalize XML by removing comments, whitespace, and sorting attributes."""
    try:
        # Parse
        parser = ET.XMLParser(target=ET.TreeBuilder(insert_comments=False))
        root = ET.fromstring(xml_string, parser=parser)
        
        # Canonicalize (simple version)
        return ET.tostring(root, method='xml', encoding='unicode')
    except Exception as e:
        return f"Error parsing XML: {e}"

def compare(file1, file2):
    with open(file1, 'r') as f:
        c1 = f.read()
    with open(file2, 'r') as f:
        c2 = f.read()
        
    n1 = normalize_xml(c1)
    n2 = normalize_xml(c2)
    
    if n1 == n2:
        print("MATCH: Files are identical (ignoring comments/whitespace)")
        sys.exit(0)
    else:
        print("MISMATCH: Files differ")
        # Print diff length
        print(f"File 1 length: {len(n1)}")
        print(f"File 2 length: {len(n2)}")
        sys.exit(1)

if __name__ == "__main__":
    compare(sys.argv[1], sys.argv[2])
