import zipfile
import os

def zip_release():
    output_filename = 'axway_dashboard_release.zip'
    
    with zipfile.ZipFile(output_filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
        # Add backend
        for root, dirs, files in os.walk('backend'):
            if '__pycache__' in root:
                continue
            for file in files:
                if file.endswith('.pyc'):
                    continue
                file_path = os.path.join(root, file)
                zipf.write(file_path, arcname=file_path)
        
        # Add frontend (excluding node_modules)
        for root, dirs, files in os.walk('frontend'):
            if 'node_modules' in root:
                continue
            for file in files:
                file_path = os.path.join(root, file)
                zipf.write(file_path, arcname=file_path)
        
        # Add root files
        files_to_add = ['get_axway_apis.py', 'requirements.txt', 'README_RELEASE.md']
        for file in files_to_add:
            if os.path.exists(file):
                zipf.write(file, arcname=file)
                
    print(f"Created {output_filename}")

if __name__ == "__main__":
    zip_release()
