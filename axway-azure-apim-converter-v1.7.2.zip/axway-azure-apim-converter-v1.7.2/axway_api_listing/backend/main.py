from fastapi import FastAPI, HTTPException, Query, Response, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional, Union
import sys
import os
import random
import csv
import io
from datetime import datetime, timedelta

# Add parent directory to path to import get_axway_apis
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import get_axway_apis
from backend.metadata import MetadataStore

app = FastAPI(title="Axway API Dashboard")
metadata_store = MetadataStore()

# Enable CORS for frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, specify the frontend URL
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class HostConfig(BaseModel):
    host: str
    port: str = "8075"
    username: str
    password: str
    name: Optional[str] = None

class ApiProxy(BaseModel):
    host: str
    host_alias: str
    name: str
    path: str
    version: str
    state: str
    inbound_security: str
    outbound_security: str
    technical_complexity: str = "Low"
    business_complexity: str = "Low"
    notes: str = ""
    ignore: bool = False

class ComplexityUpdate(BaseModel):
    host: str
    name: str
    version: str
    field: str
    value: Union[str, bool]

class HostAliasUpdate(BaseModel):
    host: str
    alias: str

class FileAliasUpdate(BaseModel):
    filename: str
    alias: str

@app.get("/api/hosts")
def get_hosts():
    return {
        "hosts": metadata_store.metadata.get("_host_aliases", {}),
        "files": metadata_store.metadata.get("_file_aliases", {})
    }

@app.post("/api/hosts/alias")
def update_host_alias(update: HostAliasUpdate):
    metadata_store.set_host_alias(update.host, update.alias)
    return {"status": "success", "host": update.host, "alias": update.alias}

@app.post("/api/files/alias")
def update_file_alias(update: FileAliasUpdate):
    metadata_store.set_file_alias(update.filename, update.alias)
    return {"status": "success", "filename": update.filename, "alias": update.alias}

@app.post("/api/proxies", response_model=List[ApiProxy])
def get_proxies_list(configs: List[HostConfig]):
    all_proxies = []
    
    for config in configs:
        # Use stored alias if available, otherwise provided name, otherwise host
        stored_alias = metadata_store.get_host_alias(config.host)
        host_alias = stored_alias if stored_alias else (config.name if config.name and config.name.strip() else config.host)

        if config.host.lower().startswith("mock"):
            # Generate enhanced mock data based on environment
            env_type = config.host.lower().replace("mock-", "") if "-" in config.host else "prod"
            
            # Adjust weights based on environment
            if "prod" in env_type:
                state_weights = [0.9, 0.05, 0.05] # Mostly published
            elif "dev" in env_type:
                state_weights = [0.2, 0.7, 0.1]   # Mostly unpublished
            else:
                state_weights = [0.5, 0.4, 0.1]   # Mixed
                
            api_names = [
                "Payment Gateway", "User Service", "Inventory API", "Order Processing", 
                "Notification Service", "Analytics Engine", "Search API", "Authentication Provider",
                "Legacy CRM Adapter", "Partner Integration", "Mobile Backend", "IoT Ingest",
                "Data Warehouse Sync", "Email Service", "SMS Gateway", "Loyalty Program",
                "Product Catalog", "Shipping Calculator", "Tax Service", "Audit Log"
            ]
            
            # Add some randomness to the number of APIs based on env
            count = len(api_names) if "prod" in env_type else len(api_names) - 5
            
            for i, name in enumerate(api_names[:count]):
                version = f"1.{random.randint(0, 5)}"
                api_id = f"{config.host}:{name}:{version}"
                metadata = metadata_store.get_metadata(api_id)
                
                api_proxy = ApiProxy(
                    host=config.host,
                    host_alias=host_alias,
                    name=name,
                    path=f"/api/v1/{name.lower().replace(' ', '-')}",
                    version=version,
                    state=random.choices(["published", "unpublished", "deprecated"], weights=state_weights)[0],
                    inbound_security=metadata.get("inbound_security", random.choice(["apiKey", "oauth", "passthrough", "aws_signature"])),
                    outbound_security=metadata.get("outbound_security", random.choice(["oauth", "mtls", "none"])),
                    technical_complexity=metadata.get("technical_complexity", "Low"),
                    business_complexity=metadata.get("business_complexity", "Low"),
                    notes=metadata.get("notes", ""),
                    ignore=metadata.get("ignore", False)
                )
                
                if not api_proxy.ignore:
                    # Check for passThrough filter
                    if api_proxy.inbound_security.lower() == "passthrough":
                        continue
                    all_proxies.append(api_proxy)
            continue

        try:
            proxies = get_axway_apis.get_proxies(config.host, config.port, config.username, config.password)
            if proxies:
                for proxy in proxies:
                    inbound, outbound = get_axway_apis.parse_security(proxy)
                    
                    # Generate a unique ID for the API to look up metadata
                    # Using host:name:version as key
                    api_id = f"{config.host}:{proxy.get('name') or 'N/A'}:{proxy.get('version') or 'N/A'}"
                    metadata = metadata_store.get_metadata(api_id)
                    
                    api_proxy = ApiProxy(
                        host=config.host,
                        host_alias=host_alias,
                        name=proxy.get('name') or 'N/A',
                        path=proxy.get('path') or 'N/A',
                        version=proxy.get('version') or 'N/A',
                        state=proxy.get('state') or 'N/A',
                        inbound_security=metadata.get("inbound_security", inbound),
                        outbound_security=metadata.get("outbound_security", outbound),
                        technical_complexity=metadata.get("technical_complexity", "Low"),
                        business_complexity=metadata.get("business_complexity", "Low"),
                        notes=metadata.get("notes", ""),
                        ignore=metadata.get("ignore", False)
                    )

                    if not api_proxy.ignore:
                         # Check for passThrough filter
                        if api_proxy.inbound_security.lower() == "passthrough":
                            continue
                        all_proxies.append(api_proxy)
                        
        except Exception as e:
            print(f"Error fetching from {config.host}: {e}")
            
    return all_proxies

@app.post("/api/complexity")
def update_complexity(update: ComplexityUpdate):
    # Generate ID
    api_id = f"{update.host}:{update.name}:{update.version}"
    
    # Map frontend field names to backend metadata keys
    field_map = {
        "technical": "technical_complexity",
        "business": "business_complexity",
        "notes": "notes",
        "inbound_security": "inbound_security",
        "outbound_security": "outbound_security",
        "ignore": "ignore"
    }
    
    if update.field in field_map:
        metadata_store.update_metadata(api_id, {field_map[update.field]: update.value})
        return {"status": "success"}
    
    raise HTTPException(status_code=400, detail="Invalid field")

@app.post("/api/export")
def export_csv(configs: List[HostConfig]):
    proxies = get_proxies_list(configs)
    
    output = io.StringIO()
    writer = csv.writer(output)
    
    # Write header
    writer.writerow([
        "Host", "Name", "Path", "Version", "State", 
        "Inbound Security", "Outbound Security", 
        "Technical Complexity", "Business Complexity", "Notes"
    ])
    
    # Write data
    for proxy in proxies:
        writer.writerow([
            proxy.host_alias, # Use alias in export
            proxy.name,
            proxy.path,
            proxy.version,
            proxy.state,
            proxy.inbound_security,
            proxy.outbound_security,
            proxy.technical_complexity,
            proxy.business_complexity,
            proxy.notes
        ])
        
    return Response(
        content=output.getvalue(),
        media_type="text/csv",
        headers={"Content-Disposition": f"attachment; filename=api_export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"}
    )

@app.post("/api/import", response_model=List[ApiProxy])
async def import_csv(file: UploadFile = File(...)):
    content = await file.read()
    decoded_content = content.decode('utf-8')
    csv_reader = csv.DictReader(io.StringIO(decoded_content))
    
    # Get file alias if exists
    file_alias = metadata_store.get_file_alias(file.filename)
    
    imported_proxies = []
    
    for row in csv_reader:
        # Handle potential missing columns gracefully
        host = row.get('Host', '')
        
        # Priority: 
        # 1. Alias column in CSV (Specific Override)
        # 2. File Alias (Batch Override)
        # 3. Stored Host Alias (General Override)
        # 4. Host column (Default)
        
        csv_alias = row.get('Alias')
        stored_host_alias = metadata_store.get_host_alias(host)
        
        if csv_alias:
            host_alias = csv_alias
        elif file_alias:
            host_alias = file_alias
        elif stored_host_alias:
            host_alias = stored_host_alias
        else:
            host_alias = host
        
        imported_proxies.append(ApiProxy(
            host=host,
            host_alias=host_alias,
            name=row.get('Name', 'Unknown'),
            path=row.get('Path', ''),
            version=row.get('Version', ''),
            state=row.get('State', 'Unknown'),
            inbound_security=row.get('Inbound Security') or 'None',
            outbound_security=row.get('Outbound Security') or 'None',
            technical_complexity=row.get('Technical Complexity', 'Medium'),
            business_complexity=row.get('Business Complexity', 'Medium'),
            notes=row.get('Notes', '')
        ))
        
    return imported_proxies

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
