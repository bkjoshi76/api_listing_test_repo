---
theme: default
paginate: true
backgroundColor: #fff
---

# Axway API Dashboard
## Modernizing API Management Visibility

---

# Problem Statement

- **Visibility Gap**: Difficult to get a consolidated view of all APIs across multiple Axway gateways.
- **Security Auditing**: Manual effort required to check Inbound/Outbound security profiles for each API.
- **Complexity Tracking**: No built-in way to tag and track Technical vs. Business complexity for migration planning.
- **Data Portability**: Hard to export specific API subsets for reporting.

---

# Solution: Axway API Dashboard

A modern, web-based dashboard that provides:

1.  **Centralized Listing**: View APIs from multiple hosts in one place.
2.  **Deep Analytics**: Visualize security profiles and complexity distribution.
3.  **Interactive Filtering**: Granular column-level filtering for precise data slicing.
4.  **Enriched Metadata**: Tag APIs with complexity scores and custom notes.

---

# Key Features

- **Multi-Host Support**: Connect to Production, Staging, and Dev environments simultaneously.
- **Security Analytics**:
    - **Inbound**: Visualize auth types (API Key, OAuth, Passthrough).
    - **Outbound**: Track backend security protocols.
- **Smart Filtering**:
    - Global Search (Name, Path, Host).
    - Column-specific filters (e.g., "Show all High complexity APIs with OAuth").
- **CSV Export**: One-click export of filtered datasets for offline analysis.

---

# Technical Architecture

### Frontend
- **React + Vite**: Fast, responsive UI.
- **Tailwind CSS**: Modern, clean styling with Dark Mode support.
- **Recharts**: Interactive data visualization.

### Backend
- **FastAPI (Python)**: High-performance REST API.
- **Requests**: Robust communication with Axway API Manager.
- **Persistence**: JSON-based storage for metadata (Complexity/Notes).

---

# Workflow

1.  **Configure**: Add Axway Host credentials in the Configuration tab.
2.  **Fetch**: Dashboard pulls live data from all configured hosts.
3.  **Analyze**:
    - Review charts for macro-level insights.
    - Use filters to drill down to specific API groups.
4.  **Enrich**: Tag APIs with complexity levels and notes.
5.  **Export**: Generate CSV reports for stakeholders.

---

# Future Roadmap

- **Direct Migration**: One-click migration of selected APIs to Azure APIM.
- **Policy Analysis**: Deep dive into policy XML for compatibility checks.
- **User Management**: Role-based access control for the dashboard.
- **History**: Track changes in API state over time.

---

# Thank You

**Axway API Dashboard**
*Bringing clarity to your API Landscape*
