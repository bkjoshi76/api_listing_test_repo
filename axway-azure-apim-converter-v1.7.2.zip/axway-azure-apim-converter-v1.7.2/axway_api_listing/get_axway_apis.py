import argparse
import requests
import json
import csv
import sys
from requests.auth import HTTPBasicAuth
import urllib3

# Suppress InsecureRequestWarning if using self-signed certs
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

def get_proxies(host, port, username, password):
    """
    Retrieves the list of proxies from the Axway API Manager.
    """
    # Clean up host input
    host = host.strip()
    if host.startswith("https://"):
        host = host[8:]
    elif host.startswith("http://"):
        host = host[7:]
    
    if host.endswith("/"):
        host = host[:-1]

    base_url = f"https://{host}:{port}/api/portal/v1.3"
    proxies_url = f"{base_url}/proxies"
    
    print(f"Connecting to {proxies_url}...")
    
    try:
        response = requests.get(
            proxies_url, 
            auth=HTTPBasicAuth(username, password),
            verify=False # Assuming internal/self-signed certs for many enterprise setups
        )
        
        if response.status_code == 200:
            return response.json()
        else:
            print(f"Error: Failed to retrieve APIs. Status Code: {response.status_code}")
            print(f"Response: {response.text}")
            return None
            
    except requests.exceptions.RequestException as e:
        print(f"Error connecting to Axway API Manager: {e}")
        return None

def parse_security(proxy):
    """
    Parses the security profiles from a proxy object.
    """
    inbound_security = "None"
    outbound_security = "None"
    
    # Parse Inbound Security
    # Inbound security is typically in 'securityProfiles'
    if 'securityProfiles' in proxy and proxy['securityProfiles']:
        profiles = []
        for profile in proxy['securityProfiles']:
            # Each profile might have devices
            current_profile_devices = []
            is_custom_policy = False
            
            if 'devices' in profile:
                for device in profile['devices']:
                    if 'type' in device:
                        device_type = device['type']
                        if device_type == 'authPolicy':
                            is_custom_policy = True
                        else:
                            current_profile_devices.append(device_type)
            
            if is_custom_policy:
                # If it's a custom policy, use the profile name and IGNORE other devices (like passThrough)
                if 'name' in profile:
                    profiles.append(profile['name'])
            elif current_profile_devices:
                # If standard devices found and NOT custom policy, use them
                profiles.extend(current_profile_devices)
            elif 'name' in profile:
                # Fallback: No devices found at all, use profile name
                profiles.append(profile['name'])
        
        if profiles:
            # Deduplicate profiles
            unique_profiles = list(set(profiles))
            
            # If we have multiple profiles and one of them is passThrough, remove passThrough
            # This handles cases where a custom policy is used alongside passThrough
            if len(unique_profiles) > 1 and "passThrough" in unique_profiles:
                unique_profiles.remove("passThrough")
                
            inbound_security = ", ".join(unique_profiles)

    # Parse Outbound Security
    # Outbound is often in 'authenticationProfiles' or 'outboundProfiles' depending on version/setup
    if 'authenticationProfiles' in proxy and proxy['authenticationProfiles']:
        profiles = []
        for profile in proxy['authenticationProfiles']:
             if 'type' in profile:
                 profiles.append(profile['type'])
             elif 'name' in profile:
                 profiles.append(profile['name'])
        
        if profiles:
            outbound_security = ", ".join(list(set(profiles)))
            
    return inbound_security, outbound_security

def main():
    parser = argparse.ArgumentParser(description="List APIs and Security from Axway API Gateway")
    parser.add_argument("--host", help="Axway API Manager Hostname or IP")
    parser.add_argument("--port", default="8075", help="Axway API Manager Port (default: 8075)")
    parser.add_argument("--username", help="Admin Username")
    parser.add_argument("--password", help="Admin Password")
    parser.add_argument("--config", help="Path to JSON config file for multiple hosts")
    parser.add_argument("--output", default="axway_apis.csv", help="Output CSV file name")

    args = parser.parse_args()

    hosts_config = []

    if args.config:
        try:
            with open(args.config, 'r') as f:
                hosts_config = json.load(f)
        except Exception as e:
            print(f"Error reading config file: {e}")
            sys.exit(1)
    elif args.host and args.username and args.password:
        hosts_config.append({
            "host": args.host,
            "port": args.port,
            "username": args.username,
            "password": args.password
        })
    else:
        print("Error: You must provide either --config or (--host, --username, --password)")
        parser.print_help()
        sys.exit(1)

    all_proxies = []

    for config in hosts_config:
        host = config.get("host")
        port = config.get("port", "8075")
        username = config.get("username")
        password = config.get("password")
        
        if not host or not username or not password:
            print(f"Skipping incomplete config: {config}")
            continue

        print(f"Processing host: {host}")
        proxies = get_proxies(host, port, username, password)
        
        if proxies:
            for proxy in proxies:
                proxy['source_host'] = host # Tag the proxy with its source host
            all_proxies.extend(proxies)

    if all_proxies:
        print(f"Successfully retrieved {len(all_proxies)} APIs from {len(hosts_config)} hosts. Writing to {args.output}...")
        
        with open(args.output, 'w', newline='', encoding='utf-8') as csvfile:
            fieldnames = ['Host', 'Name', 'Path', 'Version', 'State', 'Inbound Security', 'Outbound Security']
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)

            writer.writeheader()
            
            for proxy in all_proxies:
                inbound, outbound = parse_security(proxy)
                
                writer.writerow({
                    'Host': proxy.get('source_host', 'N/A'),
                    'Name': proxy.get('name', 'N/A'),
                    'Path': proxy.get('path', 'N/A'),
                    'Version': proxy.get('version', 'N/A'),
                    'State': proxy.get('state', 'N/A'),
                    'Inbound Security': inbound,
                    'Outbound Security': outbound
                })
                
        print("Done.")
    else:
        print("No APIs found or failed to retrieve data from any host.")

if __name__ == "__main__":
    main()
