import unittest
from unittest.mock import patch, MagicMock
import get_axway_apis

class TestAxwayAPIListing(unittest.TestCase):

    def test_parse_security(self):
        # Sample Proxy Object with Inbound and Outbound security
        sample_proxy = {
            "name": "Test API",
            "path": "/test",
            "securityProfiles": [
                {
                    "name": "Inbound Profile 1",
                    "devices": [
                        {"type": "apiKey"},
                        {"type": "oauth"}
                    ]
                }
            ],
            "authenticationProfiles": [
                {
                    "name": "Outbound Profile 1",
                    "type": "http_basic"
                }
            ]
        }

        inbound, outbound = get_axway_apis.parse_security(sample_proxy)
        
        # Check if parsed correctly
        self.assertIn("apiKey", inbound)
        self.assertIn("oauth", inbound)
        self.assertIn("http_basic", outbound)
        
    def test_parse_security_empty(self):
        sample_proxy = {
            "name": "Public API",
            "path": "/public"
        }
        
        inbound, outbound = get_axway_apis.parse_security(sample_proxy)
        
        self.assertEqual(inbound, "None")
        self.assertEqual(outbound, "None")

    @patch('get_axway_apis.get_proxies')
    @patch('builtins.open', new_callable=MagicMock)
    @patch('json.load')
    @patch('sys.argv', ['get_axway_apis.py', '--config', 'hosts.json'])
    def test_main_multi_host(self, mock_json_load, mock_open, mock_get_proxies):
        # Mock config file content
        mock_json_load.return_value = [
            {"host": "host1", "username": "u1", "password": "p1"},
            {"host": "host2", "username": "u2", "password": "p2"}
        ]
        
        # Mock get_proxies return value
        mock_get_proxies.side_effect = [
            [{"name": "API1", "path": "/api1"}], # host1
            [{"name": "API2", "path": "/api2"}]  # host2
        ]
        
        # Capture stdout to verify output
        with patch('sys.stdout', new_callable=MagicMock) as mock_stdout:
            get_axway_apis.main()
            
            # Verify get_proxies was called for both hosts
            self.assertEqual(mock_get_proxies.call_count, 2)
            mock_get_proxies.assert_any_call("host1", "8075", "u1", "p1")
            mock_get_proxies.assert_any_call("host2", "8075", "u2", "p2")

if __name__ == '__main__':
    unittest.main()
