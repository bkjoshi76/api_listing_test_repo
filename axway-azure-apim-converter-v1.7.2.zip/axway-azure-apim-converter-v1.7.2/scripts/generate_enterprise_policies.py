#!/usr/bin/env python3
"""
Enterprise YAML Policy Generator

Generates comprehensive test policies for all filter types to validate
the Strategic Axway to Azure APIM Converter.

Author: Enterprise API Team
Version: 1.0.0
"""

import yaml
import os
from datetime import datetime

def ensure_directory(path):
    """Create directory if it doesn't exist."""
    os.makedirs(path, exist_ok=True)
    return path

def generate_authentication_policy():
    """Generate enterprise authentication policy."""
    return {
        'name': 'Enterprise Authentication Policy',
        'description': 'Multi-layer authentication with JWT and OAuth',
        'created': datetime.now().isoformat(),
        'filters': [
            {
                'name': 'HTTPBasicAuth',
                'type': 'HTTPBasicFilter',
                'username': '{{basic-username}}',
                'password': '{{basic-password}}',
                'realm': 'Enterprise API'
            },
            {
                'name': 'JWTValidation',
                'type': 'JWTFilter',
                'signingKey': '{{jwt-signing-key}}',
                'issuer': 'https://auth.enterprise.com',
                'audience': 'api://enterprise',
                'claims': {
                    'scope': ['read', 'write'],
                    'sub': 'required'
                }
            },
            {
                'name': 'OAuth2Validation',
                'type': 'OAuth2Filter',
                'tokenEndpoint': 'https://oauth.enterprise.com/token',
                'clientId': '{{oauth-client-id}}',
                'clientSecret': '{{oauth-client-secret}}',
                'scope': 'api.read api.write'
            }
        ],
        'security': {
            'primaryAuth': 'JWTValidation',
            'fallbackAuth': 'HTTPBasicAuth',
            'oauthIntegration': 'OAuth2Validation'
        }
    }

def generate_security_policy():
    """Generate enterprise security policy."""
    return {
        'name': 'Enterprise Security Policy',
        'description': 'Comprehensive threat protection and security',
        'created': datetime.now().isoformat(),
        'filters': [
            {
                'name': 'XMLThreatProtection',
                'type': 'XMLThreatProtectionFilter',
                'maxDepth': 15,
                'maxNodeCount': 2000,
                'maxAttributeCount': 150,
                'maxNamespaceCount': 10,
                'detectExternalEntities': True,
                'enableDTDProcessing': False
            },
            {
                'name': 'JSONThreatProtection', 
                'type': 'JSONThreatProtectionFilter',
                'maxDepth': 10,
                'maxArrayElements': 1500,
                'maxObjectProperties': 250,
                'maxStringLength': 5000
            },
            {
                'name': 'IPWhitelist',
                'type': 'IPWhitelistFilter',
                'allowedIPs': [
                    '192.168.0.0/16',
                    '10.0.0.0/8', 
                    '172.16.0.0/12',
                    '203.0.113.0/24'
                ],
                'action': 'allow'
            },
            {
                'name': 'SQLInjectionProtection',
                'type': 'SQLInjectionFilter',
                'enabled': True,
                'strictMode': True,
                'patterns': ['union', 'select', 'insert', 'update', 'delete']
            }
        ],
        'security': {
            'threatProtection': ['XMLThreatProtection', 'JSONThreatProtection'],
            'accessControl': 'IPWhitelist',
            'injectionProtection': 'SQLInjectionProtection'
        }
    }

def generate_performance_policy():
    """Generate enterprise performance policy."""
    return {
        'name': 'Enterprise Performance Policy',
        'description': 'Rate limiting, caching, and optimization',
        'created': datetime.now().isoformat(),
        'filters': [
            {
                'name': 'MainRateLimit',
                'type': 'ThrottlingFilter',
                'maxRequests': 1000,
                'timeWindow': 60,
                'keyExpression': '@(context.Request.IpAddress)',
                'action': 'reject'
            },
            {
                'name': 'ConcurrencyLimit',
                'type': 'ConcurrencyFilter',
                'maxConcurrentRequests': 100,
                'queueLength': 200,
                'timeout': 30000
            },
            {
                'name': 'APIQuota',
                'type': 'QuotaFilter',
                'quotaLimit': 50000,
                'quotaPeriod': 86400,
                'quotaCounter': '@(context.Request.Headers.GetValueOrDefault("ApiKey","anonymous"))',
                'resetTime': '00:00:00'
            },
            {
                'name': 'ResponseCache',
                'type': 'ResponseCacheFilter',
                'cacheDuration': 600,
                'cacheKey': '@(context.Request.Url.Path)',
                'varyByHeaders': ['Authorization', 'Accept-Language'],
                'cacheControl': 'public'
            }
        ],
        'performance': {
            'rateLimit': 'MainRateLimit',
            'concurrency': 'ConcurrencyLimit', 
            'quota': 'APIQuota',
            'caching': 'ResponseCache'
        }
    }

def generate_transformation_policy():
    """Generate enterprise transformation policy."""
    return {
        'name': 'Enterprise Transformation Policy',
        'description': 'Content transformation and format conversion',
        'created': datetime.now().isoformat(),
        'filters': [
            {
                'name': 'JSONToXMLTransform',
                'type': 'JSONTransformFilter',
                'rootElement': 'EnterpriseRequest',
                'namespaceUri': 'http://enterprise.com/api/v2',
                'arrayHandling': 'preserve',
                'attributePrefix': '@'
            },
            {
                'name': 'XSLTransformation',
                'type': 'XSLTransformFilter',
                'xslContent': '''<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
    <xsl:template match="/">
        <EnterpriseRequest>
            <Header>
                <Timestamp><xsl:value-of select="current-dateTime()"/></Timestamp>
                <Source>API Gateway</Source>
            </Header>
            <Body>
                <xsl:copy-of select="*"/>
            </Body>
        </EnterpriseRequest>
    </xsl:template>
</xsl:stylesheet>''',
                'parameters': {
                    'source': 'APIM_GATEWAY',
                    'version': '2.0'
                }
            },
            {
                'name': 'XMLToJSONTransform',
                'type': 'XMLToJSONFilter',
                'namespaceHandling': 'strip',
                'arrayDetection': True,
                'rootElement': 'Response'
            },
            {
                'name': 'ContentModify',
                'type': 'ContentModifyFilter',
                'content': '''{
    "apiVersion": "v2",
    "timestamp": "@(DateTime.Now)",
    "originalContent": @(context.Request.Body.As<string>()),
    "metadata": {
        "source": "enterprise-gateway",
        "transformed": true,
        "processingTime": "@(DateTime.Now.Subtract(context.Variables["requestTime"]))"
    }
}''',
                'contentType': 'application/json'
            }
        ],
        'transformation': {
            'requestPath': ['JSONToXMLTransform', 'XSLTransformation'],
            'responsePath': ['XMLToJSONTransform', 'ContentModify']
        }
    }

def generate_backend_policy():
    """Generate enterprise backend policy.""" 
    return {
        'name': 'Enterprise Backend Policy',
        'description': 'Backend routing, load balancing, and failover',
        'created': datetime.now().isoformat(),
        'filters': [
            {
                'name': 'LoadBalancer',
                'type': 'LoadBalancingFilter',
                'algorithm': 'weighted_round_robin',
                'healthCheck': '/health',
                'healthCheckInterval': 30,
                'servers': [
                    {'url': 'https://api1.enterprise.com', 'weight': 50, 'priority': 1},
                    {'url': 'https://api2.enterprise.com', 'weight': 30, 'priority': 2},
                    {'url': 'https://api3.enterprise.com', 'weight': 20, 'priority': 3}
                ]
            },
            {
                'name': 'FailoverHandler',
                'type': 'FailoverFilter',
                'retryCount': 3,
                'retryInterval': 2000,
                'backoffMultiplier': 1.5,
                'maxInterval': 10000,
                'retryOn': ['5xx', 'timeout', 'connection_error']
            },
            {
                'name': 'BackendConnection',
                'type': 'ConnectToURLFilter',
                'url': 'https://primary.enterprise.com',
                'timeout': 30,
                'connectionTimeout': 10,
                'keepAlive': True
            }
        ],
        'backend': {
            'loadBalancing': 'LoadBalancer',
            'failover': 'FailoverHandler',
            'primaryConnection': 'BackendConnection'
        }
    }

def generate_monitoring_policy():
    """Generate enterprise monitoring policy."""
    return {
        'name': 'Enterprise Monitoring Policy',
        'description': 'Comprehensive monitoring and analytics',
        'created': datetime.now().isoformat(),
        'filters': [
            {
                'name': 'RequestMonitoring',
                'type': 'MonitoringFilter',
                'logLevel': 'INFO',
                'includeHeaders': True,
                'includeBody': False,
                'includeSensitiveData': False,
                'destination': 'eventhub',
                'eventHubName': 'api-monitoring'
            },
            {
                'name': 'BusinessMetrics',
                'type': 'MetricsFilter',
                'metricName': 'api_requests_total',
                'metricValue': '1',
                'metricDimensions': {
                    'service': 'enterprise-api',
                    'version': 'v2',
                    'environment': 'production',
                    'region': 'east-us'
                }
            },
            {
                'name': 'ResponseCompression',
                'type': 'CompressionFilter',
                'compressionLevel': 6,
                'compressionTypes': ['application/json', 'application/xml', 'text/xml'],
                'minimumSize': 1024
            },
            {
                'name': 'AuditLog',
                'type': 'MonitoringFilter',
                'logLevel': 'AUDIT',
                'auditEvents': ['authentication', 'authorization', 'dataAccess'],
                'destination': 'loganalytics'
            }
        ],
        'monitoring': {
            'requestTracking': 'RequestMonitoring',
            'businessMetrics': 'BusinessMetrics',
            'optimization': 'ResponseCompression',
            'auditTrail': 'AuditLog'
        }
    }

def main():
    """Main function to generate all policies."""
    print("🏗️ Generating Enterprise YAML Policies...")
    print()
    
    # Ensure output directory exists
    output_dir = ensure_directory('policies/generated')
    
    # Generate all policies
    policies = {
        'authentication-policy.yaml': generate_authentication_policy(),
        'security-policy.yaml': generate_security_policy(),
        'performance-policy.yaml': generate_performance_policy(),
        'transformation-policy.yaml': generate_transformation_policy(),
        'backend-policy.yaml': generate_backend_policy(),
        'monitoring-policy.yaml': generate_monitoring_policy()
    }
    
    # Write policies to files
    for filename, policy_data in policies.items():
        filepath = os.path.join(output_dir, filename)
        with open(filepath, 'w', encoding='utf-8') as f:
            yaml.dump(policy_data, f, default_flow_style=False, sort_keys=False, indent=2)
        print(f"✅ Generated {filename}")
    
    print()
    print("================================================================================")
    print("  🎉 ENTERPRISE YAML POLICIES GENERATED SUCCESSFULLY")
    print("================================================================================")
    print()
    print("📁 Generated Files in policies/generated/:")
    print("   📄 authentication-policy.yaml    - Multi-layer authentication")
    print("   📄 security-policy.yaml         - Threat protection and security")
    print("   📄 performance-policy.yaml      - Rate limiting and caching")
    print("   📄 transformation-policy.yaml   - Content transformation")
    print("   📄 backend-policy.yaml          - Backend routing and failover") 
    print("   📄 monitoring-policy.yaml       - Monitoring and analytics")
    print()
    print("🚀 Ready to run strategic-test-enterprise.bat for full testing!")
    print()
    print("These policies provide comprehensive coverage of:")
    print("  - 6 different policy categories")
    print("  - 20+ filter types")
    print("  - Demo configurations")
    print("  - Real-world complexity scenarios")
    print()

if __name__ == "__main__":
    main()
