// Axway to Azure APIM Converter
// JavaScript port of the Python converter

import jsyaml from 'js-yaml';
import { FILTER_MAPPINGS, PolicySection, getFilterMapping } from './filter-mappings.js';

export class AxwayToApimConverter {
    constructor() {
        this.version = '1.1.0';
    }

    /**
     * Convert Axway FilterCircuit YAML to Azure APIM XML
     * @param {string} yamlContent - YAML content string
     * @returns {object} Conversion result with XML and statistics
     */
    convertYamlToXml(yamlContent) {
        try {
            // Parse YAML
            const config = jsyaml.load(yamlContent);

            if (!config || !config.filters) {
                return {
                    success: false,
                    error: 'Invalid YAML: missing filters section'
                };
            }

            // Convert to XML
            const xmlResult = this.convertFilterCircuitToXml(config);

            return {
                success: true,
                xml: xmlResult.xml,
                statistics: xmlResult.statistics,
                policyName: config.name || 'Unnamed Policy',
                description: config.description || ''
            };
        } catch (error) {
            return {
                success: false,
                error: `Conversion failed: ${error.message}`
            };
        }
    }

    /**
     * Convert FilterCircuit configuration to Azure APIM XML
     * @param {object} config - Parsed FilterCircuit configuration
     * @returns {object} XML string and statistics
     */
    convertFilterCircuitToXml(config) {
        const policyName = config.name || 'Converted Policy';
        const filters = config.filters || [];

        // Organize filters by section
        const sections = {
            [PolicySection.INBOUND]: [],
            [PolicySection.BACKEND]: [],
            [PolicySection.OUTBOUND]: [],
            [PolicySection.ON_ERROR]: []
        };

        let convertedCount = 0;
        let totalCount = filters.length;
        const unsupportedFilters = [];

        // Categorize filters by section
        filters.forEach(filter => {
            const mapping = getFilterMapping(filter.type);

            if (mapping) {
                const policyXml = this.createPolicyElement(filter, mapping);
                sections[mapping.section].push(policyXml);
                convertedCount++;
            } else {
                unsupportedFilters.push(filter.type);
                // Add as comment
                sections[PolicySection.INBOUND].push(
                    `    <!-- UNSUPPORTED: ${filter.name} (${filter.type}) -->`
                );
            }
        });

        // Build XML
        const xml = this.buildXmlDocument(policyName, sections, convertedCount, totalCount);

        return {
            xml,
            statistics: {
                totalFilters: totalCount,
                convertedFilters: convertedCount,
                successRate: totalCount > 0 ? (convertedCount / totalCount * 100).toFixed(1) : 0,
                unsupportedFilters
            }
        };
    }

    /**
     * Create a policy XML element for a filter
     * @param {object} filter - Filter configuration
     * @param {object} mapping - Filter mapping definition
     * @returns {string} XML element string
     */
    createPolicyElement(filter, mapping) {
        const filterType = filter.type;
        const filterName = filter.name;
        const policyType = mapping.apimPolicy;

        let policyXml = `    <!-- ${filterName} (${filterType}) -->\n`;

        // Generate policy based on type
        switch (policyType) {
            case 'authentication-basic':
                policyXml += this.createBasicAuthPolicy(filter);
                break;

            case 'validate-jwt':
                policyXml += this.createJwtPolicy(filter);
                break;

            case 'rate-limit':
                policyXml += this.createRateLimitPolicy(filter);
                break;

            case 'quota':
                policyXml += this.createQuotaPolicy(filter);
                break;

            case 'set-backend-service':
                if (filterType === 'ConnectToURLFilter') {
                    policyXml += this.createBackendPolicy(filter);
                } else {
                    policyXml += this.createGenericPolicy(policyType, filter, mapping);
                }
                break;

            case 'xml-threat-detection':
                policyXml += this.createXmlThreatPolicy(filter);
                break;

            case 'json-threat-detection':
                policyXml += this.createJsonThreatPolicy(filter);
                break;

            case 'ip-filter':
                policyXml += this.createIpFilterPolicy(filter, mapping);
                break;

            case 'emit-metric':
                policyXml += this.createMetricPolicy(filter);
                break;

            case 'log-to-eventhub':
                policyXml += this.createMonitoringPolicy(filter);
                break;

            case 'cache-lookup-value':
                policyXml += this.createCachePolicy(filter);
                break;

            case 'xsl-transform':
            case 'json-to-xml':
            case 'xml-to-json':
            case 'set-body':
            case 'compression':
            case 'retry':
            case 'concurrency-limit':
                policyXml += this.createGenericPolicy(policyType, filter, mapping);
                break;

            default:
                policyXml += `    <!-- TODO: Implement ${policyType} conversion -->`;
        }

        return policyXml;
    }

    // Policy creation methods
    createBasicAuthPolicy(filter) {
        const username = filter.username || 'user';
        const password = filter.password || '{{password}}';
        return `    <authentication-basic username="${this.escapeXml(username)}" password="${this.escapeXml(password)}"/>`;
    }

    createJwtPolicy(filter) {
        let xml = '    <validate-jwt header-name="Authorization" failed-validation-httpcode="401" failed-validation-error-message="Unauthorized">\n';

        if (filter.issuer) {
            xml += `      <issuers>\n        <issuer>${this.escapeXml(filter.issuer)}</issuer>\n      </issuers>\n`;
        }

        if (filter.audience || filter.clientId) {
            const aud = filter.audience || filter.clientId;
            xml += `      <audiences>\n        <audience>${this.escapeXml(aud)}</audience>\n      </audiences>\n`;
        }

        if (filter.signingKey || filter.tokenEndpoint) {
            xml += '      <issuer-signing-keys>\n';
            xml += '        <key>{{jwt-signing-key}}</key>\n';
            xml += '      </issuer-signing-keys>\n';
        }

        xml += '    </validate-jwt>';
        return xml;
    }

    createRateLimitPolicy(filter) {
        const calls = filter.maxRequests || 100;
        const period = filter.timeWindow || 60;
        const counterKey = filter.keyExpression || '@(context.Request.IpAddress)';
        return `    <rate-limit calls="${calls}" renewal-period="${period}" counter-key="${this.escapeXml(counterKey)}"/>`;
    }

    createQuotaPolicy(filter) {
        const calls = filter.quotaLimit || 10000;
        const period = filter.quotaPeriod || 86400;
        return `    <quota calls="${calls}" renewal-period="${period}"/>`;
    }

    createBackendPolicy(filter) {
        const url = filter.url || 'https://backend.example.com';
        const timeout = filter.timeout || 30;
        return `    <set-backend-service base-url="${this.escapeXml(url)}" timeout="${timeout}"/>`;
    }

    createXmlThreatPolicy(filter) {
        let xml = '    <xml-threat-detection';
        if (filter.maxDepth) xml += ` maximum-depth="${filter.maxDepth}"`;
        if (filter.maxNodeCount) xml += ` maximum-node-count="${filter.maxNodeCount}"`;
        if (filter.maxAttributeCount) xml += ` maximum-attribute-count="${filter.maxAttributeCount}"`;
        if (filter.maxNamespaceCount) xml += ` maximum-namespace-count="${filter.maxNamespaceCount}"`;
        if (filter.detectExternalEntities !== undefined) {
            xml += ` enable-external-entity-detection="${filter.detectExternalEntities}"`;
        }
        xml += '/>';
        return xml;
    }

    createJsonThreatPolicy(filter) {
        // Match Python converter's generic attribute handling for this filter
        let xml = '    <json-threat-detection';
        if (filter.maxDepth) xml += ` maxDepth="${filter.maxDepth}"`;
        if (filter.maxArrayElements) xml += ` maxArrayElements="${filter.maxArrayElements}"`;
        if (filter.maxObjectProperties) xml += ` maxObjectProperties="${filter.maxObjectProperties}"`;
        if (filter.maxStringLength) xml += ` maxStringLength="${filter.maxStringLength}"`;
        xml += '/>';
        return xml;
    }

    createIpFilterPolicy(filter, mapping) {
        const action = mapping.configMapping.action || 'allow';
        const ips = filter.allowedIPs || filter.blockedIPs || ['0.0.0.0'];
        let xml = `    <ip-filter action="${action}">\n`;
        ips.forEach(ip => {
            xml += `      <address-range from="${this.escapeXml(ip)}" to="${this.escapeXml(ip)}"/>\n`;
        });
        xml += '    </ip-filter>';
        return xml;
    }

    createMetricPolicy(filter) {
        const name = filter.metricName || 'custom_metric';
        const value = filter.metricValue || '1';
        let xml = `    <emit-metric name="${this.escapeXml(name)}">\n`;
        xml += `      <value>${this.escapeXml(value)}</value>\n`;
        xml += '    </emit-metric>';
        return xml;
    }

    createMonitoringPolicy(filter) {
        const loggerId = (filter.logLevel || 'api-logger').toLowerCase();
        return `    <log-to-eventhub logger-id="${this.escapeXml(loggerId)}">\n` +
            '      <message>@{ \n' +
            '        var requestLine = string.Format("{0} {1} HTTP/{2}\\r\\n", \n' +
            '            context.Request.Method, \n' +
            '            context.Request.Url.Path + context.Request.Url.QueryString, \n' +
            '            context.Request.HttpVersion \n' +
            '        ); \n' +
            '        return requestLine; \n' +
            '      }</message>\n' +
            '    </log-to-eventhub>';
    }

    createCachePolicy(filter) {
        // Match Python's generic handling which adds attributes as-is
        const duration = filter.cacheDuration || 300;
        const key = filter.cacheKey || '@(context.Request.Url.ToString())';
        // Note: Python converter would generate cacheDuration attribute, keeping consistent with that
        return `    <cache-lookup-value cacheDuration="${duration}" cacheKey="${this.escapeXml(key)}"/>`;
    }

    createGenericPolicy(policyType, filter, mapping) {
        // Match Python's generic handler: add all primitive properties as attributes
        let xml = `    <${policyType}`;

        // Add basic configuration as attributes
        Object.keys(filter).forEach(key => {
            if (key !== 'name' && key !== 'type') {
                const value = filter[key];
                // Only add primitive values (str, int, float, bool)
                if (typeof value === 'string' || typeof value === 'number' || typeof value === 'boolean') {
                    // Convert underscores to hyphens if any (though Python does key.replace('_', '-'))
                    const attrName = key.replace(/_/g, '-');
                    xml += ` ${attrName}="${this.escapeXml(String(value))}"`;
                }
            }
        });

        xml += '/>';
        return xml;
    }

    /**
     * Build complete XML document
     */
    buildXmlDocument(policyName, sections, convertedCount, totalCount) {
        const successRate = totalCount > 0 ? (convertedCount / totalCount * 100).toFixed(0) : 0;

        let xml = '<policies>\n';
        xml += `  <!-- Generated by Strategic Converter v${this.version} from FilterCircuit: ${this.escapeXml(policyName)} -->\n`;

        // Inbound section
        xml += '  <inbound>\n';
        xml += '    <base/>\n';
        if (sections[PolicySection.INBOUND].length > 0) {
            xml += sections[PolicySection.INBOUND].join('\n') + '\n';
        }
        xml += '  </inbound>\n';

        // Backend section
        xml += '  <backend>\n';
        xml += '    <base/>\n';
        if (sections[PolicySection.BACKEND].length > 0) {
            xml += sections[PolicySection.BACKEND].join('\n') + '\n';
        }
        xml += '  </backend>\n';

        // Outbound section
        xml += '  <outbound>\n';
        xml += '    <base/>\n';
        if (sections[PolicySection.OUTBOUND].length > 0) {
            xml += sections[PolicySection.OUTBOUND].join('\n') + '\n';
        }
        xml += '  </outbound>\n';

        // On-error section
        xml += '  <on-error>\n';
        xml += '    <base/>\n';
        if (sections[PolicySection.ON_ERROR].length > 0) {
            xml += sections[PolicySection.ON_ERROR].join('\n') + '\n';
        }
        xml += '  </on-error>\n';

        xml += `  <!-- Conversion Statistics: ${convertedCount}/${totalCount} filters converted (${successRate}% success rate) -->\n`;
        xml += '</policies>';

        return xml;
    }

    /**
     * Escape XML special characters
     */
    escapeXml(str) {
        if (typeof str !== 'string') return str;
        return str
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&apos;');
    }
}
