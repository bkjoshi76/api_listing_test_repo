// Main Application Logic
import { AxwayToApimConverter } from './converter.js';
import { getAllExamples, getExamplePolicy } from './examples.js';

// Initialize converter
const converter = new AxwayToApimConverter();

// DOM Elements
const exampleSelect = document.getElementById('example-select');
const yamlInput = document.getElementById('yaml-input');
const xmlOutput = document.getElementById('xml-output');
const convertBtn = document.getElementById('convert-btn');
const clearBtn = document.getElementById('clear-btn');
const copyBtn = document.getElementById('copy-btn');
const statsContainer = document.getElementById('stats');
const statusMessage = document.getElementById('status-message');

// Statistics elements
const statName = document.getElementById('stat-name');
const statTotal = document.getElementById('stat-total');
const statConverted = document.getElementById('stat-converted');
const statRate = document.getElementById('stat-rate');

/**
 * Initialize the application
 */
function init() {
    loadExamples();
    attachEventListeners();

    // Load first example by default
    const examples = getAllExamples();
    if (examples.length > 0) {
        loadExample(examples[0].key);
    }
}

/**
 * Load example policies into dropdown
 */
function loadExamples() {
    const examples = getAllExamples();

    examples.forEach(example => {
        const option = document.createElement('option');
        option.value = example.key;
        option.textContent = example.name;
        exampleSelect.appendChild(option);
    });
}

/**
 * Attach event listeners
 */
function attachEventListeners() {
    exampleSelect.addEventListener('change', (e) => {
        if (e.target.value) {
            loadExample(e.target.value);
        }
    });

    convertBtn.addEventListener('click', handleConvert);
    clearBtn.addEventListener('click', handleClear);
    copyBtn.addEventListener('click', handleCopy);

    // Auto-convert on input change (debounced)
    let debounceTimer;
    yamlInput.addEventListener('input', () => {
        clearTimeout(debounceTimer);
        debounceTimer = setTimeout(() => {
            if (yamlInput.value.trim()) {
                handleConvert();
            }
        }, 1000);
    });
}

/**
 * Load an example policy
 */
function loadExample(exampleKey) {
    const example = getExamplePolicy(exampleKey);

    if (example) {
        yamlInput.value = example.yaml;
        exampleSelect.value = exampleKey;

        // Auto-convert
        setTimeout(() => handleConvert(), 100);
    }
}

/**
 * Handle conversion
 */
function handleConvert() {
    const yamlContent = yamlInput.value.trim();

    if (!yamlContent) {
        showStatus('Please enter YAML content or select an example', 'error');
        return;
    }

    // Show loading state
    convertBtn.classList.add('loading');
    convertBtn.disabled = true;

    // Simulate async conversion (for smooth UX)
    setTimeout(() => {
        try {
            const result = converter.convertYamlToXml(yamlContent);

            if (result.success) {
                displayResult(result);
                showStatus('✓ Conversion successful!', 'success');
                copyBtn.disabled = false;
            } else {
                displayError(result.error);
                showStatus(`✗ ${result.error}`, 'error');
                copyBtn.disabled = true;
            }
        } catch (error) {
            displayError(error.message);
            showStatus(`✗ Unexpected error: ${error.message}`, 'error');
            copyBtn.disabled = true;
        } finally {
            convertBtn.classList.remove('loading');
            convertBtn.disabled = false;
        }
    }, 300);
}

/**
 * Display conversion result
 */
function displayResult(result) {
    // Display XML with basic syntax highlighting
    const formattedXml = highlightXml(result.xml);
    xmlOutput.innerHTML = `<code>${formattedXml}</code>`;

    // Update statistics
    statsContainer.style.display = 'grid';
    statName.textContent = result.policyName;
    statTotal.textContent = result.statistics.totalFilters;
    statConverted.textContent = result.statistics.convertedFilters;
    statRate.textContent = `${result.statistics.successRate}%`;

    // Color code success rate
    const rate = parseFloat(result.statistics.successRate);
    if (rate === 100) {
        statRate.style.background = 'linear-gradient(135deg, #10b981 0%, #059669 100%)';
    } else if (rate >= 75) {
        statRate.style.background = 'linear-gradient(135deg, #f59e0b 0%, #d97706 100%)';
    } else {
        statRate.style.background = 'linear-gradient(135deg, #ef4444 0%, #dc2626 100%)';
    }
    statRate.style.webkitBackgroundClip = 'text';
    statRate.style.webkitTextFillColor = 'transparent';
    statRate.style.backgroundClip = 'text';
}

/**
 * Display error
 */
function displayError(errorMessage) {
    xmlOutput.innerHTML = `<code style="color: #ef4444;">Error: ${escapeHtml(errorMessage)}</code>`;
    statsContainer.style.display = 'none';
}

/**
 * Basic XML syntax highlighting
 */
function highlightXml(xml) {
    return escapeHtml(xml).replace(/(&lt;\!--.*?--&gt;)|(&lt;\/?[\w:-]+)|([\w:-]+)=|("[^"]*")|(&gt;)/g,
        (match, comment, tag, attr, value, endTag) => {
            if (comment) return `<span class="xml-comment">${comment}</span>`;
            if (tag) return `<span class="xml-tag">${tag}</span>`;
            if (attr) return `<span class="xml-attr">${attr}</span>=`;
            if (value) return `"<span class="xml-value">${value.substring(1, value.length - 1)}</span>"`;
            if (endTag) return `<span class="xml-tag">${endTag}</span>`;
            return match;
        }
    );
}

/**
 * Escape HTML
 */
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

/**
 * Handle clear
 */
function handleClear() {
    yamlInput.value = '';
    xmlOutput.innerHTML = '<code>Converted XML will appear here...</code>';
    statsContainer.style.display = 'none';
    exampleSelect.value = '';
    copyBtn.disabled = true;
    hideStatus();
}

/**
 * Handle copy to clipboard
 */
async function handleCopy() {
    const xmlText = xmlOutput.textContent;

    try {
        await navigator.clipboard.writeText(xmlText);

        // Visual feedback
        const originalText = copyBtn.innerHTML;
        copyBtn.innerHTML = `
      <svg class="btn-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <polyline points="20 6 9 17 4 12"/>
      </svg>
      Copied!
    `;

        setTimeout(() => {
            copyBtn.innerHTML = originalText;
        }, 2000);

        showStatus('✓ XML copied to clipboard!', 'success');
    } catch (error) {
        showStatus('✗ Failed to copy to clipboard', 'error');
    }
}

/**
 * Show status message
 */
function showStatus(message, type = 'success') {
    statusMessage.textContent = message;
    statusMessage.className = `status-message ${type}`;
    statusMessage.style.display = 'block';

    // Auto-hide after 5 seconds
    setTimeout(() => {
        hideStatus();
    }, 5000);
}

/**
 * Hide status message
 */
function hideStatus() {
    statusMessage.style.display = 'none';
}

// Initialize app when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
} else {
    init();
}
