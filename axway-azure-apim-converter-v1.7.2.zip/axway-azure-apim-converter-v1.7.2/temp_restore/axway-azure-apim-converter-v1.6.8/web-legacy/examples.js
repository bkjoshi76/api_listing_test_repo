// Example Policies for Testing
// Embedded example Axway FilterCircuit policies

export const EXAMPLE_POLICIES = {
  'health-check': {
    name: 'Health Check Policy',
    yaml: `name: Health Check Policy
description: Simple health check and monitoring circuit
filters:
  - name: BasicHealthAuth
    type: HTTPBasicFilter
    username: "healthcheck"
    password: "{{health-password}}"
  - name: HealthRateLimit
    type: ThrottlingFilter
    maxRequests: 1000
    timeWindow: 60
  - name: HealthBackend
    type: ConnectToURLFilter
    url: "https://health.enterprise.com/status"
    timeout: 5
  - name: HealthMetrics
    type: MetricsFilter
    metricName: "health_check_count"
    metricValue: "1"
    metricDimensions:
      service: "enterprise-api"
      environment: "production"
routing:
  default: HealthBackend
security:
  authentication: BasicHealthAuth
performance:
  rateLimit: HealthRateLimit
monitoring:
  metrics: HealthMetrics`
  },

  'oauth-security': {
    name: 'OAuth Security Policy',
    yaml: `name: OAuth Security Policy
description: Enterprise OAuth 2.0 security with JWT validation
filters:
  - name: OAuthValidation
    type: OAuth2Filter
    tokenEndpoint: "https://oauth.enterprise.com/token"
    clientId: "enterprise-api-client"
    clientSecret: "{{oauth-client-secret}}"
    scope: "api.read api.write"
  - name: SecurityRateLimit
    type: ThrottlingFilter
    maxRequests: 5000
    timeWindow: 60
  - name: SecureBackend
    type: ConnectToURLFilter
    url: "https://api.enterprise.com"
    timeout: 30
  - name: SecurityMetrics
    type: MetricsFilter
    metricName: "oauth_requests"
    metricValue: "1"
  - name: SecurityMonitoring
    type: MonitoringFilter
    logLevel: "INFO"
    includeHeaders: true
    includeBody: false
routing:
  default: SecureBackend
security:
  oauth: OAuthValidation
  rateLimit: SecurityRateLimit
monitoring:
  metrics: SecurityMetrics
  logging: SecurityMonitoring`
  },

  'xml-threat': {
    name: 'XML Threat Protection Policy',
    yaml: `name: XML Threat Policy
description: XML threat protection and validation
filters:
  - name: XMLThreatCheck
    type: XMLThreatProtectionFilter
    maxDepth: 10
    maxNodeCount: 1000
    maxAttributeCount: 50
    maxNamespaceCount: 10
    detectExternalEntities: true
  - name: XMLRateLimit
    type: ThrottlingFilter
    maxRequests: 2000
    timeWindow: 60
  - name: XMLBackend
    type: ConnectToURLFilter
    url: "https://xml.enterprise.com/api"
    timeout: 15
  - name: XMLMetrics
    type: MetricsFilter
    metricName: "xml_processing_count"
    metricValue: "1"
  - name: XMLCache
    type: ResponseCacheFilter
    cacheDuration: 300
    cacheKey: "xml-response"
    varyByHeaders: ["Content-Type"]
routing:
  default: XMLBackend
security:
  threatProtection: XMLThreatCheck
  rateLimit: XMLRateLimit
performance:
  caching: XMLCache
monitoring:
  metrics: XMLMetrics`
  },

  'content-transformation': {
    name: 'Content Transformation Policy',
    yaml: `name: Content Transformation Policy
description: Enterprise content transformation and validation circuit
filters:
  - name: JSONToXMLTransform
    type: JSONTransformFilter
    rootElement: "Request"
    namespaceUri: "http://enterprise.com/api/v1"
    arrayDetection: true
  - name: XSLTransformation
    type: XSLTransformFilter
    xslContent: |
      <?xml version="1.0" encoding="UTF-8"?>
      <xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
        <xsl:template match="/">
          <EnterpriseRequest>
            <Header>
              <Timestamp><xsl:value-of select="current-dateTime()"/></Timestamp>
              <Source>APIM Gateway</Source>
            </Header>
            <Body>
              <xsl:copy-of select="*"/>
            </Body>
          </EnterpriseRequest>
        </xsl:template>
      </xsl:stylesheet>
    parameters:
      source: "API_GATEWAY"
      version: "1.0"
  - name: XMLToJSONTransform
    type: XMLToJSONFilter
    namespaceHandling: "ignore"
    arrayDetection: "auto"
    rootElement: "Response"
  - name: ContentModification
    type: ContentModifyFilter
    content: |
      {
        "apiVersion": "v1",
        "timestamp": "@(DateTime.Now)",
        "originalContent": @(context.Request.Body.As<string>()),
        "metadata": {
          "source": "enterprise-gateway",
          "transformed": true
        }
      }
    contentType: "application/json"
  - name: JSONThreatProtection
    type: JSONThreatProtectionFilter
    maxDepth: 8
    maxArrayElements: 1000
    maxObjectProperties: 200
    maxStringLength: 5000
  - name: CompressionFilter
    type: CompressionFilter
    compressionLevel: 6
    compressionTypes: ["application/json", "application/xml", "text/xml"]
  - name: LoadBalancedBackend
    type: LoadBalancingFilter
    algorithm: "round_robin"
    healthCheck: "/health"
    servers:
      - url: "https://api1.enterprise.com"
        weight: 50
      - url: "https://api2.enterprise.com" 
        weight: 30
      - url: "https://api3.enterprise.com"
        weight: 20
  - name: FailoverRetry
    type: FailoverFilter
    retryCount: 3
    retryInterval: 1000
    backoffMultiplier: 2
    maxInterval: 10000
transformation:
  request: [JSONToXMLTransform, XSLTransformation]
  response: [XMLToJSONTransform, ContentModification]
security:
  threatProtection: JSONThreatProtection
optimization:
  compression: CompressionFilter
backend:
  loadBalancing: LoadBalancedBackend
  failover: FailoverRetry
performance:
  cacheHeaders: true
  compressionEnabled: true
  keepAlive: true`
  }
};

export function getExamplePolicy(policyKey) {
  return EXAMPLE_POLICIES[policyKey] || null;
}

export function getAllExamples() {
  return Object.keys(EXAMPLE_POLICIES).map(key => ({
    key,
    name: EXAMPLE_POLICIES[key].name
  }));
}
