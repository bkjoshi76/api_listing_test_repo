# Axway to Azure APIM Converter - Web UI

Modern web-based interface for converting Axway FilterCircuit policies to Azure APIM XML policies.

## Features

- 🎨 **Beautiful UI**: Modern dark theme with glassmorphism effects
- ⚡ **Real-time Conversion**: Instant YAML to XML conversion
- 📝 **Syntax Highlighting**: Color-coded XML output
- 📊 **Statistics**: Conversion success rates and filter counts
- 📱 **Responsive**: Works on desktop, tablet, and mobile
- 🚀 **Fast**: Client-side processing, no server required
- 📦 **Example Policies**: 4 pre-loaded enterprise examples

## Quick Start

### Local Development

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Open browser to http://localhost:5173
```

### Production Build

```bash
# Build for production
npm run build

# Preview production build
npm run preview
```

## Usage

1. **Select an Example**: Choose from 4 pre-loaded enterprise policies
2. **Or Paste YAML**: Enter your own Axway FilterCircuit YAML
3. **Convert**: Click "Convert to XML" or wait for auto-conversion
4. **Copy**: Use "Copy XML" button to copy the result
5. **Deploy**: Use the generated XML in Azure APIM

## Supported Filter Types

The converter supports 25+ Axway filter types including:

- **Authentication**: HTTPBasicFilter, OAuth2Filter, JWTFilter
- **Security**: XMLThreatProtectionFilter, JSONThreatProtectionFilter, IP filters
- **Rate Limiting**: ThrottlingFilter, QuotaFilter, ConcurrencyFilter
- **Transformation**: XSLTransformFilter, JSONTransformFilter, XMLToJSONFilter
- **Routing**: ConnectToURLFilter, LoadBalancingFilter, FailoverFilter
- **Monitoring**: MetricsFilter, MonitoringFilter
- **Caching**: ResponseCacheFilter, CompressionFilter

## Deployment to Azure

### Azure Static Web Apps

1. **Create Azure Static Web App**:
   ```bash
   az staticwebapp create \
     --name axway-apim-converter \
     --resource-group my-resource-group \
     --source https://github.com/your-repo \
     --location eastus2 \
     --branch main \
     --app-location "/web" \
     --output-location "dist"
   ```

2. **Configure Build**:
   - Build command: `npm run build`
   - Output directory: `dist`
   - App location: `/web`

3. **Deploy**:
   - Push to GitHub
   - Azure will automatically build and deploy

### Manual Deployment

```bash
# Build the application
npm run build

# Deploy the dist folder to your hosting service
# (Azure Static Web Apps, Netlify, Vercel, etc.)
```

## Project Structure

```
web/
├── index.html              # Main HTML file
├── style.css               # Styles with dark theme
├── app.js                  # Main application logic
├── converter.js            # YAML to XML converter
├── filter-mappings.js      # Filter type mappings
├── examples.js             # Example policies
├── package.json            # Dependencies
├── vite.config.js          # Vite configuration
└── staticwebapp.config.json # Azure SWA config
```

## Technologies

- **Vite**: Fast build tool and dev server
- **Vanilla JavaScript**: No framework dependencies
- **js-yaml**: YAML parsing library
- **CSS3**: Modern styling with custom properties
- **HTML5**: Semantic markup

## Browser Support

- Chrome/Edge: Latest 2 versions
- Firefox: Latest 2 versions
- Safari: Latest 2 versions

## License

MIT License - See parent project for details

## Contributing

Contributions welcome! Please see the main project README for guidelines.
