import os
import zipfile
import datetime

def create_zip(source_dir, output_filename):
    # Exclude patterns
    exclude_dirs = {'node_modules', '__pycache__', '.git', '.vscode', '.idea', 'dist', 'build', 'coverage'}
    exclude_files = {'.DS_Store', 'Thumbs.db', os.path.basename(output_filename)}

    with zipfile.ZipFile(output_filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(source_dir):
            # Modify dirs in-place to skip excluded directories
            dirs[:] = [d for d in dirs if d not in exclude_dirs]
            
            for file in files:
                if file in exclude_files:
                    continue
                if file.endswith('.zip'): # Avoid zipping other zips if any
                    continue
                    
                file_path = os.path.join(root, file)
                arcname = os.path.relpath(file_path, start=source_dir)
                
                # Prepend a root folder name to the archive structure for cleaner extraction
                arcname = os.path.join("axway-azure-apim-converter-v1.6.8", arcname)
                
                print(f"Adding {arcname}")
                zipf.write(file_path, arcname)

if __name__ == "__main__":
    source_directory = r"c:\projects\axway-azure-apim-converter-complete-v1.1.0\axway-azure-apim-converter-complete"
    output_zip = r"c:\projects\axway-azure-apim-converter-complete-v1.1.0\axway-azure-apim-converter-complete\axway-azure-apim-converter-v1.6.8.zip"
    
    print(f"Creating release zip: {output_zip}")
    create_zip(source_directory, output_zip)
    print("Done.")
