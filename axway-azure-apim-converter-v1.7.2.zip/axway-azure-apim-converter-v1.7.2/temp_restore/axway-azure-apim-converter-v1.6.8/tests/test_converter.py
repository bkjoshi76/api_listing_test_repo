#!/usr/bin/env python3
"""
Comprehensive Test Suite for Strategic Axway to Azure APIM Converter

Demo test coverage for all conversion operations, validation,
and strategic assessment capabilities.

Author: Enterprise API Team
Version: 1.0.0
License: MIT
"""

import unittest
import tempfile
import shutil
import os
import json
import yaml
from unittest.mock import patch, MagicMock
import sys

# Add src directory to path for imports
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from strategic_filter_converter import StrategicFilterConverter
from validate_apim_policies import APIMPolicyValidator
from filter_mappings import FilterMappings, FilterComplexity, PolicySection
from utils.utilities import FileUtils, ValidationUtils, DataUtils, ConversionUtils

class TestStrategicFilterConverter(unittest.TestCase):
    """Test suite for the strategic filter converter."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.converter = StrategicFilterConverter()
        self.temp_dir = tempfile.mkdtemp()
        
        # Sample FilterCircuit configuration
        self.sample_circuit = {
            'name': 'TestCircuit',
            'filters': [
                {
                    'name': 'BasicAuth',
                    'type': 'HTTPBasicFilter',
                    'username': 'testuser',
                    'password': 'testpass'
                },
                {
                    'name': 'RateLimit', 
                    'type': 'ThrottlingFilter',
                    'maxRequests': 100,
                    'timeWindow': 60
                },
                {
                    'name': 'XMLThreat',
                    'type': 'XMLThreatProtectionFilter',
                    'maxDepth': 10,
                    'maxNodeCount': 1000
                }
            ]
        }
    
    def tearDown(self):
        """Clean up test fixtures."""
        shutil.rmtree(self.temp_dir, ignore_errors=True)
    
    def test_display_strategic_matrix(self):
        """Test strategic matrix display."""
        # Should not raise any exceptions
        try:
            self.converter.display_strategic_matrix()
        except Exception as e:
            self.fail(f"display_strategic_matrix raised {e}")
    
    def test_convert_http_basic_filter(self):
        """Test HTTP Basic Filter conversion."""
        config = {'username': 'admin', 'password': 'secret'}
        result = self.converter.convert_filter('HTTPBasicFilter', config)
        
        self.assertEqual(result['type'], 'authentication-basic')
        self.assertIn('policy', result)
        self.assertIn('authentication-basic', result['policy'])
        self.assertEqual(result['complexity'], 'Simple')
        
    def test_convert_oauth_filter(self):
        """Test OAuth Filter conversion."""
        config = {
            'tokenEndpoint': 'https://auth.example.com/token',
            'clientId': 'test-client',
            'audience': 'api://default'
        }
        result = self.converter.convert_filter('OAuth2Filter', config)
        
        self.assertEqual(result['type'], 'validate-jwt')
        self.assertIn('policy', result)
        self.assertEqual(result['complexity'], 'Moderate')
    
    def test_convert_xml_threat_filter(self):
        """Test XML Threat Protection Filter conversion."""
        config = {
            'maxDepth': 15,
            'maxNodeCount': 2000,
            'maxAttributeCount': 150,
            'detectExternalEntities': True
        }
        result = self.converter.convert_filter('XMLThreatProtectionFilter', config)
        
        self.assertEqual(result['type'], 'xml-threat-detection')
        self.assertIn('policy', result)
        self.assertEqual(result['complexity'], 'Complex')
        
        # Check specific configuration mapping
        xml_policy = result['policy']['xml-threat-detection']
        self.assertEqual(xml_policy['maximum-depth'], '15')
        self.assertEqual(xml_policy['maximum-node-count'], '2000')
    
    def test_convert_unsupported_filter(self):
        """Test conversion of unsupported filter."""
        result = self.converter.convert_filter('UnsupportedFilter', {})
        
        self.assertEqual(result['type'], 'externalized')
        self.assertIn('original_filter', result)
        self.assertEqual(result['original_filter'], 'UnsupportedFilter')
    
    def test_convert_filter_circuit(self):
        """Test complete FilterCircuit conversion."""
        result = self.converter.convert_filter_circuit(self.sample_circuit)
        
        self.assertIn('name', result)
        self.assertIn('statistics', result)
        self.assertIn('inbound_policies', result)
        
        stats = result['statistics']
        self.assertEqual(stats['total_filters'], 3)
        self.assertEqual(stats['converted_filters'], 3)
        self.assertEqual(stats['externalized_filters'], 0)
        self.assertEqual(stats['success_rate'], '100%')
    
    def test_convert_yaml_to_apim(self):
        """Test YAML file conversion."""
        # Create test YAML file
        yaml_file = os.path.join(self.temp_dir, 'test_circuit.yaml')
        with open(yaml_file, 'w') as f:
            yaml.dump(self.sample_circuit, f)
        
        result = self.converter.convert_yaml_to_apim(yaml_file)
        
        self.assertTrue(result['success'])
        self.assertIn('apim_policy', result)
        self.assertIn('statistics', result)
    
    def test_batch_convert(self):
        """Test batch conversion of multiple YAML files."""
        # Create multiple test YAML files
        for i in range(3):
            yaml_file = os.path.join(self.temp_dir, f'circuit_{i}.yaml')
            circuit = self.sample_circuit.copy()
            circuit['name'] = f'TestCircuit_{i}'
            with open(yaml_file, 'w') as f:
                yaml.dump(circuit, f)
        
        output_dir = os.path.join(self.temp_dir, 'output')
        result = self.converter.batch_convert(self.temp_dir, output_dir)
        
        self.assertTrue(result['success'])
        self.assertEqual(result['total_files'], 3)
        self.assertEqual(result['successful_conversions'], 3)
    
    def test_strategic_assessment(self):
        """Test strategic assessment functionality."""
        circuits = [self.sample_circuit] * 2
        assessment = self.converter.strategic_assessment(circuits)
        
        self.assertIn('total_circuits', assessment)
        self.assertIn('complexity_analysis', assessment)
        self.assertIn('migration_recommendations', assessment)
        self.assertIn('estimated_effort_days', assessment)
        
        self.assertEqual(assessment['total_circuits'], 2)

class TestAPIMPolicyValidator(unittest.TestCase):
    """Test suite for APIM policy validator."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.validator = APIMPolicyValidator()
        self.temp_dir = tempfile.mkdtemp()
        
        # Sample APIM policy
        self.sample_policy = {
            'name': 'TestPolicy',
            'inbound_policies': [
                {
                    'type': 'authentication-basic',
                    'policy': {
                        'authentication-basic': {
                            'username': '{{username}}',
                            'password': '{{password}}'
                        }
                    }
                },
                {
                    'type': 'rate-limit',
                    'policy': {
                        'rate-limit': {
                            'calls': '100',
                            'renewal-period': '60',
                            'counter-key': '@(context.Request.IpAddress)'
                        }
                    }
                }
            ]
        }
    
    def tearDown(self):
        """Clean up test fixtures."""
        shutil.rmtree(self.temp_dir, ignore_errors=True)
    
    def test_validate_policy_structure(self):
        """Test policy structure validation."""
        result = self.validator.validate_policy_structure(self.sample_policy)
        
        self.assertTrue(result['structure_valid'])
        self.assertEqual(len(result['issues']), 0)
    
    def test_validate_invalid_structure(self):
        """Test validation of invalid policy structure."""
        invalid_policy = "not a dictionary"
        result = self.validator.validate_policy_structure(invalid_policy)
        
        self.assertFalse(result['structure_valid'])
        self.assertIn('Policy must be a JSON object', result['issues'])
    
    def test_validate_individual_policies(self):
        """Test individual policy validation."""
        policies = self.sample_policy['inbound_policies']
        result = self.validator.validate_individual_policies(policies)
        
        self.assertTrue(result['policies_valid'])
        self.assertEqual(result['validated_policies'], 2)
        self.assertEqual(result['supported_policies'], 2)
        self.assertEqual(result['unsupported_policies'], 0)
    
    def test_validate_unsupported_policy(self):
        """Test validation of unsupported policy type."""
        unsupported_policy = [{
            'type': 'unsupported-policy-type',
            'policy': {'config': 'value'}
        }]
        
        result = self.validator.validate_individual_policies(unsupported_policy)
        
        self.assertFalse(result['policies_valid'])
        self.assertEqual(result['unsupported_policies'], 1)
    
    def test_validate_security_compliance(self):
        """Test security compliance validation."""
        result = self.validator.validate_security_compliance(self.sample_policy)
        
        self.assertIn('security_score', result)
        self.assertIn('security_compliant', result)
        self.assertIsInstance(result['security_score'], (int, float))
    
    def test_validate_enterprise_compliance(self):
        """Test enterprise compliance validation."""
        result = self.validator.validate_enterprise_compliance(self.sample_policy)
        
        self.assertIn('compliance_score', result)
        self.assertIn('enterprise_compliant', result)
        self.assertIsInstance(result['compliance_score'], (int, float))
    
    def test_validate_policy_file(self):
        """Test complete policy file validation."""
        # Create test policy file
        policy_file = os.path.join(self.temp_dir, 'test_policy.json')
        with open(policy_file, 'w') as f:
            json.dump(self.sample_policy, f)
        
        result = self.validator.validate_policy_file(policy_file)
        
        self.assertIn('overall_valid', result)
        self.assertIn('summary', result)
        self.assertIn('file_path', result)
    
    def test_validate_directory(self):
        """Test directory validation."""
        # Create multiple test policy files
        for i in range(2):
            policy_file = os.path.join(self.temp_dir, f'policy_{i}.json')
            policy = self.sample_policy.copy()
            policy['name'] = f'TestPolicy_{i}'
            with open(policy_file, 'w') as f:
                json.dump(policy, f)
        
        result = self.validator.validate_directory(self.temp_dir)
        
        self.assertTrue(result['success'])
        self.assertIn('overall_statistics', result)
        self.assertIn('file_results', result)
        self.assertEqual(len(result['file_results']), 2)

class TestFilterMappings(unittest.TestCase):
    """Test suite for filter mappings."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.mappings = FilterMappings()
    
    def test_get_filter_mapping(self):
        """Test getting filter mapping."""
        mapping = self.mappings.get_filter_mapping('HTTPBasicFilter')
        
        self.assertIsNotNone(mapping)
        self.assertEqual(mapping['apim_policy'], 'authentication-basic')
        self.assertEqual(mapping['complexity'], FilterComplexity.SIMPLE)
    
    def test_get_unsupported_filter_mapping(self):
        """Test getting mapping for unsupported filter."""
        mapping = self.mappings.get_filter_mapping('UnsupportedFilter')
        self.assertIsNone(mapping)
    
    def test_get_supported_filters(self):
        """Test getting list of supported filters."""
        filters = self.mappings.get_supported_filters()
        
        self.assertIsInstance(filters, list)
        self.assertIn('HTTPBasicFilter', filters)
        self.assertIn('OAuth2Filter', filters)
        self.assertIn('XMLThreatProtectionFilter', filters)
    
    def test_get_filters_by_complexity(self):
        """Test filtering by complexity."""
        simple_filters = self.mappings.get_filters_by_complexity(FilterComplexity.SIMPLE)
        complex_filters = self.mappings.get_filters_by_complexity(FilterComplexity.COMPLEX)
        
        self.assertIsInstance(simple_filters, list)
        self.assertIsInstance(complex_filters, list)
        self.assertIn('HTTPBasicFilter', simple_filters)
        self.assertIn('XMLThreatProtectionFilter', complex_filters)
    
    def test_get_filters_by_section(self):
        """Test filtering by policy section."""
        inbound_filters = self.mappings.get_filters_by_section(PolicySection.INBOUND)
        backend_filters = self.mappings.get_filters_by_section(PolicySection.BACKEND)
        
        self.assertIsInstance(inbound_filters, list)
        self.assertIsInstance(backend_filters, list)
    
    def test_calculate_migration_effort(self):
        """Test migration effort calculation."""
        filter_list = ['HTTPBasicFilter', 'OAuth2Filter', 'XMLThreatProtectionFilter']
        effort = self.mappings.calculate_migration_effort(filter_list)
        
        self.assertIn('total_effort_hours', effort)
        self.assertIn('total_effort_days', effort)
        self.assertIn('complexity_breakdown', effort)
        self.assertIn('testing_requirements', effort)
        self.assertIn('dependencies', effort)
        
        self.assertEqual(effort['filters_analyzed'], 3)
        self.assertEqual(effort['supported_filters'], 3)
    
    def test_get_enterprise_recommendations(self):
        """Test enterprise recommendations generation."""
        filter_list = ['HTTPBasicFilter', 'OAuth2Filter', 'XMLThreatProtectionFilter'] * 3
        recommendations = self.mappings.get_enterprise_recommendations(filter_list)
        
        self.assertIn('migration_approach', recommendations)
        self.assertIn('priority_phases', recommendations)
        self.assertIn('resource_requirements', recommendations)

class TestUtilities(unittest.TestCase):
    """Test suite for utility functions."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.temp_dir = tempfile.mkdtemp()
    
    def tearDown(self):
        """Clean up test fixtures."""
        shutil.rmtree(self.temp_dir, ignore_errors=True)
    
    def test_file_utils_ensure_directory(self):
        """Test directory creation."""
        new_dir = os.path.join(self.temp_dir, 'new', 'nested', 'directory')
        result = FileUtils.ensure_directory(new_dir)
        
        self.assertEqual(result, new_dir)
        self.assertTrue(os.path.exists(new_dir))
    
    def test_file_utils_yaml_operations(self):
        """Test YAML file operations."""
        test_data = {'key': 'value', 'number': 42}
        yaml_file = os.path.join(self.temp_dir, 'test.yaml')
        
        # Write YAML
        FileUtils.write_yaml_file(test_data, yaml_file)
        self.assertTrue(os.path.exists(yaml_file))
        
        # Read YAML
        read_data = FileUtils.read_yaml_file(yaml_file)
        self.assertEqual(read_data, test_data)
    
    def test_file_utils_json_operations(self):
        """Test JSON file operations."""
        test_data = {'key': 'value', 'number': 42}
        json_file = os.path.join(self.temp_dir, 'test.json')
        
        # Write JSON
        FileUtils.write_json_file(test_data, json_file)
        self.assertTrue(os.path.exists(json_file))
        
        # Read JSON
        read_data = FileUtils.read_json_file(json_file)
        self.assertEqual(read_data, test_data)
    
    def test_validation_utils_policy_name(self):
        """Test policy name validation."""
        # Valid names
        valid, issues = ValidationUtils.validate_policy_name('ValidPolicy')
        self.assertTrue(valid)
        self.assertEqual(len(issues), 0)
        
        valid, issues = ValidationUtils.validate_policy_name('policy_with_underscores')
        self.assertTrue(valid)
        
        # Invalid names
        valid, issues = ValidationUtils.validate_policy_name('123invalid')
        self.assertFalse(valid)
        self.assertGreater(len(issues), 0)
        
        valid, issues = ValidationUtils.validate_policy_name('sh')  # too short
        self.assertFalse(valid)
    
    def test_validation_utils_url(self):
        """Test URL validation."""
        # Valid URLs
        valid, issues = ValidationUtils.validate_url('https://example.com')
        self.assertTrue(valid)
        
        valid, issues = ValidationUtils.validate_url('http://localhost:8080/api')
        self.assertTrue(valid)
        
        # Invalid URLs
        valid, issues = ValidationUtils.validate_url('not-a-url')
        self.assertFalse(valid)
        
        valid, issues = ValidationUtils.validate_url('ftp://example.com')
        self.assertFalse(valid)
    
    def test_data_utils_merge_dictionaries(self):
        """Test dictionary merging."""
        dict1 = {'a': 1, 'b': {'x': 10}}
        dict2 = {'b': {'y': 20}, 'c': 3}
        
        # Shallow merge
        result = DataUtils.merge_dictionaries(dict1, dict2, deep=False)
        self.assertEqual(result['b'], {'y': 20})  # dict2 overwrites dict1
        
        # Deep merge
        result = DataUtils.merge_dictionaries(dict1, dict2, deep=True)
        self.assertEqual(result['b'], {'x': 10, 'y': 20})  # nested merge
    
    def test_data_utils_flatten_dictionary(self):
        """Test dictionary flattening."""
        nested_dict = {
            'level1': {
                'level2': {
                    'value': 'test'
                },
                'other': 42
            }
        }
        
        flattened = DataUtils.flatten_dictionary(nested_dict)
        self.assertIn('level1.level2.value', flattened)
        self.assertEqual(flattened['level1.level2.value'], 'test')
        self.assertEqual(flattened['level1.other'], 42)
    
    def test_data_utils_extract_variables(self):
        """Test variable extraction from text."""
        text = "This has {{variable1}} and {{variable2}} placeholders"
        variables = DataUtils.extract_variables(text)
        
        self.assertEqual(len(variables), 2)
        self.assertIn('variable1', variables)
        self.assertIn('variable2', variables)
    
    def test_data_utils_replace_variables(self):
        """Test variable replacement in text."""
        text = "Hello {{name}}, your score is {{score}}"
        variables = {'name': 'John', 'score': '95'}
        
        result = DataUtils.replace_variables(text, variables)
        self.assertEqual(result, "Hello John, your score is 95")
    
    def test_conversion_utils_generate_policy_id(self):
        """Test policy ID generation."""
        policy_id = ConversionUtils.generate_policy_id('TestCircuit', 'HTTPBasicFilter')
        
        self.assertIsInstance(policy_id, str)
        self.assertIn('testcircuit', policy_id.lower())
        self.assertIn('httpbasicfilter', policy_id.lower())
    
    def test_conversion_utils_normalize_filter_name(self):
        """Test filter name normalization."""
        # Test with package prefix
        normalized = ConversionUtils.normalize_filter_name('com.vordel.circuit.HTTPBasicFilter')
        self.assertEqual(normalized, 'HTTPBasicFilter')
        
        # Test with org.axway prefix
        normalized = ConversionUtils.normalize_filter_name('org.axway.security.AuthFilter')
        self.assertEqual(normalized, 'AuthFilter')
        
        # Test without prefix
        normalized = ConversionUtils.normalize_filter_name('SimpleFilter')
        self.assertEqual(normalized, 'SimpleFilter')
    
    def test_conversion_utils_convert_time_units(self):
        """Test time unit conversion."""
        # Convert minutes to seconds
        result = ConversionUtils.convert_time_units('5', 'minutes', 'seconds')
        self.assertEqual(result, 300)
        
        # Convert hours to minutes
        result = ConversionUtils.convert_time_units('2', 'hours', 'minutes')
        self.assertEqual(result, 120)
        
        # Convert days to hours
        result = ConversionUtils.convert_time_units('1', 'days', 'hours')
        self.assertEqual(result, 24)

def run_tests():
    """Run all test suites."""
    # Create test suite
    test_suite = unittest.TestSuite()
    
    # Add test classes
    test_classes = [
        TestStrategicFilterConverter,
        TestAPIMPolicyValidator,
        TestFilterMappings,
        TestUtilities
    ]
    
    for test_class in test_classes:
        tests = unittest.TestLoader().loadTestsFromTestCase(test_class)
        test_suite.addTests(tests)
    
    # Run tests
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(test_suite)
    
    # Return success status
    return result.wasSuccessful()

if __name__ == '__main__':
    success = run_tests()
    exit(0 if success else 1)
