import os
import glob
import xml.etree.ElementTree as ET
from xml.dom import minidom

# Paths
base_dir = r"c:\projects\axway-azure-apim-converter-complete-v1.1.0\axway-azure-apim-converter-complete"
test_dir = os.path.join(base_dir, "tests", "comparison_run")

def normalize_xml(xml_string):
    """Normalize XML by removing comments, whitespace, and sorting attributes."""
    try:
        # Parse
        parser = ET.XMLParser(target=ET.TreeBuilder(insert_comments=False))
        root = ET.fromstring(xml_string, parser=parser)
        
        # Canonicalize (simple version)
        return ET.tostring(root, method='xml', encoding='unicode')
    except Exception as e:
        return f"Error parsing XML: {e}"

def compare_files():
    web_files = glob.glob(os.path.join(test_dir, "*_web.xml"))
    
    print(f"Found {len(web_files)} Web output files to compare.")
    print("-" * 60)
    print(f"{'Example':<30} | {'Status':<10} | {'Details':<20}")
    print("-" * 60)
    
    for web_file in web_files:
        filename = os.path.basename(web_file)
        example_name = filename.replace('_web.xml', '')
        python_file = os.path.join(test_dir, f"{example_name}_python.xml")
        
        if not os.path.exists(python_file):
            print(f"{example_name:<30} | SKIPPED    | Python output missing")
            continue
            
        with open(web_file, 'r') as f:
            web_content = f.read()
            
        with open(python_file, 'r') as f:
            python_content = f.read()
            
        web_norm = normalize_xml(web_content)
        python_norm = normalize_xml(python_content)
        
        if web_norm == python_norm:
            print(f"{example_name:<30} | MATCH      | Identical XML structure")
        else:
            # Simple diff check
            web_len = len(web_norm)
            py_len = len(python_norm)
            diff_percent = abs(web_len - py_len) / max(web_len, py_len) * 100
            
            if diff_percent < 5:
                print(f"{example_name:<30} | MISMATCH   | Minor diff ({diff_percent:.1f}%)")
            else:
                print(f"{example_name:<30} | MISMATCH   | Major diff ({diff_percent:.1f}%)")

if __name__ == "__main__":
    compare_files()
