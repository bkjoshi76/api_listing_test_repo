import { AxwayToApimConverter } from './src/js/axway-converter.js';

const converter = new AxwayToApimConverter();

const config = {
    name: "Simple API Key",
    securityProfiles: [
        {
            name: "_default",
            isDefault: true,
            devices: [
                {
                    name: "API Key",
                    type: "apiKey",
                    properties: { apiKeyFieldName: "KeyId" }
                }
            ]
        }
    ]
};

const result = converter.convertFilterCircuitToXml(config);

console.log("Used Filter Types:", result.statistics.usedFilterTypes);

if (result.statistics.usedFilterTypes &&
    result.statistics.usedFilterTypes.includes("ExtractRESTHeaderFilter")) {
    console.log("VERIFICATION PASSED: apiKey mapped to ExtractRESTHeaderFilter.");
} else {
    console.error("VERIFICATION FAILED: ExtractRESTHeaderFilter missing.");
    process.exit(1);
}
