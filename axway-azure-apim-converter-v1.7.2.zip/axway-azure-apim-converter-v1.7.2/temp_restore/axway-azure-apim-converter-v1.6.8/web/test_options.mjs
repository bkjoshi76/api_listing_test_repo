import fs from 'fs';
import { AxwayToApimConverter } from './src/js/axway-converter.js';

const converter = new AxwayToApimConverter();

// Read test file
const configContent = fs.readFileSync('../options_test.json', 'utf8');
const config = JSON.parse(configContent);

// Test with options enabled
const options = {
    includeRateLimit: true,
    includeLogging: true,
    removeCredentials: true
};

// Convert
const result = converter.convertFilterCircuitToXml(config, options);

// Write output
fs.writeFileSync('../options_output.xml', result.xml);
console.log('Options conversion complete. Output written to ../options_output.xml');
console.log('\n--- Generated Policy ---');
console.log(result.xml);
