import fs from 'fs';
import path from 'path';
import { AxwayToApimConverter } from './src/js/axway-converter.js';

// Read the test file
const testFile = path.resolve('../method_override_test.json');
const testData = JSON.parse(fs.readFileSync(testFile, 'utf8'));

// Create converter instance
const converter = new AxwayToApimConverter();

// Convert
console.log('Converting method_override_test.json...\n');
const result = converter.convertFilterCircuitToXml(testData);

// Display result
console.log('Generated XML:');
console.log(result.xml);

// Verify expected elements
const xml = result.xml;
const checks = [
    { name: 'Inbound Overrides Comment', pattern: /<!-- Method-Level Inbound Overrides -->/ },
    { name: 'Outbound Overrides Comment', pattern: /<!-- Method-Level Outbound Overrides -->/ },
    { name: 'findPetsByStatus condition', pattern: /@\(context\.Operation\.Id == "findPetsByStatus"\)/ },
    { name: 'getOrderById condition', pattern: /@\(context\.Operation\.Id == "getOrderById"\)/ },
    { name: 'API Key check-header', pattern: /<check-header name="KeyId"/ },
    { name: 'CORS policy', pattern: /<cors allow-credentials="false">/ },
    { name: 'HTTP Basic auth', pattern: /<authentication-basic username="usernameabc"/ },
    { name: 'Custom header parameter', pattern: /<set-header name="additionalOutboundParam"/ }
];

console.log('\n=== Verification Results ===');
let allPassed = true;
checks.forEach(check => {
    const passed = check.pattern.test(xml);
    console.log(`${passed ? '✓' : '✗'} ${check.name}`);
    if (!passed) allPassed = false;
});

if (allPassed) {
    console.log('\n✅ All verification checks PASSED!');
    process.exit(0);
} else {
    console.log('\n❌ Some verification checks FAILED!');
    process.exit(1);
}
