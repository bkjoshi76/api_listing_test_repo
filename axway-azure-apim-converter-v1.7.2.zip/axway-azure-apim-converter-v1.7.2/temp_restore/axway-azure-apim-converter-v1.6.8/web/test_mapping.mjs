import { AxwayToApimConverter } from './src/js/axway-converter.js';

const converter = new AxwayToApimConverter();

const config = {
    name: "Test Policy",
    filters: [
        { type: "Reflector", name: "Reflect" },
        { type: "JavaScriptFilter", name: "Script" }
    ]
};

const result = converter.convertFilterCircuitToXml(config);

console.log("Success:", result.success !== false); // convertFilterCircuitToXml returns object directly, not wrapped in success
console.log("Used Filter Types:", result.statistics.usedFilterTypes);

if (result.statistics.usedFilterTypes &&
    result.statistics.usedFilterTypes.includes("Reflector") &&
    result.statistics.usedFilterTypes.includes("JavaScriptFilter")) {
    console.log("VERIFICATION PASSED: usedFilterTypes correctly populated.");
} else {
    console.error("VERIFICATION FAILED: usedFilterTypes missing or incorrect.");
    process.exit(1);
}
