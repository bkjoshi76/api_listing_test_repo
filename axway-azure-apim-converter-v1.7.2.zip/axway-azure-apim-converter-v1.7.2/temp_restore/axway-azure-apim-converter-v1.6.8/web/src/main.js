/**
 * Main application entry point
 */

import { convertAxwayToApim, generateDeploymentCommands } from './js/converter.js';
import { AxwayToApimConverter } from './js/axway-converter.js';
import { getExample } from './js/examples.js';
import { FILTER_MAPPINGS } from './js/filter-mappings.js';

// Application state
let currentConfig = null;
let currentResult = null;
let currentInputType = 'json'; // 'json', 'yaml', or 'groovy'

// Initialize advanced converter
const advancedConverter = new AxwayToApimConverter();

// DOM Elements
const elements = {
    configInput: null,
    includeRateLimitCheckbox: null,
    rateLimitCallsInput: null,
    rateLimitPeriodInput: null,
    includeLoggingCheckbox: null,
    removeCredentialsCheckbox: null,
    convertBtn: null,
    outputSection: null,
    policyOutput: null,
    statusMessage: null,
    toast: null,
    themeToggle: null,
    loadExampleBtn: null,
    exampleModal: null,
    closeModalBtn: null,
    uploadFileBtn: null,
    fileInput: null,
    copyPolicyBtn: null,
    downloadPolicyBtn: null
};

/**
 * Initialize application
 */
function init() {
    // Cache DOM elements
    elements.configInput = document.getElementById('axway-config-input');
    elements.includeRateLimitCheckbox = document.getElementById('include-rate-limit');
    elements.rateLimitCallsInput = document.getElementById('rate-limit-calls');
    elements.rateLimitPeriodInput = document.getElementById('rate-limit-period');
    elements.includeLoggingCheckbox = document.getElementById('include-logging');
    elements.removeCredentialsCheckbox = document.getElementById('remove-credentials');
    elements.convertBtn = document.getElementById('convert-btn');
    elements.outputSection = document.getElementById('output-section');
    elements.policyOutput = document.getElementById('policy-output');
    elements.statusMessage = document.getElementById('status-message');
    elements.toast = document.getElementById('toast');
    elements.themeToggle = document.getElementById('theme-toggle');
    elements.loadExampleBtn = document.getElementById('load-example-btn');
    elements.exampleModal = document.getElementById('example-modal');
    elements.closeModalBtn = document.getElementById('close-modal');
    elements.uploadFileBtn = document.getElementById('upload-file-btn');
    elements.fileInput = document.getElementById('file-input');
    elements.copyPolicyBtn = document.getElementById('copy-policy-btn');
    elements.downloadPolicyBtn = document.getElementById('download-policy-btn');

    // Initialize theme
    initializeTheme();

    // Setup event listeners
    setupEventListeners();

    // Check for saved state
    const savedConfig = localStorage.getItem('axway-config');
    if (savedConfig) {
        elements.configInput.value = savedConfig;
    } else {
        loadExample('petstore');
    }

    // Populate mapping table
    populateMappingTable();
}

/**
 * Populate the filter mapping table
 * @param {string[]} usedFilterTypes - Optional list of filter types to show
 */
function populateMappingTable(usedFilterTypes = null) {
    const tableBody = document.getElementById('mapping-table-body');
    if (!tableBody) return;

    // Clear existing
    tableBody.innerHTML = '';

    // Sort mappings by Axway Filter name
    let sortedMappings = Object.entries(FILTER_MAPPINGS).sort((a, b) => a[0].localeCompare(b[0]));

    // Filter if usedFilterTypes is provided (even if empty)
    if (usedFilterTypes !== null) {
        const usedSet = new Set(usedFilterTypes);
        sortedMappings = sortedMappings.filter(([filterName, mapping]) => {
            // Check if this mapping corresponds to one of the used filter types
            // The mapping key is the filter type
            return usedSet.has(filterName);
        });

        // If no mappings match (e.g. only unsupported filters or no filters), show message
        if (sortedMappings.length === 0) {
            const row = document.createElement('tr');
            row.innerHTML = '<td colspan="4" style="text-align: center; padding: 20px;">No supported filters found in this configuration.</td>';
            tableBody.appendChild(row);
            return;
        }
    }

    sortedMappings.forEach(([filterName, mapping]) => {
        const row = document.createElement('tr');

        // Complexity class
        let complexityClass = 'complexity-low';
        if (mapping.complexity === 'Moderate') complexityClass = 'complexity-medium';
        if (mapping.complexity === 'Complex') complexityClass = 'complexity-high';

        row.innerHTML = `
            <td><code>${filterName}</code></td>
            <td><code>${mapping.apimPolicy}</code></td>
            <td><span class="complexity-badge ${complexityClass}">${mapping.complexity}</span></td>
            <td>${mapping.description}</td>
        `;
        tableBody.appendChild(row);
    });
}

/**
 * Setup event listeners
 */
function setupEventListeners() {
    // Convert button
    if (elements.convertBtn) {
        elements.convertBtn.addEventListener('click', handleConvert);
    }

    // Theme toggle
    if (elements.themeToggle) {
        elements.themeToggle.addEventListener('click', toggleTheme);
    }

    // Load Example Modal
    if (elements.loadExampleBtn) {
        elements.loadExampleBtn.addEventListener('click', () => {
            elements.exampleModal.classList.add('active');
        });
    }

    if (elements.closeModalBtn) {
        elements.closeModalBtn.addEventListener('click', () => {
            elements.exampleModal.classList.remove('active');
        });
    }

    // Close modal on outside click
    window.addEventListener('click', (e) => {
        if (e.target === elements.exampleModal) {
            elements.exampleModal.classList.remove('active');
        }
    });

    // Example cards (Event Delegation)
    const exampleGrid = document.querySelector('.example-grid');
    if (exampleGrid) {
        exampleGrid.addEventListener('click', (e) => {
            const card = e.target.closest('.example-card');
            if (card) {
                const exampleKey = card.dataset.example;
                loadExample(exampleKey);
                elements.exampleModal.classList.remove('active');
            }
        });
    }

    // File Upload
    if (elements.uploadFileBtn && elements.fileInput) {
        elements.uploadFileBtn.addEventListener('click', () => {
            elements.fileInput.click();
        });

        elements.fileInput.addEventListener('change', handleFileUpload);
    }

    // Copy & Download
    if (elements.copyPolicyBtn) {
        elements.copyPolicyBtn.addEventListener('click', handleCopyPolicy);
    }

    if (elements.downloadPolicyBtn) {
        elements.downloadPolicyBtn.addEventListener('click', handleDownloadPolicy);
    }

    // Tabs
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            switchTab(btn.dataset.tab);
        });
    });

    // Save config on change
    elements.configInput.addEventListener('input', (e) => {
        localStorage.setItem('axway-config', e.target.value);
    });
    // Rate Limit Toggle
    if (elements.includeRateLimitCheckbox) {
        elements.includeRateLimitCheckbox.addEventListener('change', (e) => {
            const enabled = e.target.checked;
            if (elements.rateLimitCallsInput) elements.rateLimitCallsInput.disabled = !enabled;
            if (elements.rateLimitPeriodInput) elements.rateLimitPeriodInput.disabled = !enabled;
            const optionsDiv = document.getElementById('rate-limit-options');
            if (optionsDiv) optionsDiv.style.opacity = enabled ? '1' : '0.5';
        });
    }
}


/**
 * Handle convert button click
 */
function handleConvert() {
    try {
        // Get input
        const configText = elements.configInput.value.trim();
        if (!configText) {
            showStatus('Please enter an Axway configuration', 'error');
            return;
        }

        // Detect input type
        const isJson = configText.trim().startsWith('{');
        // Simple heuristic for Groovy: check for common Groovy/Java keywords or if file extension was .groovy
        const isGroovy = currentInputType === 'groovy' ||
            (!isJson && (configText.includes('import com.vordel') || configText.includes('def invoke')));

        if (isJson) {
            currentInputType = 'json';
            handleJsonConversion(configText);
        } else if (isGroovy) {
            currentInputType = 'groovy';
            handleGroovyConversion(configText);
        } else {
            currentInputType = 'yaml';
            handleYamlConversion(configText);
        }
    } catch (error) {
        console.error('Conversion error:', error);
        showStatus(`Error: ${error.message}`, 'error');
        showToast('An error occurred', 'error');
    }
}

/**
 * Detect security type from Axway security profiles
 */
function detectSecurityTypeFromProfile(securityProfiles) {
    if (!securityProfiles || securityProfiles.length === 0) {
        return 'auto';
    }

    const defaultProfile = securityProfiles.find(p => p.isDefault || p.name === '_default' || p._default === true);
    if (!defaultProfile || !defaultProfile.devices || defaultProfile.devices.length === 0) {
        return 'auto';
    }

    const device = defaultProfile.devices[0];
    const deviceType = device.type?.toLowerCase();

    switch (deviceType) {
        case 'apikey':
            return 'apikey';
        case 'oauth':
        case 'oauth2':
            return 'oauth';
        case 'basic':
        case 'http_basic':
            return 'basic';
        default:
            return 'custom';
    }
}

function handleJsonConversion(configText) {
    // Parse JSON
    let config;
    try {
        config = JSON.parse(configText);
    } catch (e) {
        showStatus('Invalid JSON format. Please check your configuration.', 'error');
        return;
    }

    // Check if this is an OpenAPI specification
    const isOpenAPI = config.openapi || config.swagger;

    if (isOpenAPI) {
        showStatus('Detected OpenAPI specification. Generating template policy...', 'info');

        // For OpenAPI specs, use the simple converter with custom auth
        const options = {
            securityType: 'custom', // Force custom auth for OpenAPI specs
            includeRateLimit: elements.includeRateLimitCheckbox.checked,
            rateLimitCalls: parseInt(elements.rateLimitCallsInput.value) || 1000,
            rateLimitPeriod: parseInt(elements.rateLimitPeriodInput.value) || 60,
            includeLogging: elements.includeLoggingCheckbox.checked,
            removeCredentials: elements.removeCredentialsCheckbox.checked
        };

        const result = convertAxwayToApim(config, options);

        if (result.success) {
            currentConfig = config;
            currentResult = result;
            displayResult(result);
            showStatus('Conversion successful!', 'success');
            showToast('Policy generated successfully!', 'success');
        } else {
            showStatus(`Conversion failed: ${result.error}`, 'error');
            showToast('Conversion failed', 'error');
        }
        return;
    }

    // Check if this is an API-level configuration (Axway API export)
    const isApiLevelConfig = config.name && config.path &&
        !config.type && // Not a FilterCircuit
        (config.securityProfiles || config.corsProfiles);

    if (isApiLevelConfig) {
        showStatus('Detected Axway API configuration. Converting with Advanced Converter...', 'info');

        // Create options from UI state
        const options = {
            includeRateLimit: elements.includeRateLimitCheckbox.checked,
            rateLimitCalls: parseInt(elements.rateLimitCallsInput.value) || 1000,
            rateLimitPeriod: parseInt(elements.rateLimitPeriodInput.value) || 60,
            includeLogging: elements.includeLoggingCheckbox.checked,
            removeCredentials: elements.removeCredentialsCheckbox.checked
        };

        // Use Advanced Converter for API-level configs as it supports full profile conversion
        const result = advancedConverter.convertFilterCircuitToXml(config, options);

        currentConfig = config;
        currentResult = {
            success: true,
            policyXml: result.xml,
            securityType: 'Advanced Config',
            metadata: {
                apiName: config.name || 'Converted API',
                convertedAt: new Date().toISOString(),
                options: {
                    includeRateLimit: options.includeRateLimit,
                    includeLogging: options.includeLogging
                }
            },
            statistics: result.statistics
        };

        displayResult(currentResult);
        showStatus('Conversion successful!', 'success');
        showToast('Policy generated successfully!', 'success');
        return;
    }

    // Check for advanced configuration features (Quotas, Profiles, Filters)
    const isAdvancedConfig = config.filters ||
        config.applicationQuota ||
        config.systemQuota ||
        config.inboundProfiles ||
        config.outboundProfiles ||
        config.securityProfiles;

    if (isAdvancedConfig) {
        showStatus('Detected advanced Axway configuration. Converting...', 'info');
        const result = advancedConverter.convertFilterCircuitToXml(config);

        currentConfig = config;
        currentResult = {
            success: true,
            policyXml: result.xml,
            securityType: 'Advanced Config',
            metadata: {
                apiName: config.name || 'Converted API',
                convertedAt: new Date().toISOString(),
                options: {
                    includeRateLimit: true,
                    includeLogging: true
                }
            },
            statistics: result.statistics
        };

        displayResult(currentResult);
        showStatus('Conversion successful!', 'success');
        showToast('Advanced policy generated!', 'success');
        return;
    }

    // Fallback to simple converter for basic configs
    // Get options
    const options = {
        securityType: 'auto',
        includeRateLimit: elements.includeRateLimitCheckbox.checked,
        rateLimitCalls: parseInt(elements.rateLimitCallsInput.value) || 1000,
        rateLimitPeriod: parseInt(elements.rateLimitPeriodInput.value) || 60,
        includeLogging: elements.includeLoggingCheckbox.checked,
        removeCredentials: elements.removeCredentialsCheckbox.checked
    };

    // Convert
    showStatus('Converting configuration...', 'info');
    const result = convertAxwayToApim(config, options);

    if (result.success) {
        currentConfig = config; // Store original config for comparison
        currentResult = result;
        displayResult(result);
        showStatus('Conversion successful!', 'success');
        showToast('Policy generated successfully!', 'success');
    } else {
        showStatus(`Conversion failed: ${result.error}`, 'error');
        showToast('Conversion failed', 'error');
    }
}


function handleYamlConversion(configText) {
    showStatus('Converting FilterCircuit YAML...', 'info');

    const result = advancedConverter.convertYamlToXml(configText);

    if (result.success) {
        currentConfig = configText; // Store original YAML

        // Normalize result to match expected structure
        currentResult = {
            success: true,
            policyXml: result.xml,
            securityType: 'FilterCircuit',
            metadata: {
                apiName: result.policyName,
                convertedAt: new Date().toISOString(),
                options: {
                    includeRateLimit: true, // Assumed included in YAML
                    includeLogging: true    // Assumed included in YAML
                }
            },
            statistics: result.statistics
        };

        displayResult(currentResult);
        showStatus('Conversion successful!', 'success');
        showToast('Policy generated successfully!', 'success');
    } else {
        showStatus(`Conversion failed: ${result.error}`, 'error');
        showToast('Conversion failed', 'error');
    }
}

function handleGroovyConversion(configText) {
    showStatus('Converting Groovy Script...', 'info');

    const result = advancedConverter.convertGroovyToXml(configText);

    if (result.success) {
        currentConfig = configText; // Store original Groovy script

        // Normalize result
        currentResult = {
            success: true,
            policyXml: result.xml,
            securityType: 'GroovyScript',
            metadata: {
                apiName: result.policyName,
                convertedAt: new Date().toISOString(),
                options: {
                    includeRateLimit: false,
                    includeLogging: false
                }
            },
            statistics: result.statistics
        };

        displayResult(currentResult);
        showStatus('Conversion successful (Placeholder generated)', 'success');
        showToast('Groovy script wrapped in policy', 'success');
    } else {
        showStatus(`Conversion failed: ${result.error}`, 'error');
        showToast('Conversion failed', 'error');
    }
}

/**
 * Display conversion result
 */
function displayResult(result) {
    // Show output section
    elements.outputSection.style.display = 'block';

    // Display policy XML
    elements.policyOutput.textContent = result.policyXml;

    // Highlight syntax
    if (window.Prism) {
        Prism.highlightElement(elements.policyOutput);
    }

    // Populate comparison view
    if (currentConfig) {
        const originalConfigOutput = document.getElementById('original-config-output');
        const convertedPolicyOutput = document.getElementById('converted-policy-output');

        // Display original Axway config
        if (typeof currentConfig === 'string') {
            // YAML or raw string
            originalConfigOutput.textContent = currentConfig;
            originalConfigOutput.className = 'language-yaml';
        } else {
            // JSON object
            originalConfigOutput.textContent = JSON.stringify(currentConfig, null, 2);
            originalConfigOutput.className = 'language-json';
        }

        // Update language class based on input type
        if (currentInputType === 'groovy') {
            originalConfigOutput.className = 'language-java'; // Prism uses java for groovy-like syntax often
        } else if (currentInputType === 'yaml') {
            originalConfigOutput.className = 'language-yaml';
        }

        // Update label
        const configTypeLabel = document.getElementById('original-config-type');
        if (configTypeLabel) {
            configTypeLabel.textContent = currentInputType.toUpperCase();
        }

        // Display converted APIM policy
        convertedPolicyOutput.textContent = result.policyXml;

        // Apply syntax highlighting
        if (window.Prism) {
            Prism.highlightElement(originalConfigOutput);
            Prism.highlightElement(convertedPolicyOutput);
        }
    }

    // Update metadata
    document.getElementById('meta-security-type').textContent = result.securityType.toUpperCase();
    document.getElementById('meta-api-name').textContent = result.metadata.apiName;
    document.getElementById('meta-rate-limit').textContent = result.metadata.options.includeRateLimit ? 'Enabled' : 'Disabled';
    document.getElementById('meta-logging').textContent = result.metadata.options.includeLogging ? 'Enabled' : 'Disabled';
    document.getElementById('meta-timestamp').textContent = new Date(result.metadata.convertedAt).toLocaleString();

    // Generate deployment commands
    const deploymentCommands = generateDeploymentCommands(result.metadata.apiName, result.securityType);
    const deploymentCodeBlock = document.getElementById('deployment-commands');
    deploymentCodeBlock.textContent = deploymentCommands;

    if (window.Prism) {
        Prism.highlightElement(deploymentCodeBlock);
    }

    // Scroll to output
    elements.outputSection.scrollIntoView({ behavior: 'smooth', block: 'start' });

    // Update mapping table with used filters
    if (result.statistics && result.statistics.usedFilterTypes) {
        populateMappingTable(result.statistics.usedFilterTypes);
    } else {
        populateMappingTable(); // Fallback to showing all
    }
}

/**
 * Handle file upload
 */
function handleFileUpload(e) {
    const file = e.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
        try {
            const content = event.target.result;
            elements.configInput.value = content;

            // Detect type from extension
            if (file.name.endsWith('.json')) {
                currentInputType = 'json';
                // Validate JSON
                JSON.parse(content);
            } else if (file.name.endsWith('.yaml') || file.name.endsWith('.yml')) {
                currentInputType = 'yaml';
            } else if (file.name.endsWith('.groovy')) {
                currentInputType = 'groovy';
            }

            showToast(`File loaded: ${file.name}`, 'success');
        } catch (error) {
            showToast('Error reading file', 'error');
        }
    };
    reader.readAsText(file);
}

/**
 * Load example configuration
 */
function loadExample(key) {
    const example = getExample(key);
    if (example) {
        if (typeof example.config === 'string') {
            // YAML or raw string
            elements.configInput.value = example.config;
        } else {
            // JSON object
            elements.configInput.value = JSON.stringify(example.config, null, 2);
        }
        showToast(`Loaded: ${example.name}`, 'success');
    }
}

/**
 * Switch tabs
 */
function switchTab(tabName) {
    // Update tab buttons
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.classList.remove('active');
        if (btn.dataset.tab === tabName) {
            btn.classList.add('active');
        }
    });

    // Update tab content
    document.querySelectorAll('.tab-content').forEach(content => {
        content.classList.remove('active');
    });
    document.getElementById(`tab-${tabName}`).classList.add('active');
}

/**
 * Handle copy policy
 */
async function handleCopyPolicy() {
    if (!currentResult) return;

    try {
        await navigator.clipboard.writeText(currentResult.policyXml);
        showToast('Policy copied to clipboard!', 'success');
    } catch (error) {
        showToast('Failed to copy', 'error');
    }
}

/**
 * Handle download policy
 */
function handleDownloadPolicy() {
    if (!currentResult) return;

    const blob = new Blob([currentResult.policyXml], { type: 'application/xml' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'apim-policy.xml';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    showToast('Policy downloaded!', 'success');
}


/**
 * Show status message
 */
function showStatus(message, type = 'info') {
    elements.statusMessage.textContent = message;
    elements.statusMessage.className = `status-message ${type}`;
    elements.statusMessage.style.display = 'block';
}

/**
 * Show toast notification
 */
function showToast(message, type = 'success') {
    elements.toast.textContent = message;
    elements.toast.className = `toast ${type} show`;

    setTimeout(() => {
        elements.toast.classList.remove('show');
    }, 3000);
}

/**
 * Initialize theme
 */
function initializeTheme() {
    const savedTheme = localStorage.getItem('theme') || 'light';
    document.documentElement.setAttribute('data-theme', savedTheme);
    updateThemeIcon(savedTheme);
}

/**
 * Toggle theme
 */
function toggleTheme() {
    const currentTheme = document.documentElement.getAttribute('data-theme');
    const newTheme = currentTheme === 'dark' ? 'light' : 'dark';

    document.documentElement.setAttribute('data-theme', newTheme);
    localStorage.setItem('theme', newTheme);
    updateThemeIcon(newTheme);
}

/**
 * Update theme icon
 */
function updateThemeIcon(theme) {
    const icon = elements.themeToggle.querySelector('.icon');
    icon.textContent = theme === 'dark' ? '☀️' : '🌙';
}

// Initialize when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
} else {
    init();
}
