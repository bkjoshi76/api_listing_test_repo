/**
 * Example Axway configurations for testing
 */

export const examples = {
  petstore: {
    name: "Petstore API Key",
    description: "Official Swagger Petstore with custom API key authentication",
    config: {
      "name": "petstore3",
      "path": "/api/v3",
      "state": "published",
      "version": "1.0.17",
      "organization": "orga",
      "backendBasepath": "https://petstore3.swagger.io",
      "securityProfiles": [
        {
          "name": "_default",
          "isDefault": true,
          "devices": [
            {
              "name": "API Key",
              "type": "apiKey",
              "order": 1,
              "properties": {
                "apiKeyFieldName": "KeyId",
                "takeFrom": "HEADER",
                "removeCredentialsOnSuccess": true
              }
            }
          ]
        }
      ],
      "customProperties": {
        "customProperty1": "public",
        "customProperty4": "true"
      }
    }
  },

  oauth: {
    name: "OAuth 2.0 External",
    description: "External OAuth provider with JWT validation",
    config: {
      "name": "orders-api",
      "path": "/orders/v1",
      "state": "published",
      "version": "v1",
      "organization": "Production",
      "backendBasepath": "https://backend.example.com/api/orders",
      "securityProfiles": [
        {
          "name": "_default",
          "isDefault": true,
          "devices": [
            {
              "name": "OAuth 2.0 Authentication",
              "type": "oauthExternal",
              "order": 1,
              "properties": {
                "providerProfile": "azure-ad-provider",
                "tokenStore": "azure-ad-tokens",
                "scopes": "orders.read orders.write",
                "audience": "api://orders-api",
                "removeCredentialsOnSuccess": false
              }
            }
          ]
        }
      ],
      "customProperties": {
        "environment": "production",
        "team": "order-processing",
        "security-level": "high"
      }
    }
  },

  basic: {
    name: "HTTP Basic Auth",
    description: "Simple username/password authentication",
    config: {
      "name": "internal-api",
      "path": "/internal/v1",
      "state": "published",
      "version": "1.0",
      "organization": "Internal",
      "backendBasepath": "https://internal.example.com/api",
      "securityProfiles": [
        {
          "name": "_default",
          "isDefault": true,
          "devices": [
            {
              "name": "HTTP Basic Authentication",
              "type": "httpBasic",
              "order": 1,
              "properties": {
                "realm": "Internal API Access",
                "removeCredentialsOnSuccess": true
              }
            }
          ]
        }
      ]
    }
  },

  passthrough: {
    name: "Passthrough (No Auth)",
    description: "Public API with no authentication",
    config: {
      "name": "public-api",
      "path": "/public/v1",
      "state": "published",
      "version": "1.0",
      "organization": "Public",
      "backendBasepath": "https://public.example.com/api",
      "securityProfiles": [
        {
          "name": "_default",
          "isDefault": true,
          "devices": [
            {
              "name": "No Authentication",
              "type": "passthrough",
              "order": 1,
              "properties": {}
            }
          ]
        }
      ]
    }
  },

  simpleApiKey: {
    name: "Simple API Key",
    description: "Minimal API key configuration",
    config: {
      "name": "API-Key secured API",
      "path": "/api/v1/apikey",
      "state": "unpublished",
      "version": "1.0.0",
      "organization": "API Development",
      "securityProfiles": [
        {
          "name": "_default",
          "isDefault": true,
          "devices": [
            {
              "name": "API Key",
              "type": "apiKey",
              "order": 0,
              "properties": {
                "apiKeyFieldName": "KeyId",
                "takeFrom": "HEADER",
                "removeCredentialsOnSuccess": "true"
              }
            }
          ]
        }
      ]
    }
  },

  customerApi: {
    name: "Customer API (Advanced)",
    description: "Full-featured customer API with CORS and quotas",
    config: {
      "name": "customer-api",
      "path": "/customers/v1",
      "state": "published",
      "version": "v1",
      "organization": "Production",
      "backendBasepath": "https://backend.example.com/api/customers",
      "descriptionManual": "Customer Management API - Provides CRUD operations for customer data",
      "summary": "Customer API with API Key authentication",
      "securityProfiles": [
        {
          "_default": true,
          "devices": [
            {
              "name": "API Key Authentication",
              "type": "apiKey",
              "order": 1,
              "properties": {
                "apiKeyFieldName": "X-API-Key",
                "takeFrom": "HEADER",
                "removeCredentialsOnSuccess": true
              }
            }
          ]
        }
      ],
      "customProperties": {
        "environment": "production",
        "team": "customer-services",
        "costCenter": "CC-1234",
        "compliance": "PCI-DSS"
      }
    }
  },

  oauthInternal: {
    name: "OAuth 2.0 Internal",
    description: "Internal OAuth with token store",
    config: {
      "name": "OAuth secured API",
      "path": "/api/v1/oauth",
      "state": "published",
      "version": "1.0.0",
      "organization": "API Development",
      "securityProfiles": [
        {
          "name": "_default",
          "isDefault": true,
          "devices": [
            {
              "type": "oauth",
              "name": "OAuth",
              "order": 1,
              "properties": {
                "tokenStore": "OAuth Access Token Store",
                "accessTokenLocation": "HEADER",
                "authorizationHeaderPrefix": "Bearer",
                "scopesMustMatch": "Any",
                "scopes": "resource.WRITE, resource.READ",
                "removeCredentialsOnSuccess": true,
                "implicitGrantEnabled": true,
                "authCodeGrantTypeEnabled": true
              }
            }
          ]
        }
      ]
    }
  },

  customPolicy: {
    name: "Custom Auth Policy",
    description: "Custom authentication policy invocation",
    config: {
      "name": "Custom Policy secured API",
      "path": "/api/v1/custom-policy",
      "state": "published",
      "version": "1.0.0",
      "organization": "API Development",
      "securityProfiles": [
        {
          "name": "_default",
          "isDefault": true,
          "devices": [
            {
              "type": "authPolicy",
              "name": "Invoke Policy",
              "order": 1,
              "properties": {
                "authenticationPolicy": "Custom authentication policy",
                "useClientRegistry": true,
                "subjectSelector": "authentication.subject.id"
              }
            }
          ]
        }
      ]
    }
  },

  // YAML Examples (Advanced FilterCircuit)
  healthCheck: {
    name: "Health Check Policy (YAML)",
    description: "Simple health check and monitoring circuit",
    config: `name: Health Check Policy
description: Simple health check and monitoring circuit
filters:
  - name: BasicHealthAuth
    type: HTTPBasicFilter
    username: "healthcheck"
    password: "{{health-password}}"
  - name: HealthRateLimit
    type: ThrottlingFilter
    maxRequests: 1000
    timeWindow: 60
  - name: HealthBackend
    type: ConnectToURLFilter
    url: "https://health.enterprise.com/status"
    timeout: 5
  - name: HealthMetrics
    type: MetricsFilter
    metricName: "health_check_count"
    metricValue: "1"
    metricDimensions:
      service: "enterprise-api"
      environment: "production"
routing:
  default: HealthBackend
security:
  authentication: BasicHealthAuth
performance:
  rateLimit: HealthRateLimit
monitoring:
  metrics: HealthMetrics`
  },

  oauthSecurity: {
    name: "OAuth Security Policy (YAML)",
    description: "Enterprise OAuth 2.0 security with JWT validation",
    config: `name: OAuth Security Policy
description: Enterprise OAuth 2.0 security with JWT validation
filters:
  - name: OAuthValidation
    type: OAuth2Filter
    tokenEndpoint: "https://oauth.enterprise.com/token"
    clientId: "enterprise-api-client"
    clientSecret: "{{oauth-client-secret}}"
    scope: "api.read api.write"
  - name: SecurityRateLimit
    type: ThrottlingFilter
    maxRequests: 5000
    timeWindow: 60
  - name: SecureBackend
    type: ConnectToURLFilter
    url: "https://api.enterprise.com"
    timeout: 30
  - name: SecurityMetrics
    type: MetricsFilter
    metricName: "oauth_requests"
    metricValue: "1"
  - name: SecurityMonitoring
    type: MonitoringFilter
    logLevel: "INFO"
    includeHeaders: true
    includeBody: false
routing:
  default: SecureBackend
security:
  oauth: OAuthValidation
  rateLimit: SecurityRateLimit
monitoring:
  metrics: SecurityMetrics
  logging: SecurityMonitoring`
  },

  xmlThreat: {
    name: "XML Threat Protection (YAML)",
    description: "XML threat protection and validation",
    config: `name: XML Threat Policy
description: XML threat protection and validation
filters:
  - name: XMLThreatCheck
    type: XMLThreatProtectionFilter
    maxDepth: 10
    maxNodeCount: 1000
    maxAttributeCount: 50
    maxNamespaceCount: 10
    detectExternalEntities: true
  - name: XMLRateLimit
    type: ThrottlingFilter
    maxRequests: 2000
    timeWindow: 60
  - name: XMLBackend
    type: ConnectToURLFilter
    url: "https://xml.enterprise.com/api"
    timeout: 15
  - name: XMLMetrics
    type: MetricsFilter
    metricName: "xml_processing_count"
    metricValue: "1"
  - name: XMLCache
    type: ResponseCacheFilter
    cacheDuration: 300
    cacheKey: "xml-response"
    varyByHeaders: ["Content-Type"]
routing:
  default: XMLBackend
security:
  threatProtection: XMLThreatCheck
  rateLimit: XMLRateLimit
performance:
  caching: XMLCache
monitoring:
  metrics: XMLMetrics`
  },

  contentTransformation: {
    name: "Content Transformation (YAML)",
    description: "Complex content transformation and validation",
    config: `name: Content Transformation Policy
description: Enterprise content transformation and validation circuit
filters:
  - name: JSONToXMLTransform
    type: JSONTransformFilter
    rootElement: "Request"
    namespaceUri: "http://enterprise.com/api/v1"
    arrayDetection: true
  - name: XSLTransformation
    type: XSLTransformFilter
    xslContent: |
      <?xml version="1.0" encoding="UTF-8"?>
      <xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
        <xsl:template match="/">
          <EnterpriseRequest>
            <Header>
              <Timestamp><xsl:value-of select="current-dateTime()"/></Timestamp>
              <Source>APIM Gateway</Source>
            </Header>
            <Body>
              <xsl:copy-of select="*"/>
            </Body>
          </EnterpriseRequest>
        </xsl:template>
      </xsl:stylesheet>
    parameters:
      source: "API_GATEWAY"
      version: "1.0"
  - name: XMLToJSONTransform
    type: XMLToJSONFilter
    namespaceHandling: "ignore"
    arrayDetection: "auto"
    rootElement: "Response"
  - name: ContentModification
    type: ContentModifyFilter
    content: |
      {
        "apiVersion": "v1",
        "timestamp": "@(DateTime.Now)",
        "originalContent": @(context.Request.Body.As<string>()),
        "metadata": {
          "source": "enterprise-gateway",
          "transformed": true
        }
      }
    contentType: "application/json"
  - name: JSONThreatProtection
    type: JSONThreatProtectionFilter
    maxDepth: 8
    maxArrayElements: 1000
    maxObjectProperties: 200
    maxStringLength: 5000
  - name: CompressionFilter
    type: CompressionFilter
    compressionLevel: 6
    compressionTypes: ["application/json", "application/xml", "text/xml"]
  - name: LoadBalancedBackend
    type: LoadBalancingFilter
    algorithm: "round_robin"
    healthCheck: "/health"
    servers:
      - url: "https://api1.enterprise.com"
        weight: 50
      - url: "https://api2.enterprise.com" 
        weight: 30
      - url: "https://api3.enterprise.com"
        weight: 20
  - name: FailoverRetry
    type: FailoverFilter
    retryCount: 3
    retryInterval: 1000
    backoffMultiplier: 2
    maxInterval: 10000
transformation:
  request: [JSONToXMLTransform, XSLTransformation]
  response: [XMLToJSONTransform, ContentModification]
security:
  threatProtection: JSONThreatProtection
optimization:
  compression: CompressionFilter
backend:
  loadBalancing: LoadBalancedBackend
  failover: FailoverRetry
performance:
  cacheHeaders: true
  compressionEnabled: true
  keepAlive: true`
  }
};

/**
 * Get example by key
 */
export function getExample(key) {
  return examples[key] || null;
}

/**
 * Get all example keys
 */
export function getExampleKeys() {
  return Object.keys(examples);
}
