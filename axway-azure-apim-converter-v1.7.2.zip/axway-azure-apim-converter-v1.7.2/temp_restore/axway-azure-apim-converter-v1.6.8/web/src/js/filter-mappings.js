// Filter Mappings for Axway to Azure APIM Conversion
// Ported from Python filter_mappings.py

export const PolicySection = {
    INBOUND: 'inbound',
    BACKEND: 'backend',
    OUTBOUND: 'outbound',
    ON_ERROR: 'on-error'
};

export const FilterComplexity = {
    SIMPLE: 'Simple',
    MODERATE: 'Moderate',
    COMPLEX: 'Complex',
    CUSTOM: 'Custom'
};

export const FILTER_MAPPINGS = {
    // Authentication & Identity Filters
    'HTTPBasicFilter': {
        apimPolicy: 'authentication-basic',
        complexity: FilterComplexity.SIMPLE,
        section: PolicySection.INBOUND,
        description: 'HTTP Basic Authentication',
        configMapping: {
            username: 'username',
            password: 'password',
            realm: 'realm'
        }
    },

    'OAuth2Filter': {
        apimPolicy: 'validate-jwt',
        complexity: FilterComplexity.MODERATE,
        section: PolicySection.INBOUND,
        description: 'OAuth 2.0 Token Validation',
        configMapping: {
            tokenEndpoint: 'issuer-signing-keys',
            clientId: 'audiences',
            clientSecret: '{{oauth-client-secret}}',
            scope: 'required-claims'
        }
    },

    'JWTFilter': {
        apimPolicy: 'validate-jwt',
        complexity: FilterComplexity.MODERATE,
        section: PolicySection.INBOUND,
        description: 'JWT Token Validation',
        configMapping: {
            signingKey: 'issuer-signing-keys',
            issuer: 'issuers',
            audience: 'audiences',
            claims: 'required-claims'
        }
    },

    // Security & Protection Filters
    'XMLThreatProtectionFilter': {
        apimPolicy: 'xml-threat-detection',
        complexity: FilterComplexity.COMPLEX,
        section: PolicySection.INBOUND,
        description: 'XML Threat Protection',
        configMapping: {
            maxDepth: 'maximum-depth',
            maxNodeCount: 'maximum-node-count',
            maxAttributeCount: 'maximum-attribute-count',
            maxNamespaceCount: 'maximum-namespace-count',
            detectExternalEntities: 'enable-external-entity-detection'
        }
    },

    'JSONThreatProtectionFilter': {
        apimPolicy: 'json-threat-detection',
        complexity: FilterComplexity.COMPLEX,
        section: PolicySection.INBOUND,
        description: 'JSON Threat Protection',
        configMapping: {
            maxDepth: 'maximum-depth',
            maxArrayElements: 'maximum-array-elements',
            maxObjectProperties: 'maximum-object-properties',
            maxStringLength: 'maximum-string-length'
        }
    },

    'IPWhitelistFilter': {
        apimPolicy: 'ip-filter',
        complexity: FilterComplexity.SIMPLE,
        section: PolicySection.INBOUND,
        description: 'IP Address Whitelist',
        configMapping: {
            allowedIPs: 'address-range',
            action: 'allow'
        }
    },

    'IPBlacklistFilter': {
        apimPolicy: 'ip-filter',
        complexity: FilterComplexity.SIMPLE,
        section: PolicySection.INBOUND,
        description: 'IP Address Blacklist',
        configMapping: {
            blockedIPs: 'address-range',
            action: 'forbid'
        }
    },

    // Rate Limiting & Throttling Filters
    'ThrottlingFilter': {
        apimPolicy: 'rate-limit',
        complexity: FilterComplexity.SIMPLE,
        section: PolicySection.INBOUND,
        description: 'Request Rate Limiting',
        configMapping: {
            maxRequests: 'calls',
            timeWindow: 'renewal-period',
            keyExpression: 'counter-key'
        }
    },

    'ConcurrencyFilter': {
        apimPolicy: 'concurrency-limit',
        complexity: FilterComplexity.MODERATE,
        section: PolicySection.INBOUND,
        description: 'Concurrent Request Limiting',
        configMapping: {
            maxConcurrentRequests: 'max-concurrency',
            queueLength: 'queue-length'
        }
    },

    'QuotaFilter': {
        apimPolicy: 'quota',
        complexity: FilterComplexity.SIMPLE,
        section: PolicySection.INBOUND,
        description: 'API Usage Quota',
        configMapping: {
            quotaLimit: 'calls',
            quotaPeriod: 'renewal-period',
            quotaCounter: 'counter-key'
        }
    },

    // Content Transformation Filters
    'XSLTransformFilter': {
        apimPolicy: 'xsl-transform',
        complexity: FilterComplexity.MODERATE,
        section: PolicySection.INBOUND,
        description: 'XSL Transformation',
        configMapping: {
            xslContent: 'xsl-content',
            xslTemplate: 'template',
            parameters: 'parameters'
        }
    },

    'JSONTransformFilter': {
        apimPolicy: 'json-to-xml',
        complexity: FilterComplexity.MODERATE,
        section: PolicySection.INBOUND,
        description: 'JSON to XML Transformation',
        configMapping: {
            rootElement: 'root-element-name',
            namespaceUri: 'namespace-uri'
        }
    },

    'XMLToJSONFilter': {
        apimPolicy: 'xml-to-json',
        complexity: FilterComplexity.MODERATE,
        section: PolicySection.INBOUND,
        description: 'XML to JSON Transformation',
        configMapping: {
            namespaceHandling: 'namespace-handling',
            arrayDetection: 'array-detection'
        }
    },

    'ContentModifyFilter': {
        apimPolicy: 'set-body',
        complexity: FilterComplexity.SIMPLE,
        section: PolicySection.INBOUND,
        description: 'Content Body Modification',
        configMapping: {
            content: 'template',
            contentType: 'content-type'
        }
    },

    'SetAttributeFilter': {
        apimPolicy: 'set-variable',
        complexity: FilterComplexity.SIMPLE,
        section: PolicySection.INBOUND,
        description: 'Set Context Variable',
        configMapping: {
            messageAttribute: 'name',
            attributeValue: 'value'
        }
    },

    'Reflector': {
        apimPolicy: 'return-response',
        complexity: FilterComplexity.SIMPLE,
        section: PolicySection.INBOUND, // Can be used in inbound to return early
        description: 'Return Response',
        configMapping: {
            httpResponseStatus: 'status-code'
        }
    },

    'TraceFilter': {
        apimPolicy: 'trace',
        complexity: FilterComplexity.SIMPLE,
        section: PolicySection.INBOUND,
        description: 'Trace Message',
        configMapping: {
            traceMsg: 'message'
        }
    },

    'AuthenticateAPIKeyFilter': {
        apimPolicy: 'check-header', // Simplified mapping
        complexity: FilterComplexity.MODERATE,
        section: PolicySection.INBOUND,
        description: 'Validate API Key',
        configMapping: {
            apiKeyName: 'name',
            apiKeyHTTPLocation: 'failed-check-httpcode' // Not direct map, handled in logic
        }
    },

    'CompareAttributeFilter': {
        apimPolicy: 'choose',
        complexity: FilterComplexity.COMPLEX,
        section: PolicySection.INBOUND,
        description: 'Conditional Logic',
        configMapping: {
            // Complex mapping handled in converter
        }
    },

    'ExceptionFilter': {
        apimPolicy: 'return-response',
        complexity: FilterComplexity.SIMPLE,
        section: PolicySection.ON_ERROR,
        description: 'Exception Handling',
        configMapping: {
            // Usually sets a 500 or custom error
        }
    },

    'SslFilter': {
        apimPolicy: 'validate-client-certificate',
        complexity: FilterComplexity.COMPLEX,
        section: PolicySection.INBOUND,
        description: 'SSL/TLS Certificate Validation',
        configMapping: {
            // Config handled in logic
        }
    },

    'ExtractCertAttributesFilter': {
        apimPolicy: 'set-header',
        complexity: FilterComplexity.SIMPLE,
        section: PolicySection.INBOUND,
        description: 'Extract Certificate Attributes',
        configMapping: {
            // Config handled in logic
        }
    },

    'JavaScriptFilter': {
        apimPolicy: 'set-variable', // Or comment/trace depending on content
        complexity: FilterComplexity.COMPLEX,
        section: PolicySection.INBOUND,
        description: 'Custom Script Logic',
        configMapping: {
            engineName: 'engine-name',
            script: 'script'
        }
    },

    'AttributeExtractHTTPHeaderFilter': {
        apimPolicy: 'set-variable',
        complexity: FilterComplexity.SIMPLE,
        section: PolicySection.INBOUND,
        description: 'Extract HTTP Header',
        configMapping: {
            headerName: 'header-name',
            attributeName: 'variable-name'
        }
    },

    'PortalApiaccessReadFilter': {
        apimPolicy: 'rate-limit', // Mapping to rate-limit as per Python script
        complexity: FilterComplexity.COMPLEX,
        section: PolicySection.INBOUND,
        description: 'Portal API Access',
        configMapping: {
            // Fixed values in logic
        }
    },

    'PortalApplicationReadFilter': {
        apimPolicy: 'check-header',
        complexity: FilterComplexity.COMPLEX,
        section: PolicySection.INBOUND,
        description: 'Portal Application Validation',
        configMapping: {
            // Fixed values in logic
        }
    },

    // Routing & Backend Filters
    'ConnectToURLFilter': {
        apimPolicy: 'set-backend-service',
        complexity: FilterComplexity.SIMPLE,
        section: PolicySection.BACKEND,
        description: 'Backend Service Connection',
        configMapping: {
            url: 'base-url',
            timeout: 'timeout',
            connectionTimeout: 'connection-timeout'
        }
    },

    'LoadBalancingFilter': {
        apimPolicy: 'set-backend-service',
        complexity: FilterComplexity.MODERATE,
        section: PolicySection.BACKEND,
        description: 'Load Balancing',
        configMapping: {
            algorithm: '{{lb-algorithm}}',
            healthCheck: '{{health-check-url}}',
            servers: '{{backend-servers}}'
        }
    },

    'FailoverFilter': {
        apimPolicy: 'retry',
        complexity: FilterComplexity.MODERATE,
        section: PolicySection.BACKEND,
        description: 'Failover and Retry Logic',
        configMapping: {
            retryCount: 'count',
            retryInterval: 'interval',
            backoffMultiplier: 'delta'
        }
    },

    // Monitoring & Analytics Filters
    'MonitoringFilter': {
        apimPolicy: 'log-to-eventhub',
        complexity: FilterComplexity.SIMPLE,
        section: PolicySection.OUTBOUND,
        description: 'Request/Response Monitoring',
        configMapping: {
            logLevel: 'logger-id',
            includeHeaders: '{{include-headers}}',
            includeBody: '{{include-body}}'
        }
    },

    'MetricsFilter': {
        apimPolicy: 'emit-metric',
        complexity: FilterComplexity.SIMPLE,
        section: PolicySection.OUTBOUND,
        description: 'Custom Metrics Collection',
        configMapping: {
            metricName: 'name',
            metricValue: 'value',
            metricDimensions: 'dimensions'
        }
    },

    // Response Processing Filters
    'ResponseCacheFilter': {
        apimPolicy: 'cache-lookup-value',
        complexity: FilterComplexity.SIMPLE,
        section: PolicySection.INBOUND,
        description: 'Response Caching',
        configMapping: {
            cacheDuration: 'duration',
            cacheKey: 'key',
            varyByHeaders: 'vary-by'
        }
    },

    'CompressionFilter': {
        apimPolicy: 'compression',
        complexity: FilterComplexity.SIMPLE,
        section: PolicySection.OUTBOUND,
        description: 'Response Compression',
        configMapping: {
            compressionLevel: 'level',
            compressionTypes: 'content-types'
        }
    }
};

export function getFilterMapping(filterType) {
    return FILTER_MAPPINGS[filterType] || null;
}

export function getSupportedFilters() {
    return Object.keys(FILTER_MAPPINGS);
}
