
import { AxwayToApimConverter } from './src/js/axway-converter.js';

const input = {
    "name": "public-api",
    "path": "/public/v1",
    "state": "published",
    "version": "1.0",
    "organization": "Public",
    "backendBasepath": "https://public.example.com/api",
    "securityProfiles": [
        {
            "name": "_default",
            "isDefault": true,
            "devices": [
                {
                    "name": "No Authentication",
                    "type": "passthrough",
                    "order": 1,
                    "properties": {}
                }
            ]
        }
    ]
};

const converter = new AxwayToApimConverter();
const result = converter.convertFilterCircuitToXml(input);

console.log(result.xml);

if (result.xml.includes('<!-- Passthrough authentication - No policy required -->')) {
    console.log('SUCCESS: Passthrough policy found.');
} else {
    console.log('FAILURE: Passthrough policy NOT found.');
}
