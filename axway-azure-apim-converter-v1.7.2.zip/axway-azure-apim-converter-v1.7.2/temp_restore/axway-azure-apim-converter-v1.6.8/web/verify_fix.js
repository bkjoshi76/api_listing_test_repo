import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { AxwayToApimConverter } from './src/js/axway-converter.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const yamlPath = path.join(__dirname, '../repro_fail.yaml');

try {
    console.log(`Reading YAML from ${yamlPath}...`);
    const yamlContent = fs.readFileSync(yamlPath, 'utf8');

    console.log('Initializing converter...');
    const converter = new AxwayToApimConverter();

    console.log('Converting YAML...');
    const result = converter.convertYamlToXml(yamlContent);

    if (result.success) {
        console.log('SUCCESS: Conversion successful!');
        console.log('Policy Name:', result.policyName);
        console.log('Statistics:', JSON.stringify(result.statistics, null, 2));
        // console.log('XML Output:', result.xml);
    } else {
        console.error('FAILURE: Conversion failed.');
        console.error('Error:', result.error);
        process.exit(1);
    }
} catch (error) {
    console.error('An unexpected error occurred:', error);
    process.exit(1);
}
