
import fs from 'fs';
import path from 'path';
import { AxwayToApimConverter } from './src/js/axway-converter.js';

const converter = new AxwayToApimConverter();
const testFile = path.resolve('quota_test.json');

try {
    const jsonContent = fs.readFileSync(testFile, 'utf8');
    const result = converter.convertYamlToXml(jsonContent);

    if (result.success) {
        console.log('SUCCESS: Quota conversion successful!');
        console.log('XML Output:');
        console.log(result.xml);

        // Basic validation
        if (result.xml.includes('<quota renewal-period="3600" calls="3000"/>') &&
            result.xml.includes('<quota renewal-period="86400" bandwidth="51200"/>')) {
            console.log('VERIFICATION PASSED: Expected quota policies found.');
        } else {
            console.error('VERIFICATION FAILED: Expected quota policies NOT found.');
            process.exit(1);
        }
    } else {
        console.error('FAILURE: Conversion failed:', result.error);
        process.exit(1);
    }
} catch (error) {
    console.error('ERROR:', error.message);
    process.exit(1);
}
