import { AxwayToApimConverter } from './src/js/axway-converter.js';

const converter = new AxwayToApimConverter();

const config = {
    name: "Test API",
    securityProfiles: [{
        name: "_default",
        isDefault: true,
        devices: [{ type: "apiKey" }]
    }]
};

const options = {
    includeRateLimit: true,
    rateLimitCalls: 500,
    rateLimitPeriod: 30
};

console.log("Testing configurable rate limit...");
const result = converter.convertFilterCircuitToXml(config, options);

if (result.xml.includes('<rate-limit calls="500" renewal-period="30"/>')) {
    console.log("SUCCESS: Custom rate limit found.");
} else {
    console.error("FAILURE: Custom rate limit NOT found.");
    console.log("Generated XML:", result.xml);
    process.exit(1);
}
