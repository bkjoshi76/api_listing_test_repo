
import fs from 'fs';
import { AxwayToApimConverter } from './src/js/axway-converter.js';

const config = JSON.parse(fs.readFileSync('../test_config.json', 'utf8'));
const converter = new AxwayToApimConverter();
const result = converter.convertFilterCircuitToXml(config);

console.log(result.xml);
