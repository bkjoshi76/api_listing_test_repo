import fs from 'fs';
import { AxwayToApimConverter } from './src/js/axway-converter.js';

const converter = new AxwayToApimConverter();

// Read test file
const configContent = fs.readFileSync('../httpbasic_test.json', 'utf8');
const config = JSON.parse(configContent);

// Convert
const result = converter.convertFilterCircuitToXml(config);

// Write output
fs.writeFileSync('../httpbasic_output.xml', result.xml);
console.log('HTTP Basic Auth conversion complete. Output written to ../httpbasic_output.xml');
console.log('\n--- Generated Policy ---');
console.log(result.xml);
