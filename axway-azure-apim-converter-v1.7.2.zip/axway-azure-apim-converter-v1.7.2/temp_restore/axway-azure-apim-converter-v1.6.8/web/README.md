# 🚀 Axway to Azure APIM Conversion Tool - Web Application

A modern, browser-based tool for converting Axway API Gateway configurations to Azure API Management policies.

## ✨ Features

- **🎨 Beautiful UI** - Premium design with dark mode support and glassmorphism effects
- **⚡ Client-Side Conversion** - No backend required, all processing happens in your browser
- **📝 Multiple Security Types** - Support for API Key, OAuth 2.0, Basic Auth, AWS Signature, and more
- **📚 Pre-loaded Examples** - Quick testing with Petstore, OAuth, and other example configurations
- **💾 File Upload** - Upload your Axway JSON configuration files
- **📥 Download Policies** - Export generated Azure APIM policy XML files
- **🔍 Syntax Highlighting** - Beautiful code display with Prism.js
- **📱 Responsive Design** - Works on desktop, tablet, and mobile devices

## 🚀 Quick Start

### Local Development

```bash
# Navigate to web-app directory
cd web-app

# Install dependencies
npm install

# Start development server
npm run dev
```

The application will be available at `http://localhost:5173`

### Build for Production

```bash
# Create production build
npm run build

# Preview production build
npm run preview
```

The built files will be in the `dist` directory.

## 🌐 Deploying to Azure

### Option 1: Azure Static Web Apps (Recommended)

Azure Static Web Apps is perfect for this application since it's entirely client-side.

#### Using Azure CLI

```bash
# Login to Azure
az login

# Create a resource group
az group create --name axway-migration-rg --location eastus

# Create static web app
az staticwebapp create \
  --name axway-migration-toolkit \
  --resource-group axway-migration-rg \
  --source ./dist \
  --location eastus2 \
  --branch main \
  --app-location "/" \
  --output-location "dist"
```

#### Using GitHub Actions

1. Fork or push this repository to GitHub
2. Create an Azure Static Web App in the Azure Portal
3. Connect it to your GitHub repository
4. Azure will automatically create a GitHub Actions workflow
5. Every push to main will trigger a deployment

The workflow file is already included at `.github/workflows/azure-static-web-apps.yml`

### Option 2: Azure App Service

```bash
# Create App Service plan
az appservice plan create \
  --name axway-migration-plan \
  --resource-group axway-migration-rg \
  --sku B1 \
  --is-linux

# Create web app
az webapp create \
  --name axway-migration-app \
  --resource-group axway-migration-rg \
  --plan axway-migration-plan \
  --runtime "NODE|20-lts"

# Deploy from local git
cd dist
git init
git add .
git commit -m "Initial deployment"
az webapp deployment source config-local-git \
  --name axway-migration-app \
  --resource-group axway-migration-rg
git remote add azure <deployment-url>
git push azure main
```

### Option 3: Azure Blob Storage (Static Website)

```bash
# Create storage account
az storage account create \
  --name axwaymigration \
  --resource-group axway-migration-rg \
  --location eastus \
  --sku Standard_LRS

# Enable static website hosting
az storage blob service-properties update \
  --account-name axwaymigration \
  --static-website \
  --index-document index.html \
  --404-document index.html

# Upload files
az storage blob upload-batch \
  --account-name axwaymigration \
  --source ./dist \
  --destination '$web'
```

## 📖 Usage

### 1. Load Configuration

Choose one of these methods:

- **Upload File**: Click "Upload JSON" and select your Axway configuration file
- **Load Example**: Click "Load Example" to choose from pre-configured examples
- **Paste JSON**: Directly paste your Axway configuration into the editor

### 2. Configure Options

- **Security Type**: Auto-detect or manually select (API Key, OAuth, Basic Auth, etc.)
- **Include Rate Limiting**: Add rate limiting policies
- **Include Security Logging**: Enable authentication logging
- **Remove Credentials**: Strip auth headers before backend calls

### 3. Convert

Click "Convert to APIM Policy" to generate the Azure APIM policy XML.

### 4. Review & Download

- **Policy XML Tab**: View the generated policy
- **Metadata Tab**: See conversion details
- **Deployment Guide Tab**: Get Azure CLI commands for deployment

### 5. Deploy

- Copy the policy XML or download it
- Follow the deployment commands in the Deployment Guide tab
- Deploy to your Azure APIM instance

## 🎯 Supported Security Types

| Type | Description | Status |
|------|-------------|--------|
| **API Key** | Custom header or query parameter authentication | ✅ Complete |
| **OAuth 2.0** | JWT validation with external/internal providers | ✅ Complete |
| **HTTP Basic** | Username/password authentication | ✅ Complete |
| **AWS Signature** | AWS Signature Version 4 validation | ✅ Complete |
| **Passthrough** | No authentication (public APIs) | ✅ Complete |
| **Custom** | External authentication service integration | ✅ Complete |

## 🛠️ Technology Stack

- **Vite** - Fast build tool and dev server
- **Vanilla JavaScript** - No framework dependencies
- **CSS3** - Modern design with custom properties
- **Prism.js** - Syntax highlighting
- **Google Fonts** - Inter and JetBrains Mono

## 📁 Project Structure

```
web-app/
├── index.html              # Main HTML file
├── package.json            # NPM dependencies
├── src/
│   ├── main.js            # Application entry point
│   ├── css/
│   │   ├── design-system.css   # Design tokens and variables
│   │   └── components.css      # Component styles
│   └── js/
│       ├── converter.js        # Conversion engine
│       └── examples.js         # Example configurations
└── dist/                   # Production build (generated)
```

## 🔧 Configuration

### Custom Branding

Edit `index.html` to update:
- Application title
- Logo and branding
- Footer links

### Theme Colors

Edit `src/css/design-system.css` to customize:
- Color palette (HSL values)
- Dark mode colors
- Typography
- Spacing

## 🐛 Troubleshooting

### Build Issues

```bash
# Clear node_modules and reinstall
rm -rf node_modules package-lock.json
npm install
```

### Port Already in Use

```bash
# Use a different port
npm run dev -- --port 3000
```

### CORS Issues in Production

If deploying to Azure Blob Storage or CDN, ensure CORS is configured:

```bash
az storage cors add \
  --account-name axwaymigration \
  --services b \
  --methods GET POST OPTIONS \
  --origins "*" \
  --allowed-headers "*"
```

## 📝 License

MIT License - see the main project LICENSE file for details.

## 🤝 Contributing

Contributions are welcome! Please see the main project CONTRIBUTING.md for guidelines.

## 📧 Support

- **Issues**: [GitHub Issues](https://github.com/your-org/axway-to-azure-apim-security-migration/issues)
- **Discussions**: [GitHub Discussions](https://github.com/your-org/axway-to-azure-apim-security-migration/discussions)

---


