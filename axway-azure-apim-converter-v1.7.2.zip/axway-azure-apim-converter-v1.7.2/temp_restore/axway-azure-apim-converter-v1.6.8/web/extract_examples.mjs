import { examples } from './src/js/examples.js';
import fs from 'fs';
import path from 'path';

const outputDir = path.resolve('../tests/comparison_run');

if (!fs.existsSync(outputDir)) {
    fs.mkdirSync(outputDir, { recursive: true });
}

console.log(`Extracting examples to ${outputDir}...`);

Object.entries(examples).forEach(([key, example]) => {
    const config = example.config;
    let filename;
    let content;

    if (typeof config === 'string') {
        // Assume YAML if string
        filename = `${key}.yaml`;
        content = config;
    } else {
        // JSON object
        filename = `${key}.json`;
        content = JSON.stringify(config, null, 2);
    }

    const filePath = path.join(outputDir, filename);
    fs.writeFileSync(filePath, content);
    console.log(`Extracted: ${filename}`);
});

console.log('Extraction complete.');
