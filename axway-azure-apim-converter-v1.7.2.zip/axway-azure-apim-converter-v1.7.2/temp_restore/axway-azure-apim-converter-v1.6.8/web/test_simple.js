const { AxwayToApimConverter } = require('./web/src/js/axway-converter.js');

const testConfig = {
    "type": "FilterCircuit",
    "fields": {
        "name": "Simple Test API"
    },
    "children": [
        {
            "type": "AuthenticateAPIKeyFilter",
            "fields": {
                "name": "API Key Check",
                "apiKeyName": "X-API-Key"
            }
        }
    ]
};

console.log('Testing JavaScript Converter...');
const converter = new AxwayToApimConverter();
try {
    const xml = converter.convertFilterCircuitToXml(testConfig);
    console.log('SUCCESS: Conversion completed');
    console.log('XML Output:');
    console.log(xml);
} catch (error) {
    console.error('ERROR:', error.message);
    console.error(error.stack);
}
