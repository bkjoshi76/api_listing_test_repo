
const { AxwayToApimConverter } = require('./web/src/js/axway-converter.js');

const input = {
    "name": "customer-api",
    "path": "/customers/v1",
    "state": "published",
    "version": "v1",
    "organization": "Production",
    "backendBasepath": "https://backend.example.com/api/customers",
    "descriptionManual": "Customer Management API - Provides CRUD operations for customer data",
    "summary": "Customer API with API Key authentication",
    "securityProfiles": [
        {
            "_default": true,
            "devices": [
                {
                    "name": "API Key Authentication",
                    "type": "apiKey",
                    "order": 1,
                    "properties": {
                        "apiKeyFieldName": "X-API-Key",
                        "takeFrom": "HEADER",
                        "removeCredentialsOnSuccess": true
                    }
                }
            ]
        }
    ],
    "customProperties": {
        "environment": "production",
        "team": "customer-services",
        "costCenter": "CC-1234",
        "compliance": "PCI-DSS"
    }
};

const converter = new AxwayToApimConverter();
const result = converter.convertFilterCircuitToXml(input);

console.log(result.xml);

if (result.xml.includes('<check-header')) {
    console.log('SUCCESS: Security policy found.');
} else {
    console.log('FAILURE: Security policy NOT found.');
}
