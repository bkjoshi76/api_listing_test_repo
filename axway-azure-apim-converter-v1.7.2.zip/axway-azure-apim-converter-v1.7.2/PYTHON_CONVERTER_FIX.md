# Python Converter Fix - Manual Instructions

## Issue
The Python converter (`scripts/fully_validated_converter.py`) does not apply default security profiles when method-level inbound overrides are present.

## Root Cause
Lines 294-302 in `convert_to_apim_xml` method:

```python
# Process Method-Level Inbound Overrides
if 'inboundProfiles' in circuit_data:
    self._convert_inbound_overrides(inbound, circuit_data)
else:
    # Check for default security profile
    security_profiles = circuit_data.get('securityProfiles', [])
    default_profile = next((p for p in security_profiles if p.get('isDefault')), None)
    if default_profile:
        self._apply_security_profile(inbound, default_profile)
```

The logic only applies the default security profile when NO `inboundProfiles` exist. This means when method-level overrides are present, the global default security is skipped entirely.

## Fix Required

**Replace lines 294-302 with:**

```python
# Apply default security profile (if exists)
security_profiles = circuit_data.get('securityProfiles', [])
default_profile = next((p for p in security_profiles if p.get('isDefault') or p.get('_default')), None)
if default_profile:
    comment = ET.Comment(f" Global Security Profile: {default_profile.get('name', '_default')} ")
    inbound.append(comment)
    self._apply_security_profile(inbound, default_profile)

# Process Method-Level Inbound Overrides (these override the default)
if 'inboundProfiles' in circuit_data:
    self._convert_inbound_overrides(inbound, circuit_data)
```

## What This Does

1. **Always** checks for and applies the default security profile first (if it exists)
2. **Then** processes method-level overrides, which will override the default for specific operations
3. Adds support for `_default` property in addition to `isDefault`
4. Adds a comment to identify the global security profile in the output

## Expected Behavior After Fix

For the test case `oauth-default-apikey-on-one-method.json`:
- Global OAuth policy will be applied to ALL operations by default
- `findPetsByStatus` operation will override with API Key check
- Other operations will use the global OAuth policy

## Test Command

```bash
python scripts/fully_validated_converter.py --convert test_oauth_default_apikey_override.json
```

## Expected Output

The generated XML should include:
1. Global `<validate-jwt>` policy (for OAuth)
2. `<choose>` block with method-level override for `findPetsByStatus` (API Key)

This will achieve parity with the Web converter v1.7.0.
