---
marp: true
theme: default
paginate: true
backgroundColor: #fff
---

# Axway to Azure APIM Converter
## Technical Deep Dive & Architecture

**v1.7.1 Implementation Details**

---

# Architecture Overview

```mermaid
graph LR
    A[Axway FilterCircuit<br/>JSON/YAML] --> B{Converter Engine}
    B --> C[Python CLI<br/>fully_validated_converter.py]
    B --> D[Web Application<br/>JS Port]
    C --> E[Azure APIM<br/>Policy XML]
    D --> E
    
    style A fill:#e1f5ff
    style E fill:#d4edda
    style B fill:#fff3cd
```

- **Core Logic**: Shared logic pattern between Python and JS.
- **Validation**: Strict schema compliance for generated XML.
- **Extensibility**: Modular filter mapping architecture.

---

# Implementation: The Converter Class

The heart of the solution is `fully_validated_converter.py`.

```python
class AxwayToApimConverter:
    def convert_to_apim_xml(self, axway_data):
        # 1. Parse & Normalize Input
        filters = self.parse_axway_filtercircuit(axway_data)
        
        # 2. Apply Global Policies (Order Matters!)
        self._apply_quotas(axway_data, inbound)
        self._apply_security_profile(axway_data, inbound, ...)
        self._apply_cors_profile(axway_data, inbound)
        
        # 3. Process Individual Filters
        for filter_config in filters:
            self._map_filter_to_policy(filter_config, ...)
            
        # 4. Apply Method Overrides
        self._apply_method_overrides(axway_data, inbound, ...)
```

---

# Feature: Method-Level Overrides

**Challenge**: Axway policies are often monolithic, while APIM requires operation-specific logic.

**Solution**: We implemented a `<choose>` block strategy that inspects `context.Operation.Id`.

**Code Example (Generated XML)**:
```xml
<choose>
  <!-- Method: findPetsByStatus -->
  <when condition="@(context.Operation.Id == &quot;findPetsByStatus&quot;)">
    <check-header name="KeyId" failed-check-httpcode="401" ... />
    <rate-limit-by-key calls="1000" renewal-period="60" ... />
  </when>
  
  <!-- Global Default Fallback -->
  <when condition="@(context.Operation.Id == &quot;_default&quot;)">
    <validate-jwt header-name="Authorization" ... />
  </when>
</choose>
```

---

# Feature: Complex Security Chains

**Challenge**: Axway allows mixing multiple auth types (API Key, OAuth, SSL) in complex chains.

**Solution**: The converter intelligently maps these to APIM security policies, handling:
1.  **API Key**: `check-header` + `rate-limit-by-key` + `trace`.
2.  **OAuth 2.0**: `validate-jwt` with dynamic `openid-config` URL.
3.  **SSL**: `validate-client-certificate` with revocation checks.

**Parity Achievement**:
We successfully verified a mixed scenario where a default OAuth profile is overridden by an API Key profile for a specific method, ensuring no policy duplication.

---

# Feature: Quota Management

**Challenge**: Axway supports multiple restrictions (bandwidth, messages) per quota.

**Solution**: The converter iterates through all restrictions and generates corresponding APIM `<quota>` policies.

**Input (Axway JSON)**:
```json
"restrictions": [
  { "type": "throttlemb", "config": { "mb": 128, "period": "hour" } },
  { "type": "throttle", "config": { "messages": 1500, "period": "minute" } }
]
```

**Output (APIM XML)**:
```xml
<!-- Bandwidth Quota -->
<quota renewal-period="3600" bandwidth="131072"/>
<!-- Message Count Quota -->
<quota renewal-period="60" calls="1500"/>
```

---

# Regression Testing & Quality Assurance

We maintain a strict regression suite to ensure zero regressions.

**Test Corpus**:
- `complex-complete-config.json` (1000+ lines)
- `method-level-apikey-cors.json`
- `multi-restriction-quota.json`
- ... and 10+ others.

**Verification Process**:
1.  Run Python Converter -> Generate XML.
2.  Run Web UI Converter -> Generate XML.
3.  **Compare**: Ensure byte-for-byte identity (Parity).
4.  **Validate**: Check against Azure APIM XSD.

**Current Status**: 14/14 Tests Passed (100% Success).

---

# Deployment Architecture

The solution is designed for flexibility:

1.  **Local Developer Experience**:
    - `npm run dev` for instant feedback.
    - VS Code integration for debugging.

2.  **CI/CD Pipeline (Azure DevOps)**:
    - `python scripts/fully_validated_converter.py` runs in build agent.
    - Output XML is pushed to Azure API Management via ARM/Bicep.

3.  **Azure Static Web App**:
    - Hosts the Web UI for self-service migration assessment.

---

# Conclusion

**Technical Excellence**

The v1.7.1 release represents a mature, enterprise-grade migration tool. By solving complex challenges like method overrides and mixed security profiles, we have removed the technical barriers to Azure adoption.

*Code is Law. Parity is Guaranteed.*
