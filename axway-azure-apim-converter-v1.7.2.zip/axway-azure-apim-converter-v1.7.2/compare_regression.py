
import os
import sys
from xml.dom import minidom
import difflib

def normalize_xml(xml_string):
    """Normalize XML for comparison (remove whitespace, comments, etc.)"""
    try:
        # Parse and pretty print to normalize structure
        dom = minidom.parseString(xml_string)
        # Remove empty text nodes (whitespace)
        for element in dom.getElementsByTagName("*"):
            if element.firstChild and element.firstChild.nodeType == element.TEXT_NODE and not element.firstChild.data.strip():
                element.removeChild(element.firstChild)
        
        # Remove comments
        # (Simplified: minidom doesn't easily remove comments without traversal)
        
        return '\n'.join([line.strip() for line in dom.toprettyxml(indent='  ').split('\n') if line.strip()])
    except Exception as e:
        return f"Error parsing XML: {e}"

def compare_files(file1, file2):
    if not os.path.exists(file1) or not os.path.exists(file2):
        print(f"[MISSING] {file1} or {file2}")
        return False

    with open(file1, 'r') as f1, open(file2, 'r') as f2:
        content1 = f1.read()
        content2 = f2.read()

    norm1 = normalize_xml(content1)
    norm2 = normalize_xml(content2)

    if norm1 == norm2:
        print(f"[MATCH] {os.path.basename(file1)} == {os.path.basename(file2)}")
        return True
    else:
        print(f"[DIFF] {os.path.basename(file1)} != {os.path.basename(file2)}")
        # Print diff
        diff = difflib.unified_diff(
            norm1.splitlines(), 
            norm2.splitlines(), 
            fromfile=os.path.basename(file1), 
            tofile=os.path.basename(file2), 
            lineterm=''
        )
        for line in diff:
            print(line)
        return False

def main():
    examples_dir = 'examples'
    files = [f for f in os.listdir(examples_dir) if f.endswith('.json')]
    
    success_count = 0
    total_count = 0
    
    print("Starting Regression Comparison...")
    
    for json_file in files:
        base_name = os.path.splitext(json_file)[0]
        python_xml = os.path.join(examples_dir, f"{base_name}-python.xml")
        web_xml = os.path.join(examples_dir, f"{base_name}-web.xml")
        
        total_count += 1
        if compare_files(python_xml, web_xml):
            success_count += 1
            
    print(f"\nRegression Results: {success_count}/{total_count} passed.")
    
    if success_count == total_count:
        sys.exit(0)
    else:
        sys.exit(1)

if __name__ == '__main__':
    main()
