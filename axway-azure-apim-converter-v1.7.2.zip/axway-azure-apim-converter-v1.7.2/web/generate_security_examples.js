import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { AxwayToApimConverter } from './src/js/axway-converter.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const examplesDir = path.join(__dirname, '../examples');

const files = [
    'security-apikey-config.json',
    'security-custom-policy-config.json',
    'security-oauth-config.json',
    'security-oauth-external-config.json',
    'security-outbound-apikey.json',
    'security-outbound-basic.json',
    'security-outbound-clientCert.json'
];

const converter = new AxwayToApimConverter();

files.forEach(file => {
    const configPath = path.join(examplesDir, file);
    if (fs.existsSync(configPath)) {
        console.log(`Processing ${file}...`);
        const configContent = fs.readFileSync(configPath, 'utf8');
        const config = JSON.parse(configContent);

        // Use default options (no rate limit or logging forced, to match Python default if possible)
        // However, Python script might have defaults. Let's check Python defaults.
        // Python defaults: include_rate_limit=False, include_logging=False unless specified.
        // So we should pass false here to match.
        const result = converter.convertFilterCircuitToXml(config, {
            includeRateLimit: false,
            includeLogging: false
        });

        const outputPath = path.join(examplesDir, file.replace('.json', '-web.xml'));
        fs.writeFileSync(outputPath, result.xml);
        console.log(`Saved to ${outputPath}`);
    } else {
        console.error(`File not found: ${configPath}`);
    }
});
