import { AxwayToApimConverter } from './src/js/axway-converter.js';
import { extractNamedValues } from './src/js/named-values.js';
import { examples } from './src/js/examples.js';

const converter = new AxwayToApimConverter();

console.log('Testing Named Values Extraction with All Examples\n');
console.log('='.repeat(80));

// Get all example keys
const exampleKeys = Object.keys(examples);

exampleKeys.forEach((key, index) => {
    const example = examples[key];

    console.log(`\n${index + 1}. Testing: ${example.name}`);
    console.log('-'.repeat(80));

    try {
        // Convert the example
        const result = converter.convertFilterCircuitToXml(example.config);

        // Extract named values
        const namedValues = extractNamedValues(result.xml);

        if (namedValues.length === 0) {
            console.log('   ✓ No named values required');
        } else {
            console.log(`   ✓ Found ${namedValues.length} named value(s):`);
            namedValues.forEach(nv => {
                const requiredBadge = nv.required ? '[REQUIRED]' : '[OPTIONAL]';
                console.log(`     - ${nv.name} ${requiredBadge}`);
                console.log(`       Description: ${nv.description}`);
                console.log(`       Example: ${nv.example}`);
            });
        }

        // Show a snippet of the generated XML
        const xmlLines = result.xml.split('\n');
        const inboundSection = xmlLines.slice(0, 15).join('\n');
        console.log('\n   XML Preview (first 15 lines):');
        console.log('   ' + inboundSection.split('\n').join('\n   '));

    } catch (error) {
        console.log(`   ✗ Error: ${error.message}`);
    }
});

console.log('\n' + '='.repeat(80));
console.log('Test Complete!\n');
