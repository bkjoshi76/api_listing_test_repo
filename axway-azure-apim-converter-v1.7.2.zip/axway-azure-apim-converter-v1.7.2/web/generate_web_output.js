import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { AxwayToApimConverter } from './src/js/axway-converter.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

// Load debug config
const configPath = path.join(__dirname, '../debug_complete_config.json');
const configContent = fs.readFileSync(configPath, 'utf8');
const config = JSON.parse(configContent);

// Initialize converter
const converter = new AxwayToApimConverter();

// Convert
console.log('Running Web UI conversion...');
const result = converter.convertFilterCircuitToXml(config, {
    includeRateLimit: true, // Matching Python default behavior if applicable or options used in Python script
    includeLogging: true    // Matching Python default behavior if applicable
});

const outputPath = path.join(__dirname, '../web_output.xml');
fs.writeFileSync(outputPath, result.xml);
console.log(`Web UI output saved to: ${outputPath}`);
