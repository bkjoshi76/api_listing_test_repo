import { AxwayToApimConverter } from './src/js/axway-converter.js';
import { readFileSync, writeFileSync } from 'fs';

const input = JSON.parse(readFileSync('test_method_level_input.json', 'utf-8'));

const converter = new AxwayToApimConverter();
const result = converter.convertFilterCircuitToXml(input, { includeLogging: false });

console.log('=== Web Converter Output (v1.7.0) ===\n');
console.log(result.xml);

// Save to file for comparison
writeFileSync('test_method_level_web_output.xml', result.xml);
console.log('\n✓ Saved to test_method_level_web_output.xml');
