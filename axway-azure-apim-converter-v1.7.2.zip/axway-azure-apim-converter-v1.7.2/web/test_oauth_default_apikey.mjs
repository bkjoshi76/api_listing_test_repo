import { AxwayToApimConverter } from './src/js/axway-converter.js';
import { readFileSync } from 'fs';

const input = JSON.parse(readFileSync('test_oauth_default_apikey_override.json', 'utf-8'));

const converter = new AxwayToApimConverter();
const result = converter.convertFilterCircuitToXml(input, { includeLogging: false });

console.log('=== Web Converter Output (v1.7.0) ===\n');
console.log(result.xml);

// Validation checks
const checks = [
    { name: 'Global OAuth policy', found: result.xml.includes('validate-jwt') && !result.xml.includes('<choose>') || result.xml.indexOf('validate-jwt') < result.xml.indexOf('<choose>') },
    { name: 'Choose block for overrides', found: result.xml.includes('<choose>') },
    { name: 'findPetsByStatus override', found: result.xml.includes('findPetsByStatus') },
    { name: 'API Key check in override', found: result.xml.includes('check-header name="KeyId"') },
    { name: 'OAuth JWT validation', found: result.xml.includes('validate-jwt') },
    { name: 'OAuth openid-config', found: result.xml.includes('openid-config') }
];

console.log('\n---\nValidation Results:');
checks.forEach(check => {
    console.log(`${check.found ? '✓' : '✗'} ${check.name}: ${check.found ? 'PASS' : 'FAIL'}`);
});

const allPassed = checks.every(c => c.found);
console.log(`\n${allPassed ? '✅ ALL CHECKS PASSED' : '⚠️  SOME CHECKS FAILED'}`);

// Show structure
console.log('\n---\nExpected Structure:');
console.log('1. Global OAuth policy (default for all operations)');
console.log('2. <choose> block with method-level overrides:');
console.log('   - findPetsByStatus: API Key check');
console.log('   - Other operations: Use global OAuth (no override needed)');
