/**
 * Extract named values from policy XML
 * @param {string} xml - The policy XML string
 * @returns {Array} Array of named value objects
 */
function extractNamedValues(xml) {
    const namedValues = [];
    const seen = new Set();

    // Regular expression to match {{variable-name}} patterns
    const regex = /\{\{([a-zA-Z0-9\-_]+)\}\}/g;
    let match;

    while ((match = regex.exec(xml)) !== null) {
        const varName = match[1];
        if (!seen.has(varName)) {
            seen.add(varName);

            // Determine description and example based on variable name
            const info = getNamedValueInfo(varName);
            namedValues.push({
                name: varName,
                description: info.description,
                example: info.example,
                required: info.required
            });
        }
    }

    return namedValues.sort((a, b) => a.name.localeCompare(b.name));
}

/**
 * Get information about a named value
 * @param {string} varName - The variable name
 * @returns {Object} Information about the named value
 */
function getNamedValueInfo(varName) {
    const infoMap = {
        'oauth-openid-config-url': {
            description: 'OpenID Connect discovery endpoint URL for OAuth validation',
            example: 'https://login.microsoftonline.com/{tenant-id}/v2.0/.well-known/openid-configuration',
            required: true
        },
        'oauth-audience': {
            description: 'Expected audience claim in OAuth tokens',
            example: 'api://your-api-id',
            required: true
        },
        'oauth-issuer': {
            description: 'Expected issuer claim in OAuth tokens',
            example: 'https://sts.windows.net/{tenant-id}/',
            required: true
        },
        'oauth-external-openid-config': {
            description: 'External OAuth provider OpenID configuration URL',
            example: 'https://your-oauth-provider.com/.well-known/openid-configuration',
            required: true
        },
        'oauth-external-audience': {
            description: 'Expected audience for external OAuth provider',
            example: 'your-api-audience',
            required: true
        },
        'oauth-external-issuer': {
            description: 'Expected issuer for external OAuth provider',
            example: 'https://your-oauth-provider.com',
            required: true
        },
        'http-basic-username': {
            description: 'Username for HTTP Basic authentication',
            example: 'api-user',
            required: true
        },
        'http-basic-password': {
            description: 'Password for HTTP Basic authentication (store as secret)',
            example: '********',
            required: true
        },
        'basic-auth-username': {
            description: 'Username for Basic authentication',
            example: 'backend-user',
            required: true
        },
        'basic-auth-password': {
            description: 'Password for Basic authentication (store as secret)',
            example: '********',
            required: true
        },
        'custom-auth-service-url': {
            description: 'URL of custom authentication service',
            example: 'https://auth.example.com/validate',
            required: true
        },
        'jwt-signing-key': {
            description: 'JWT signing key for token validation',
            example: 'your-base64-encoded-key',
            required: true
        },
        'password': {
            description: 'Generic password value (store as secret)',
            example: '********',
            required: true
        }
    };

    return infoMap[varName] || {
        description: 'Custom named value - configure based on your requirements',
        example: 'your-value-here',
        required: false
    };
}

/**
 * Populate named values table
 * @param {Array} namedValues - Array of named value objects
 */
function populateNamedValuesTable(namedValues) {
    const tbody = document.getElementById('named-values-table-body');
    if (!tbody) return;

    tbody.innerHTML = '';

    if (namedValues.length === 0) {
        tbody.innerHTML = '<tr><td colspan="4" style="text-align: center; padding: 2rem; color: var(--text-secondary);">No named values required for this policy</td></tr>';
        return;
    }

    namedValues.forEach(nv => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td><code>${escapeHtml(nv.name)}</code></td>
            <td>${escapeHtml(nv.description)}</td>
            <td><code>${escapeHtml(nv.example)}</code></td>
            <td><span class="badge ${nv.required ? 'badge-required' : 'badge-optional'}">${nv.required ? 'Yes' : 'No'}</span></td>
        `;
        tbody.appendChild(row);
    });
}

/**
 * Escape HTML special characters
 * @param {string} text - Text to escape
 * @returns {string} Escaped text
 */
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

export { extractNamedValues, populateNamedValuesTable };
