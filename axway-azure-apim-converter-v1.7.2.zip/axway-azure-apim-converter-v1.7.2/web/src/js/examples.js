/**
 * Example Axway configurations for testing
 */

export const examples = {
  petstore: {
    name: "Petstore API Key",
    description: "Official Swagger Petstore with custom API key authentication",
    config: {
      "name": "petstore3",
      "path": "/api/v3",
      "state": "published",
      "version": "1.0.17",
      "organization": "orga",
      "backendBasepath": "https://petstore3.swagger.io",
      "securityProfiles": [
        {
          "name": "_default",
          "isDefault": true,
          "devices": [
            {
              "name": "API Key",
              "type": "apiKey",
              "order": 1,
              "properties": {
                "apiKeyFieldName": "KeyId",
                "takeFrom": "HEADER",
                "removeCredentialsOnSuccess": true
              }
            }
          ]
        }
      ],
      "customProperties": {
        "customProperty1": "public",
        "customProperty4": "true"
      }
    }
  },

  oauth: {
    name: "OAuth 2.0 External",
    description: "External OAuth provider with JWT validation",
    config: {
      "name": "orders-api",
      "path": "/orders/v1",
      "state": "published",
      "version": "v1",
      "organization": "Production",
      "backendBasepath": "https://backend.example.com/api/orders",
      "securityProfiles": [
        {
          "name": "_default",
          "isDefault": true,
          "devices": [
            {
              "name": "OAuth 2.0 Authentication",
              "type": "oauthExternal",
              "order": 1,
              "properties": {
                "providerProfile": "azure-ad-provider",
                "tokenStore": "azure-ad-tokens",
                "scopes": "orders.read orders.write",
                "audience": "api://orders-api",
                "removeCredentialsOnSuccess": false
              }
            }
          ]
        }
      ],
      "customProperties": {
        "environment": "production",
        "team": "order-processing",
        "security-level": "high"
      }
    }
  },

  basic: {
    name: "HTTP Basic Auth",
    description: "Simple username/password authentication",
    config: {
      "name": "internal-api",
      "path": "/internal/v1",
      "state": "published",
      "version": "1.0",
      "organization": "Internal",
      "backendBasepath": "https://internal.example.com/api",
      "securityProfiles": [
        {
          "name": "_default",
          "isDefault": true,
          "devices": [
            {
              "name": "HTTP Basic Authentication",
              "type": "httpBasic",
              "order": 1,
              "properties": {
                "realm": "Internal API Access",
                "removeCredentialsOnSuccess": true
              }
            }
          ]
        }
      ]
    }
  },

  passthrough: {
    name: "Passthrough (No Auth)",
    description: "Public API with no authentication",
    config: {
      "name": "public-api",
      "path": "/public/v1",
      "state": "published",
      "version": "1.0",
      "organization": "Public",
      "backendBasepath": "https://public.example.com/api",
      "securityProfiles": [
        {
          "name": "_default",
          "isDefault": true,
          "devices": [
            {
              "name": "No Authentication",
              "type": "passthrough",
              "order": 1,
              "properties": {}
            }
          ]
        }
      ]
    }
  },

  simpleApiKey: {
    name: "Simple API Key",
    description: "Minimal API key configuration",
    config: {
      "name": "API-Key secured API",
      "path": "/api/v1/apikey",
      "state": "unpublished",
      "version": "1.0.0",
      "organization": "API Development",
      "securityProfiles": [
        {
          "name": "_default",
          "isDefault": true,
          "devices": [
            {
              "name": "API Key",
              "type": "apiKey",
              "order": 0,
              "properties": {
                "apiKeyFieldName": "KeyId",
                "takeFrom": "HEADER",
                "removeCredentialsOnSuccess": "true"
              }
            }
          ]
        }
      ]
    }
  },

  customerApi: {
    name: "Customer API (Advanced)",
    description: "Full-featured customer API with CORS and quotas",
    config: {
      "name": "customer-api",
      "path": "/customers/v1",
      "state": "published",
      "version": "v1",
      "organization": "Production",
      "backendBasepath": "https://backend.example.com/api/customers",
      "descriptionManual": "Customer Management API - Provides CRUD operations for customer data",
      "summary": "Customer API with API Key authentication",
      "securityProfiles": [
        {
          "_default": true,
          "devices": [
            {
              "name": "API Key Authentication",
              "type": "apiKey",
              "order": 1,
              "properties": {
                "apiKeyFieldName": "X-API-Key",
                "takeFrom": "HEADER",
                "removeCredentialsOnSuccess": true
              }
            }
          ]
        }
      ],
      "customProperties": {
        "environment": "production",
        "team": "customer-services",
        "costCenter": "CC-1234",
        "compliance": "PCI-DSS"
      }
    }
  },

  oauthInternal: {
    name: "OAuth 2.0 Internal",
    description: "Internal OAuth with token store",
    config: {
      "name": "OAuth secured API",
      "path": "/api/v1/oauth",
      "state": "published",
      "version": "1.0.0",
      "organization": "API Development",
      "securityProfiles": [
        {
          "name": "_default",
          "isDefault": true,
          "devices": [
            {
              "type": "oauth",
              "name": "OAuth",
              "order": 1,
              "properties": {
                "tokenStore": "OAuth Access Token Store",
                "accessTokenLocation": "HEADER",
                "authorizationHeaderPrefix": "Bearer",
                "scopesMustMatch": "Any",
                "scopes": "resource.WRITE, resource.READ",
                "removeCredentialsOnSuccess": true,
                "implicitGrantEnabled": true,
                "authCodeGrantTypeEnabled": true
              }
            }
          ]
        }
      ]
    }
  },

  customPolicy: {
    name: "Custom Auth Policy",
    description: "Custom authentication policy invocation",
    config: {
      "name": "Custom Policy secured API",
      "path": "/api/v1/custom-policy",
      "state": "published",
      "version": "1.0.0",
      "organization": "API Development",
      "securityProfiles": [
        {
          "name": "_default",
          "isDefault": true,
          "devices": [
            {
              "type": "authPolicy",
              "name": "Invoke Policy",
              "order": 1,
              "properties": {
                "authenticationPolicy": "Custom authentication policy",
                "useClientRegistry": true,
                "subjectSelector": "authentication.subject.id"
              }
            }
          ]
        }
      ]
    }
  },

  // YAML Examples (Advanced FilterCircuit)
  healthCheck: {
    name: "Health Check Policy (YAML)",
    description: "Simple health check and monitoring circuit",
    config: `name: Health Check Policy
description: Simple health check and monitoring circuit
filters:
  - name: BasicHealthAuth
    type: HTTPBasicFilter
    username: "healthcheck"
    password: "{{health-password}}"
  - name: HealthRateLimit
    type: ThrottlingFilter
    maxRequests: 1000
    timeWindow: 60
  - name: HealthBackend
    type: ConnectToURLFilter
    url: "https://health.enterprise.com/status"
    timeout: 5
  - name: HealthMetrics
    type: MetricsFilter
    metricName: "health_check_count"
    metricValue: "1"
    metricDimensions:
      service: "enterprise-api"
      environment: "production"
routing:
  default: HealthBackend
security:
  authentication: BasicHealthAuth
performance:
  rateLimit: HealthRateLimit
monitoring:
  metrics: HealthMetrics`
  },

  oauthSecurity: {
    name: "OAuth Security Policy (YAML)",
    description: "Enterprise OAuth 2.0 security with JWT validation",
    config: `name: OAuth Security Policy
description: Enterprise OAuth 2.0 security with JWT validation
filters:
  - name: OAuthValidation
    type: OAuth2Filter
    tokenEndpoint: "https://oauth.enterprise.com/token"
    clientId: "enterprise-api-client"
    clientSecret: "{{oauth-client-secret}}"
    scope: "api.read api.write"
  - name: SecurityRateLimit
    type: ThrottlingFilter
    maxRequests: 5000
    timeWindow: 60
  - name: SecureBackend
    type: ConnectToURLFilter
    url: "https://api.enterprise.com"
    timeout: 30
  - name: SecurityMetrics
    type: MetricsFilter
    metricName: "oauth_requests"
    metricValue: "1"
  - name: SecurityMonitoring
    type: MonitoringFilter
    logLevel: "INFO"
    includeHeaders: true
    includeBody: false
routing:
  default: SecureBackend
security:
  oauth: OAuthValidation
  rateLimit: SecurityRateLimit
monitoring:
  metrics: SecurityMetrics
  logging: SecurityMonitoring`
  },

  xmlThreat: {
    name: "XML Threat Protection (YAML)",
    description: "XML threat protection and validation",
    config: `name: XML Threat Policy
description: XML threat protection and validation
filters:
  - name: XMLThreatCheck
    type: XMLThreatProtectionFilter
    maxDepth: 10
    maxNodeCount: 1000
    maxAttributeCount: 50
    maxNamespaceCount: 10
    detectExternalEntities: true
  - name: XMLRateLimit
    type: ThrottlingFilter
    maxRequests: 2000
    timeWindow: 60
  - name: XMLBackend
    type: ConnectToURLFilter
    url: "https://xml.enterprise.com/api"
    timeout: 15
  - name: XMLMetrics
    type: MetricsFilter
    metricName: "xml_processing_count"
    metricValue: "1"
  - name: XMLCache
    type: ResponseCacheFilter
    cacheDuration: 300
    cacheKey: "xml-response"
    varyByHeaders: ["Content-Type"]
routing:
  default: XMLBackend
security:
  threatProtection: XMLThreatCheck
  rateLimit: XMLRateLimit
performance:
  caching: XMLCache
monitoring:
  metrics: XMLMetrics`
  },

  contentTransformation: {
    name: "Content Transformation (YAML)",
    description: "Complex content transformation and validation",
    config: `name: Content Transformation Policy
description: Enterprise content transformation and validation circuit
filters:
  - name: JSONToXMLTransform
    type: JSONTransformFilter
    rootElement: "Request"
    namespaceUri: "http://enterprise.com/api/v1"
    arrayDetection: true
  - name: XSLTransformation
    type: XSLTransformFilter
    xslContent: |
      <?xml version="1.0" encoding="UTF-8"?>
      <xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
        <xsl:template match="/">
          <EnterpriseRequest>
            <Header>
              <Timestamp><xsl:value-of select="current-dateTime()"/></Timestamp>
              <Source>APIM Gateway</Source>
            </Header>
            <Body>
              <xsl:copy-of select="*"/>
            </Body>
          </EnterpriseRequest>
        </xsl:template>
      </xsl:stylesheet>
    parameters:
      source: "API_GATEWAY"
      version: "1.0"
  - name: XMLToJSONTransform
    type: XMLToJSONFilter
    namespaceHandling: "ignore"
    arrayDetection: "auto"
    rootElement: "Response"
  - name: ContentModification
    type: ContentModifyFilter
    content: |
      {
        "apiVersion": "v1",
        "timestamp": "@(DateTime.Now)",
        "originalContent": @(context.Request.Body.As<string>()),
        "metadata": {
          "source": "enterprise-gateway",
          "transformed": true
        }
      }
    contentType: "application/json"
  - name: JSONThreatProtection
    type: JSONThreatProtectionFilter
    maxDepth: 8
    maxArrayElements: 1000
    maxObjectProperties: 200
    maxStringLength: 5000
  - name: CompressionFilter
    type: CompressionFilter
    compressionLevel: 6
    compressionTypes: ["application/json", "application/xml", "text/xml"]
  - name: LoadBalancedBackend
    type: LoadBalancingFilter
    algorithm: "round_robin"
    healthCheck: "/health"
    servers:
      - url: "https://api1.enterprise.com"
        weight: 50
      - url: "https://api2.enterprise.com" 
        weight: 30
      - url: "https://api3.enterprise.com"
        weight: 20
  - name: FailoverRetry
    type: FailoverFilter
    retryCount: 3
    retryInterval: 1000
    backoffMultiplier: 2
    maxInterval: 10000
transformation:
  request: [JSONToXMLTransform, XSLTransformation]
  response: [XMLToJSONTransform, ContentModification]
security:
  threatProtection: JSONThreatProtection
optimization:
  compression: CompressionFilter
backend:
  loadBalancing: LoadBalancedBackend
  failover: FailoverRetry
performance:
  cacheHeaders: true
  compressionEnabled: true
  keepAlive: true`
  },

  // Regression Test Examples
  securityApiKeyConfig: {
    name: "Security: API Key",
    description: "Standard API Key authentication with header checks",
    config: {
      "name": "Samples SecurityInbound APIKey",
      "path": "/samples/securityInbound/apiKey/v1/api",
      "state": "unpublished",
      "version": "1.0.0",
      "organization": "API Development",
      "securityProfiles": [
        {
          "name": "_default",
          "isDefault": true,
          "devices": [
            {
              "name": "API Key",
              "type": "apiKey",
              "order": 0,
              "properties": {
                "apiKeyFieldName": "KeyId",
                "takeFrom": "HEADER",
                "removeCredentialsOnSuccess": "false"
              }
            }
          ]
        }
      ]
    }
  },

  securityOauthConfig: {
    name: "Security: OAuth 2.0",
    description: "OAuth 2.0 validation with JWT and claims",
    config: {
      "name": "Samples SecurityInbound OAuth",
      "path": "/samples/securityInbound/oauth/v1/api",
      "state": "unpublished",
      "version": "1.0.0",
      "organization": "API Development",
      "securityProfiles": [
        {
          "name": "_default",
          "isDefault": true,
          "devices": [
            {
              "type": "oauth",
              "name": "OAuth",
              "order": 1,
              "properties": {
                "tokenStore": "OAuth Access Token Store",
                "accessTokenLocation": "HEADER",
                "authorizationHeaderPrefix": "Bearer",
                "accessTokenLocationQueryString": "",
                "scopesMustMatch": "Any",
                "scopes": "resource.WRITE, resource.READ, resource.ADMIN",
                "removeCredentialsOnSuccess": true,
                "implicitGrantEnabled": true,
                "implicitGrantLoginEndpointUrl": "https://localhost:8089/api/oauth/authorize",
                "implicitGrantLoginTokenName": "access_token",
                "authCodeGrantTypeEnabled": true,
                "authCodeGrantTypeRequestEndpointUrl": "https://localhost:8089/api/oauth/authorize",
                "authCodeGrantTypeRequestClientIdName": "client_id",
                "authCodeGrantTypeRequestSecretName": "client_secret",
                "authCodeGrantTypeTokenEndpointUrl": "https://localhost:8089/api/oauth/token",
                "authCodeGrantTypeTokenEndpointTokenName": "access_code"
              }
            }
          ]
        }
      ]
    }
  },

  securityOutboundBasic: {
    name: "Outbound: HTTP Basic",
    description: "Outbound HTTP Basic authentication",
    config: {
      "name": "Samples SecurityOutbound HTTP-Basic",
      "path": "/samples/securityOutbound/httpbasic/v1/api",
      "state": "unpublished",
      "version": "1.0.0",
      "organization": "API Development",
      "authenticationProfiles": [
        {
          "name": "HTTP Basic",
          "isDefault": true,
          "parameters": {
            "username": "my-username",
            "password": "my-password"
          },
          "type": "http_basic"
        }
      ]
    }
  },

  securityOutboundApikey: {
    name: "Outbound: API Key",
    description: "Outbound API Key injection",
    config: {
      "name": "Samples SecurityOutbound APIKey",
      "path": "/samples/securityOutbound/apikey/v1/api",
      "state": "unpublished",
      "version": "1.0.0",
      "organization": "API Development",
      "authenticationProfiles": [
        {
          "name": "_default",
          "isDefault": true,
          "parameters": {
            "apiKey": "4249823490238490",
            "apiKeyField": "KeyId",
            "httpLocation": "QUERYSTRING_PARAMETER"
          },
          "type": "apiKey"
        }
      ]
    }
  },

  securityOutboundClientCert: {
    name: "Outbound: Client Cert",
    description: "Outbound Mutual TLS (Client Certificate)",
    config: {
      "name": "Samples SecurityOutbound Client-Cert",
      "path": "/samples/securityOutbound/clientcert/v1/api",
      "state": "unpublished",
      "version": "1.0.0",
      "organization": "API Development",
      "authenticationProfiles": [
        {
          "name": "_default",
          "isDefault": true,
          "parameters": {
            "source": "file",
            "certFile": "../certificates/clientcert.pfx",
            "password": "axway",
            "trustAll": true
          },
          "type": "ssl"
        }
      ]
    }
  },

  complexCompleteConfig: {
    name: "Complex: Complete Config",
    description: "Large configuration with nested logic (1000+ lines)",
    config: {
      "name": "Samples Complete API",
      "path": "/sample/complete/api/v1",
      "state": "published",
      "summary": "My complete API-Summary",
      "version": "1.0.0",
      "organization": "API Development",
      "descriptionType": "manual",
      "descriptionManual": "This is my __markdown__ based API description.",
      "vhost": "api.custom-host.com",
      "backendBasepath": "https://any.server.com:7676",
      "image": "../images/sample-api-icon.jpg",
      "securityProfiles": [
        {
          "name": "_default",
          "isDefault": true,
          "devices": [
            {
              "name": "API Key",
              "type": "apiKey",
              "order": 0,
              "properties": {
                "apiKeyFieldName": "KeyId",
                "takeFrom": "HEADER",
                "removeCredentialsOnSuccess": "false"
              }
            }
          ]
        }
      ],
      "outboundProfiles": {
        "_default": {
          "requestPolicy": "Request policy 1",
          "routePolicy": "Routing policy 1",
          "responsePolicy": "Response policy 1",
          "faultHandlerPolicy": "Faulthandler policy 1"
        }
      },
      "authenticationProfiles": [
        {
          "name": "_default",
          "isDefault": "true",
          "parameters": {
            "apiKey": "4249823490238490",
            "apiKeyField": "KeyId",
            "httpLocation": "QUERYSTRING_PARAMETER"
          },
          "type": "apiKey"
        }
      ],
      "tags": {
        "tag-name 2": [
          "value 3",
          "value 4"
        ],
        "tag-name 1": [
          "value 1",
          "value 2"
        ]
      },
      "customProperties": {
        "customProperty1": "Test-Input 1",
        "customProperty2": "1",
        "customProperty3": "true"
      },
      "corsProfiles": [
        {
          "name": "_default",
          "isDefault": true,
          "origins": [
            "*"
          ],
          "allowedHeaders": [
            "Authorization"
          ],
          "exposedHeaders": [
            "via"
          ],
          "supportCredentials": false,
          "maxAgeSeconds": 0
        }
      ],
      "caCerts": [
        {
          "certFile": "../certificates/swaggerio.crt",
          "useForOutbound": true,
          "useForInbound": false
        },
        {
          "certFile": "../certificates/GoDaddyRootCertificateAuthority-G2.crt",
          "useForOutbound": true,
          "useForInbound": false
        },
        {
          "certFile": "../certificates/GoDaddySecureCertificateAuthority-G2.crt",
          "useForOutbound": true,
          "useForInbound": false
        },
        {
          "certFile": "../certificates/GlobalSignRootCA-R2.crt",
          "useForOutbound": false,
          "useForInbound": true
        }
      ],
      "applicationQuota": {
        "restrictions": [
          {
            "method": "*",
            "type": "throttlemb",
            "config": {
              "period": "hour",
              "mb": 555,
              "per": 1
            }
          }
        ]
      },
      "systemQuota": {
        "restrictions": [
          {
            "method": "*",
            "type": "throttle",
            "config": {
              "period": "hour",
              "messages": 666,
              "per": 2
            }
          }
        ]
      }
    }
  },

  methodLevelApikeyCors: {
    name: "Logic: Method Level API Key",
    description: "Method-specific API Key and CORS overrides",
    config: {
      "name": "Samples MethodLvl APIKeyCors OneMethod",
      "path": "/sample/methodlvl/apikey/cors/one/method/api/v1",
      "state": "published",
      "version": "1.0.7",
      "organization": "API Development",
      "inboundProfiles": {
        "findPetsByStatus": {
          "securityProfile": "API-Key",
          "corsProfile": "CORS Profile",
          "monitorAPI": true
        }
      },
      "securityProfiles": [
        {
          "name": "API-Key",
          "isDefault": false,
          "devices": [
            {
              "name": "API Key",
              "type": "apiKey",
              "order": 0,
              "properties": {
                "apiKeyFieldName": "KeyId",
                "takeFrom": "HEADER",
                "removeCredentialsOnSuccess": "false"
              }
            }
          ]
        }
      ],
      "corsProfiles": [
        {
          "name": "CORS Profile",
          "isDefault": false,
          "origins": [
            "*"
          ],
          "allowedHeaders": [
            "Authorization"
          ],
          "exposedHeaders": [
            "via"
          ],
          "supportCredentials": false,
          "maxAgeSeconds": 0
        }
      ]
    }
  },

  apiKeyAndCorsTwoMethods: {
    name: "Logic: Multi-Method Security",
    description: "Multiple methods with distinct security profiles",
    config: {
      "name": "Samples MethodLvl APIKeyCors TwoMethods",
      "path": "/sample/methodlvl/apikey/cors/two/methods/api/v1",
      "state": "unpublished",
      "version": "1.0.7",
      "organization": "API Development",
      "inboundProfiles": {
        "findPetsByStatus": {
          "securityProfile": "Another API-Key profile",
          "corsProfile": "CORS Profile ABC",
          "monitorAPI": true
        },
        "getOrderById": {
          "securityProfile": "Another API-Key profile",
          "corsProfile": "CORS Profile ABC",
          "monitorAPI": true
        }
      },
      "securityProfiles": [
        {
          "name": "Another API-Key profile",
          "isDefault": false,
          "devices": [
            {
              "name": "API Key",
              "type": "apiKey",
              "order": 0,
              "properties": {
                "apiKeyFieldName": "KeyId",
                "takeFrom": "HEADER",
                "removeCredentialsOnSuccess": "false"
              }
            }
          ]
        }
      ],
      "corsProfiles": [
        {
          "name": "CORS Profile ABC",
          "isDefault": false,
          "origins": [
            "*"
          ],
          "allowedHeaders": [
            "Authorization"
          ],
          "exposedHeaders": [
            "via"
          ],
          "supportCredentials": false,
          "maxAgeSeconds": 0
        }
      ]
    }
  },

  oauthDefaultApikeyOnOneMethod: {
    name: "Logic: OAuth Default + API Key",
    description: "Global OAuth default with single method API Key override",
    config: {
      "name": "Samples MethodLvl OAuthDefault APIKey OneMethod",
      "path": "/sample/methodlvl/oauthdefault/apikey/one/method/api/v1",
      "state": "unpublished",
      "version": "1.0.7",
      "organization": "API Development",
      "inboundProfiles": {
        "findPetsByStatus": {
          "securityProfile": "Yet another API-Key profile"
        },
        "_default": {
          "securityProfile": "_default"
        }
      },
      "securityProfiles": [
        {
          "name": "_default",
          "isDefault": true,
          "devices": [
            {
              "type": "oauth",
              "name": "OAuth",
              "order": 1,
              "properties": {
                "tokenStore": "OAuth Access Token Store",
                "accessTokenLocation": "HEADER",
                "authorizationHeaderPrefix": "Bearer",
                "accessTokenLocationQueryString": "",
                "scopesMustMatch": "Any",
                "scopes": "resource.WRITE, resource.READ, resource.ADMIN",
                "removeCredentialsOnSuccess": true,
                "implicitGrantEnabled": true,
                "implicitGrantLoginEndpointUrl": "https://localhost:8089/api/oauth/authorize",
                "implicitGrantLoginTokenName": "access_token",
                "authCodeGrantTypeEnabled": true,
                "authCodeGrantTypeRequestEndpointUrl": "https://localhost:8089/api/oauth/authorize",
                "authCodeGrantTypeRequestClientIdName": "client_id",
                "authCodeGrantTypeRequestSecretName": "client_secret",
                "authCodeGrantTypeTokenEndpointUrl": "https://localhost:8089/api/oauth/token",
                "authCodeGrantTypeTokenEndpointTokenName": "access_code"
              }
            }
          ]
        },
        {
          "name": "Yet another API-Key profile",
          "isDefault": false,
          "devices": [
            {
              "name": "API Key",
              "type": "apiKey",
              "order": 0,
              "properties": {
                "apiKeyFieldName": "KeyId",
                "takeFrom": "HEADER",
                "removeCredentialsOnSuccess": "false"
              }
            }
          ]
        }
      ]
    }
  },

  outboundboundHttpbasicAddParam: {
    name: "Outbound: Basic + Params",
    description: "Outbound Basic Auth with additional parameters",
    config: {
      "name": "Samples MethodLvl HTTPBasicAuthN AddParam OneMethod",
      "path": "/sample/methodlvl/httpbasic/param/one/method/api/v1",
      "state": "published",
      "version": "1.0.7",
      "organization": "API Development",
      "outboundProfiles": {
        "_default": {
          "authenticationProfile": "_default",
          "routeType": "proxy"
        },
        "getOrderById": {
          "authenticationProfile": "HTTP Basic Auth",
          "parameters": [
            {
              "name": "additionalOutboundParam",
              "required": false,
              "type": "string",
              "paramType": "header",
              "value": "Test-Value",
              "exclude": false,
              "additional": true
            }
          ]
        }
      },
      "authenticationProfiles": [
        {
          "name": "HTTP Basic Auth",
          "parameters": {
            "username": "usernameabc",
            "password": "password"
          },
          "type": "http_basic"
        }
      ]
    }
  },

  multiRestrictionQuota: {
    name: "Traffic: Multi-Restriction Quota",
    description: "Multiple quota restrictions (Bandwidth + Calls)",
    config: {
      "name": "Samples Quota Multiple restrictions",
      "path": "/samples/quota/multipleRestrictions/v1/api",
      "state": "published",
      "version": "1.0.1",
      "organization": "API Development",
      "applicationQuota": {
        "restrictions": [
          {
            "method": "*",
            "type": "throttlemb",
            "config": {
              "period": "hour",
              "mb": 128,
              "per": 1
            }
          },
          {
            "method": "*",
            "type": "throttlemb",
            "config": {
              "period": "day",
              "mb": 8000,
              "per": 1
            }
          },
          {
            "method": "*",
            "type": "throttle",
            "config": {
              "period": "minute",
              "messages": 1500,
              "per": 30
            }
          }
        ]
      },
      "systemQuota": {
        "restrictions": [
          {
            "method": "*",
            "type": "throttlemb",
            "config": {
              "period": "hour",
              "md": 2048,
              "per": 1
            }
          },
          {
            "method": "*",
            "type": "throttle",
            "config": {
              "period": "minute",
              "messages": 10000,
              "per": 30
            }
          }
        ]
      }
    }
  },

  systemQuotaOnly: {
    name: "Traffic: System Quota Only",
    description: "System-level quota without application quota",
    config: {
      "name": "Samples System-Quota only",
      "path": "/samples/quota/systemonly/v1/api",
      "state": "published",
      "version": "1.0.1",
      "organization": "API Development",
      "systemQuota": {
        "restrictions": [
          {
            "method": "*",
            "type": "throttle",
            "config": {
              "period": "minute",
              "messages": 1000,
              "per": 5
            }
          }
        ]
      }
    }
  },

  securityCustomPolicyConfig: {
    name: "Security: Custom Policy",
    description: "Custom policy placeholder handling",
    config: {
      "name": "Samples SecurityInbound CustomPolicy",
      "path": "/samples/securityInbound/customPolicy/v1/api",
      "state": "unpublished",
      "version": "1.0.0",
      "organization": "API Development",
      "securityProfiles": [
        {
          "name": "_default",
          "isDefault": true,
          "devices": [
            {
              "type": "authPolicy",
              "name": "Invoke Policy",
              "order": 1,
              "properties": {
                "authenticationPolicy": "Custom authentication policy",
                "useClientRegistry": true,
                "subjectSelector": "authentication.subject.id",
                "descriptionType": "original",
                "descriptionUrl": "",
                "descriptionMarkdown": "",
                "description": ""
              }
            }
          ]
        }
      ]
    }
  }
};

/**
 * Get example by key
 */
export function getExample(key) {
  return examples[key] || null;
}

/**
 * Get all example keys
 */
export function getExampleKeys() {
  return Object.keys(examples);
}
