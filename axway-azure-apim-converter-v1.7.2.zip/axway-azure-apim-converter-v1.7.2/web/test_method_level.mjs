import { AxwayToApimConverter } from './src/js/axway-converter.js';

const input = {
    "name": "Samples MethodLvl APIKeyCors OneMethod",
    "path": "/sample/methodlvl/apikey/cors/one/method/api/v1",
    "state": "published",
    "version": "1.0.7",
    "organization": "API Development",
    "inboundProfiles": {
        "findPetsByStatus": {
            "securityProfile": "API-Key",
            "corsProfile": "CORS Profile",
            "monitorAPI": true
        }
    },
    "securityProfiles": [
        {
            "name": "API-Key",
            "isDefault": false,
            "devices": [
                {
                    "name": "API Key",
                    "type": "apiKey",
                    "order": 0,
                    "properties": {
                        "apiKeyFieldName": "KeyId",
                        "takeFrom": "HEADER",
                        "removeCredentialsOnSuccess": "false"
                    }
                }
            ]
        }
    ],
    "corsProfiles": [
        {
            "name": "CORS Profile",
            "isDefault": false,
            "origins": [
                "*"
            ],
            "allowedHeaders": [
                "Authorization"
            ],
            "exposedHeaders": [
                "via"
            ],
            "supportCredentials": false,
            "maxAgeSeconds": 0
        }
    ]
};

const converter = new AxwayToApimConverter();
const result = converter.convertFilterCircuitToXml(input, { includeLogging: true });

console.log('Generated XML:');
console.log(result.xml);
console.log('\n---\n');

// Check for expected elements
const checks = [
    { name: 'API Key Check', pattern: 'check-header name="KeyId"', found: result.xml.includes('check-header name="KeyId"') },
    { name: 'CORS Policy', pattern: '<cors', found: result.xml.includes('<cors') },
    { name: 'Choose Block', pattern: '<choose>', found: result.xml.includes('<choose>') },
    { name: 'Operation ID Check', pattern: 'context.Operation.Id', found: result.xml.includes('context.Operation.Id') }
];

console.log('Validation Results:');
checks.forEach(check => {
    console.log(`${check.found ? '✓' : '✗'} ${check.name}: ${check.found ? 'FOUND' : 'MISSING'}`);
});
