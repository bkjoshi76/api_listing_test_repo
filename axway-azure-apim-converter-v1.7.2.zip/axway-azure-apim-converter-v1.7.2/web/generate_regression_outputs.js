
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { AxwayToApimConverter } from './src/js/axway-converter.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const examplesDir = path.join(__dirname, '../examples');

// List of example files to process
const exampleFiles = [
    'security-apikey-config.json',
    'security-custom-policy-config.json',
    'security-oauth-config.json',
    'security-oauth-external-config.json',
    'security-outbound-apikey.json',
    'security-outbound-basic.json',
    'security-outbound-clientCert.json',
    'complex-complete-config.json',
    'method-level-apikey-cors.json',
    'api-key-and-cors-two-methods.json',
    'oauth-default-apikey-on-one-method.json',
    'outboundbound-httpbasic-add-param.json',
    'multi-restriction-quota.json',
    'system-quota-only.json'
];

console.log('Starting Web UI Regression Output Generation...');

const converter = new AxwayToApimConverter();

exampleFiles.forEach(file => {
    const filePath = path.join(examplesDir, file);
    if (fs.existsSync(filePath)) {
        try {
            const content = fs.readFileSync(filePath, 'utf8');
            // Ensure content is valid JSON first
            const config = JSON.parse(content);

            // Convert using the class method (passing JSON string as YAML/JSON)
            const result = converter.convertYamlToXml(JSON.stringify(config));

            if (result.success) {
                // Save to file
                const outputFilename = file.replace('.json', '-web.xml');
                const outputPath = path.join(examplesDir, outputFilename);
                fs.writeFileSync(outputPath, result.xml);
                console.log(`[SUCCESS] Generated ${outputFilename}`);
            } else {
                console.error(`[ERROR] Conversion failed for ${file}: ${result.error}`);
            }
        } catch (err) {
            console.error(`[ERROR] Failed to process ${file}:`, err.message);
        }
    } else {
        console.warn(`[WARN] File not found: ${file}`);
    }
});

console.log('Regression Output Generation Complete.');
