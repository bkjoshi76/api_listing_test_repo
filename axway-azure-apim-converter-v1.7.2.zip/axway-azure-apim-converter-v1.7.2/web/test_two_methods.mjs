import { AxwayToApimConverter } from './src/js/axway-converter.js';
import { readFileSync } from 'fs';

const input = JSON.parse(readFileSync('test_two_methods_input.json', 'utf-8'));

const converter = new AxwayToApimConverter();
const result = converter.convertFilterCircuitToXml(input, { includeLogging: true });

console.log('Generated XML:\n');
console.log(result.xml);

// Validation checks
const checks = [
    { name: 'Choose Block', found: result.xml.includes('<choose>') },
    { name: 'findPetsByStatus condition', found: result.xml.includes('findPetsByStatus') },
    { name: 'getOrderById condition', found: result.xml.includes('getOrderById') },
    { name: 'Two <when> blocks', found: (result.xml.match(/<when/g) || []).length === 2 },
    { name: 'API Key checks', found: (result.xml.match(/check-header name="KeyId"/g) || []).length === 2 },
    { name: 'CORS policies', found: (result.xml.match(/<cors/g) || []).length === 2 }
];

console.log('\n---\nValidation Results:');
checks.forEach(check => {
    console.log(`${check.found ? '✓' : '✗'} ${check.name}: ${check.found ? 'PASS' : 'FAIL'}`);
});

const allPassed = checks.every(c => c.found);
console.log(`\n${allPassed ? '✅ ALL CHECKS PASSED' : '❌ SOME CHECKS FAILED'}`);
