import { AxwayToApimConverter } from './src/js/axway-converter.js';
import { readFileSync, writeFileSync } from 'fs';

const input = JSON.parse(readFileSync('test_oauth_default_apikey_override.json', 'utf-8'));

const converter = new AxwayToApimConverter();
const result = converter.convertFilterCircuitToXml(input, { includeLogging: false });

writeFileSync('test_oauth_default_apikey_override_web_output.xml', result.xml);
console.log('Saved output to test_oauth_default_apikey_override_web_output.xml');
