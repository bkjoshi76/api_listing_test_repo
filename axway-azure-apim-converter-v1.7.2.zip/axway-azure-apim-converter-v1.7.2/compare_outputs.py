import os
import difflib
import re

examples_dir = 'examples'
files = [
    'security-apikey-config',
    'security-custom-policy-config',
    'security-oauth-config',
    'security-oauth-external-config',
    'security-outbound-apikey',
    'security-outbound-basic',
    'security-outbound-clientCert'
]

def normalize_xml(xml_content):
    # Remove comments to focus on functional differences
    xml_content = re.sub(r'<!--.*?-->', '', xml_content, flags=re.DOTALL)
    # Remove XML declaration
    xml_content = re.sub(r'<\?xml.*?\?>', '', xml_content)
    # Normalize whitespace
    lines = [line.strip() for line in xml_content.splitlines() if line.strip()]
    return '\n'.join(lines)

print("Comparing Python vs Web UI Outputs:\n")

for base_name in files:
    python_file = os.path.join(examples_dir, f"{base_name}-python.xml")
    web_file = os.path.join(examples_dir, f"{base_name}-web.xml")

    if not os.path.exists(python_file) or not os.path.exists(web_file):
        print(f"Skipping {base_name}: Missing output files.")
        continue

    with open(python_file, 'r') as f:
        python_xml = f.read()
    
    with open(web_file, 'r') as f:
        web_xml = f.read()

    norm_python = normalize_xml(python_xml)
    norm_web = normalize_xml(web_xml)

    if norm_python == norm_web:
        print(f"[MATCH] {base_name}")
    else:
        print(f"[DIFF]  {base_name}")
        # Print first few lines of diff
        diff = difflib.unified_diff(
            norm_python.splitlines(), 
            norm_web.splitlines(), 
            fromfile='Python', 
            tofile='Web UI', 
            n=0
        )
        print('\n'.join(list(diff)[:10])) # Show first 10 lines of diff
        print("..." if len(list(diff)) > 10 else "")
        print("-" * 40)
