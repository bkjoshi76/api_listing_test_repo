# OAuth Default with API Key Override - Test Results

## Test Input
GitHub example: `oauth-default-apikey-on-one-method.json`

**Configuration:**
- **Default Security**: OAuth (`_default` profile with `isDefault: true`)
- **Method Override**: `findPetsByStatus` uses API Key instead of OAuth
- **Inbound Profiles**: 
  - `_default` → references `_default` security profile (OAuth)
  - `findPetsByStatus` → references "Yet another API-Key profile"

## Expected Behavior

All operations should use OAuth by default, except `findPetsByStatus` which should use API Key.

## Python Converter Output (v1.2.0)

```xml
<policies>
  <inbound>
    <base/>
    <!-- Method-Level Inbound Overrides -->
    <choose>
      <when condition="@(context.Operation.Id == &quot;findPetsByStatus&quot;)">
        <check-header name="KeyId" .../>
      </when>
    </choose>
  </inbound>
  ...
</policies>
```

**Issue**: ❌ Missing global OAuth policy for default operations

## Web Converter Output (v1.7.0)

```xml
<policies>
  <inbound>
    <base/>
    <!-- Global Security Profile: _default -->
    <validate-jwt header-name="Authorization" ...>
      <openid-config url="{{oauth-openid-config-url}}"/>
    </validate-jwt>

    <!-- Method-Level Inbound Overrides -->
    <choose>
      <when condition="@(context.Operation.Id == &quot;findPetsByStatus&quot;)">
        <check-header name="KeyId" .../>
      </when>
    </choose>
  </inbound>
  ...
</policies>
```

**Result**: ✅ Correctly generates both:
1. Global OAuth policy (for all operations by default)
2. Method-level API Key override (for `findPetsByStatus`)

## Comparison

| Feature | Python v1.2.0 | Web v1.7.0 | Correct |
|---------|--------------|------------|---------|
| Global OAuth policy | ❌ Missing | ✅ Present | Web |
| Method override for findPetsByStatus | ✅ Present | ✅ Present | Both |
| API Key check | ✅ Correct | ✅ Correct | Both |

## Conclusion

✅ **Web Converter v1.7.0 is MORE CORRECT than Python v1.2.0**

The Web converter properly handles the combination of:
- Default security profiles (`isDefault: true`)
- Global inbound profiles (`_default`)
- Method-level overrides

The Python converter has a bug where it doesn't apply the default security profile globally when method-level overrides are present.

## Validation Results

All checks passed for Web converter v1.7.0:
- ✓ Global OAuth policy
- ✓ Choose block for overrides
- ✓ findPetsByStatus override
- ✓ API Key check in override
- ✓ OAuth JWT validation
- ✓ OAuth openid-config
