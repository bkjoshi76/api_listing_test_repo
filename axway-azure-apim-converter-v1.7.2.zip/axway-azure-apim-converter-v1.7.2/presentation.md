---
marp: true
theme: default
paginate: true
backgroundColor: #fff
---

# Axway to Azure APIM Converter
## Technical Overview & Feature Presentation

**Automated Migration from Axway API Gateway to Azure API Management**

---

# Executive Summary

- **Purpose**: Automated conversion of Axway policies to Azure APIM XML.
- **Key Benefits**:
  - ✅ **Zero Manual Conversion**: Automated policy transformation.
  - ✅ **Dual Implementation**: Python CLI + Web Application.
  - ✅ **Production Ready**: Fully validated, error-free XML output.
- **Success Metrics**:
  - **v1.7.2 Released**: Full parity + New API Analytics Dashboard.
  - **100% Validation**: Passed all regression tests including complex configs.
  - **14+ Filter Types**: Now including OAuth, External Auth, and System Quotas.

---

# Architecture Overview

```mermaid
graph LR
    A[Axway FilterCircuit<br/>JSON/YAML] --> B{Converter}
    B --> C[Python CLI<br/>fully_validated_converter.py]
    B --> D[Web Application<br/>localhost:5173]
    C --> E[Azure APIM<br/>Policy XML]
    D --> E
    
    style A fill:#e1f5ff
    style E fill:#d4edda
    style B fill:#fff3cd
```

- **Backend**: Python 3.x (CLI, Batch Processing)
- **Frontend**: Vite + Vanilla JS (Interactive Web Interface)
- **Input**: JSON/YAML (Axway Exports)
- **Output**: XML (Azure APIM Policy)

---

# Core Features: Filter Conversion

**Authentication & Security (v1.7.2 Enhanced)**
- `SslFilter` ➡️ `validate-client-certificate`
- `AuthenticateAPIKeyFilter` ➡️ `check-header` (with Rate Limiting)
- `OAuthFilter` / `OAuthExternal` ➡️ `validate-jwt` (New!)
- `OutboundSecurity` ➡️ `authentication-certificate` / `basic`

**Message Processing**
- `SetAttributeFilter` ➡️ `set-variable`
- `TraceFilter` ➡️ `trace`

**Logic & Flow**
- `CompareAttributeFilter` ➡️ `choose` (Conditional Logic)
- `Reflector` ➡️ `return-response`

---

# Feature Deep Dive: Quota Management

**Axway Input (JSON)**
```json
{
  "type": "throttle",
  "config": { "messages": "3000", "period": "hour" }
}
```

**Azure APIM Output (XML)**
```xml
<quota calls="3000" renewal-period="3600"/>
```

- **Smart Mapping**: Automatically converts time periods (second, minute, hour, day, week, month) to seconds.
- **Bandwidth Support**: Converts MB limits to bytes.

---

# Feature Deep Dive: Method Level Overrides (v1.7.2)

**Problem**: Axway defines policies per "FilterCircuit", but Azure APIM often requires operation-specific logic within a single policy file.

**Solution**: Use `<choose>` policies based on `operationId`.

**Supported Scenarios**:
- ✅ **API Key Overrides**: Specific keys for specific methods.
- ✅ **CORS Overrides**: Custom CORS rules per operation.
- ✅ **Mixed Profiles**: Default OAuth global + API Key override.
- ✅ **Outbound Security**: Method-specific backend auth.

```xml
<choose>
  <when condition="@(context.Operation.Id == &quot;findPetsByStatus&quot;)">
    <check-header name="KeyId" ... /> <!-- Method Specific -->
  </when>
  <when condition="@(context.Operation.Id == &quot;_default&quot;)">
    <validate-jwt ... /> <!-- Global Default -->
  </when>
</choose>
```

---

# Feature Deep Dive: Complex Configuration Parity

**Challenge**: Converting large, real-world Axway configurations with 1000+ lines of code.

**Achievement**:
- Validated against `complex-complete-config.json`.
- **100% Parity** achieved for:
  - Nested logic flows.
  - Multiple quota restrictions (Application + System).
  - Complex security chains.

**Result**:
- Identical XML structure between Python CLI and Web UI.
- Zero manual fix-up required for generated policies.

---

# New Feature: Web Dashboard & Filtering

**Interactive Web Interface**
- **Live Editor**: Paste Axway JSON/YAML and see XML instantly.
- **Comparison View**: Side-by-side diff of Original vs. Converted.
- **Dashboard**: View all APIs in a sortable, filterable table.

**Recent Updates**
- **Column-Level Filtering**: Filter APIs by Host, Name, Security, and Complexity.
- **Release Management**: One-click generation of release zip files.

---

# New Feature: API Analytics (v1.7.2)

**Visual Insights into API Portfolio**

- **Dashboard**: High-level view of API usage, latency, and errors.
- **Demo Data**: Built-in mock data for instant visualization.
- **Backend Integration**: Connects to live backend for real-time stats.
- **Interactive Charts**: Drill down into specific metrics.

---

# Testing & Validation

**Strategy**
- **Unit Tests**: Python `pytest` suite covering all filter types.
- **Parity Testing**: Ensuring Python and JS converters produce identical XML.
- **Validation**: Generated XML is validated against Azure APIM schemas.

**Results**
- ✅ 100% Validation Success Rate on test corpus.
- ✅ Zero manual intervention required for supported filters.

---

# Deployment & Usage

**Python CLI (Batch / CI/CD)**
```bash
python scripts/fully_validated_converter.py --convert input.json --output output.xml
```

**Web Application (Interactive)**
```bash
npm run dev
# Access at http://localhost:5173
```

**Azure Integration**
- Can be run as an Azure Function.
- Integrates into Azure DevOps Pipelines.

---

# Roadmap

- **Phase 1 (Complete - v1.7.1)**: 
  - Core filters, Quotas (App + System), Method Overrides.
  - OAuth 2.0 / JWT Validation support.
  - Web App with Comparison View.
- **Phase 2 (Next)**: 
  - Custom policy templates.
  - Export to Bicep/ARM templates.
  - Direct Azure Deployment integration.
- **Phase 3 (Future)**:
  - Policy versioning and rollback.
  - Governance and compliance checks.

---

# Thank You

**Axway to Azure APIM Converter**

- **Documentation**: `TECHNICAL_PRESENTATION.md`, `README.md`
- **Live Demo**: `http://localhost:5173`

*Ready for Enterprise Migration*
