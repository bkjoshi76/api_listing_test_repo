#!/usr/bin/env python3
"""
Strategic Axway FilterCircuit to Azure APIM Converter - XML OUTPUT VERSION

Demo converter transforming imperative Axway FilterCircuit networks 
directly into Azure APIM XML policy format - no intermediate JSON.

Author: Enterprise API Team
Version: 1.1.0 - Direct XML Output
License: MIT
"""

import yaml
import argparse
import sys
import os
import xml.etree.ElementTree as ET
from xml.dom import minidom
from typing import Dict, List, Any, Tuple, Optional
from datetime import datetime
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class StrategicFilterConverter:
    """
    Strategic converter for Axway FilterCircuit to Azure APIM XML transformation.
    
    Implements Demo conversion patterns for 25+ filter types with
    direct XML output for Azure APIM deployment.
    """
    
    def __init__(self):
        """Initialize the strategic converter with enterprise mappings."""
        self.version = "1.1.0"
        self.supported_filters = {
            # Authentication & Identity (5 filters)
            'HTTPBasicFilter': {'policy': 'authentication-basic', 'complexity': 'Simple', 'section': 'inbound'},
            'OAuth2Filter': {'policy': 'validate-jwt', 'complexity': 'Moderate', 'section': 'inbound'},
            'JWTFilter': {'policy': 'validate-jwt', 'complexity': 'Moderate', 'section': 'inbound'},
            'LDAPFilter': {'policy': 'authentication-basic', 'complexity': 'Complex', 'section': 'inbound'},
            'SAMLFilter': {'policy': 'validate-jwt', 'complexity': 'Complex', 'section': 'inbound'},
            
            # Security & Protection (6 filters)
            'XMLThreatProtectionFilter': {'policy': 'xml-threat-detection', 'complexity': 'Complex', 'section': 'inbound'},
            'JSONThreatProtectionFilter': {'policy': 'json-threat-detection', 'complexity': 'Complex', 'section': 'inbound'},
            'IPWhitelistFilter': {'policy': 'ip-filter', 'complexity': 'Simple', 'section': 'inbound'},
            'IPBlacklistFilter': {'policy': 'ip-filter', 'complexity': 'Simple', 'section': 'inbound'},
            'SQLInjectionFilter': {'policy': 'sql-threat-detection', 'complexity': 'Moderate', 'section': 'inbound'},
            'XSSProtectionFilter': {'policy': 'xss-protection', 'complexity': 'Moderate', 'section': 'inbound'},
            
            # Rate Limiting & Throttling (3 filters)
            'ThrottlingFilter': {'policy': 'rate-limit', 'complexity': 'Simple', 'section': 'inbound'},
            'ConcurrencyFilter': {'policy': 'concurrency-limit', 'complexity': 'Moderate', 'section': 'inbound'},
            'QuotaFilter': {'policy': 'quota', 'complexity': 'Simple', 'section': 'inbound'},
            
            # Content Transformation (4 filters)
            'XSLTransformFilter': {'policy': 'xsl-transform', 'complexity': 'Moderate', 'section': 'inbound'},
            'JSONTransformFilter': {'policy': 'json-to-xml', 'complexity': 'Moderate', 'section': 'inbound'},
            'XMLToJSONFilter': {'policy': 'xml-to-json', 'complexity': 'Moderate', 'section': 'outbound'},
            'ContentModifyFilter': {'policy': 'set-body', 'complexity': 'Simple', 'section': 'inbound'},
            
            # Routing & Backend (3 filters)
            'ConnectToURLFilter': {'policy': 'set-backend-service', 'complexity': 'Simple', 'section': 'backend'},
            'LoadBalancingFilter': {'policy': 'set-backend-service', 'complexity': 'Moderate', 'section': 'backend'},
            'FailoverFilter': {'policy': 'retry', 'complexity': 'Moderate', 'section': 'backend'},
            
            # Monitoring & Analytics (2 filters)
            'MonitoringFilter': {'policy': 'log-to-eventhub', 'complexity': 'Simple', 'section': 'outbound'},
            'MetricsFilter': {'policy': 'emit-metric', 'complexity': 'Simple', 'section': 'outbound'},
            
            # Response Processing (2 filters)
            'ResponseCacheFilter': {'policy': 'cache-lookup-value', 'complexity': 'Simple', 'section': 'inbound'},
            'CompressionFilter': {'policy': 'compression', 'complexity': 'Simple', 'section': 'outbound'}
        }
        
        # Strategic complexity mapping
        self.complexity_symbols = {
            'Simple': '🟢',
            'Moderate': '🟡', 
            'Complex': '🔴'
        }
        
        # Initialize statistics
        self.stats = {
            'total_circuits': 0,
            'total_filters': 0,
            'converted_filters': 0,
            'externalized_filters': 0,
            'success_rate': 0.0
        }

    def display_strategic_matrix(self):
        """Display the strategic filter transformation matrix."""
        print("\n" + "=" * 100)
        print("  STRATEGIC AXWAY FILTERCIRCUIT TO AZURE APIM - ENTERPRISE MIGRATION")
        print("=" * 100)
        print(f"Total Supported Filters: {len(self.supported_filters)}")
        print("Architecture: Imperative Filter Networks → Declarative XML Policy Pipelines")
        print()
        
        # Group filters by category
        categories = {
            'Authentication & Identity': [
                'HTTPBasicFilter', 'OAuth2Filter', 'JWTFilter', 'LDAPFilter', 'SAMLFilter'
            ],
            'Security & Protection': [
                'XMLThreatProtectionFilter', 'JSONThreatProtectionFilter', 'IPWhitelistFilter',
                'IPBlacklistFilter', 'SQLInjectionFilter', 'XSSProtectionFilter'
            ],
            'Rate Limiting & Throttling': [
                'ThrottlingFilter', 'ConcurrencyFilter', 'QuotaFilter'
            ],
            'Content Transformation': [
                'XSLTransformFilter', 'JSONTransformFilter', 'XMLToJSONFilter', 'ContentModifyFilter'
            ],
            'Routing & Backend': [
                'ConnectToURLFilter', 'LoadBalancingFilter', 'FailoverFilter'
            ],
            'Monitoring & Analytics': [
                'MonitoringFilter', 'MetricsFilter'
            ],
            'Response Processing': [
                'ResponseCacheFilter', 'CompressionFilter'
            ]
        }
        
        for category, filters in categories.items():
            print(f"📁 {category}:")
            for filter_name in filters:
                if filter_name in self.supported_filters:
                    policy_info = self.supported_filters[filter_name]
                    symbol = self.complexity_symbols[policy_info['complexity']]
                    print(f"   {filter_name:<30} → {policy_info['policy']:<20} ({symbol} {policy_info['complexity']})")
            print()

    def convert_filter_circuit_to_xml(self, circuit_config: Dict[str, Any]) -> str:
        """
        Convert a complete Axway FilterCircuit directly to Azure APIM XML policy.
        
        Args:
            circuit_config: Complete FilterCircuit configuration
            
        Returns:
            XML policy string ready for Azure APIM deployment
        """
        circuit_name = circuit_config.get('name', 'UnknownCircuit')
        filters = circuit_config.get('filters', [])
        
        logger.info(f"Converting FilterCircuit: {circuit_name}")
        logger.info(f"Total filters in circuit: {len(filters)}")
        
        self.stats['total_circuits'] += 1
        self.stats['total_filters'] += len(filters)
        
        # Create root policies element
        policies = ET.Element("policies")
        
        # Add comment with conversion info
        comment = ET.Comment(f" Generated by Strategic Converter v{self.version} from FilterCircuit: {circuit_name} ")
        policies.append(comment)
        
        # Create sections
        inbound = ET.SubElement(policies, "inbound")
        backend = ET.SubElement(policies, "backend") 
        outbound = ET.SubElement(policies, "outbound")
        on_error = ET.SubElement(policies, "on-error")
        
        # Add base elements
        for section in [inbound, backend, outbound, on_error]:
            base = ET.SubElement(section, "base")
            base.text = ""
        
        # Process filters and add to appropriate sections
        converted_count = 0
        externalized_count = 0
        
        for filter_config in filters:
            filter_name = filter_config.get('name', 'UnknownFilter')
            filter_type = filter_config.get('type', filter_name)
            
            if filter_type in self.supported_filters:
                mapping = self.supported_filters[filter_type]
                section_name = mapping['section']
                
                # Get the appropriate section
                if section_name == 'inbound':
                    target_section = inbound
                elif section_name == 'backend':
                    target_section = backend
                elif section_name == 'outbound':
                    target_section = outbound
                else:
                    target_section = inbound  # Default to inbound
                
                # Add policy to section
                self._add_policy_to_xml_section(target_section, filter_type, filter_config)
                converted_count += 1
            else:
                # Add comment for externalized filter
                comment = ET.Comment(f" Externalized Filter: {filter_type} ('{filter_name}') - Requires manual implementation ")
                inbound.append(comment)
                externalized_count += 1
        
        # Update statistics
        self.stats['converted_filters'] += converted_count
        self.stats['externalized_filters'] += externalized_count
        
        if len(filters) > 0:
            success_rate = (converted_count / len(filters)) * 100
        else:
            success_rate = 0
        
        # Add statistics comment
        stats_comment = ET.Comment(f" Conversion Statistics: {converted_count}/{len(filters)} filters converted ({success_rate:.0f}% success rate) ")
        policies.append(stats_comment)
        
        return self._prettify_xml(policies)

    def _add_policy_to_xml_section(self, section: ET.Element, filter_type: str, filter_config: Dict[str, Any]):
        """Add a policy element to the specified XML section."""
        
        # Add comment with original filter info
        comment = ET.Comment(f" {filter_config.get('name', filter_type)} ({filter_type}) ")
        section.append(comment)
        
        if filter_type == 'HTTPBasicFilter':
            auth = ET.SubElement(section, "authentication-basic")
            auth.set("username", filter_config.get('username', '{{basic-username}}'))
            auth.set("password", filter_config.get('password', '{{basic-password}}'))
            if filter_config.get('realm'):
                auth.set("realm", filter_config['realm'])
        
        elif filter_type in ['OAuth2Filter', 'JWTFilter']:
            jwt = ET.SubElement(section, "validate-jwt")
            jwt.set("header-name", filter_config.get('headerName', 'Authorization'))
            jwt.set("require-scheme", "Bearer")
            
            # Add signing keys
            keys = ET.SubElement(jwt, "issuer-signing-keys")
            key = ET.SubElement(keys, "key")
            key.text = filter_config.get('signingKey', '{{jwt-signing-key}}')
            
            # Add audiences
            if filter_config.get('audience'):
                audiences = ET.SubElement(jwt, "audiences")
                audience = ET.SubElement(audiences, "audience")
                audience.text = filter_config['audience']
            
            # Add issuers
            if filter_config.get('issuer'):
                issuers = ET.SubElement(jwt, "issuers")
                issuer = ET.SubElement(issuers, "issuer")
                issuer.text = filter_config['issuer']
        
        elif filter_type == 'XMLThreatProtectionFilter':
            threat = ET.SubElement(section, "xml-threat-detection")
            if filter_config.get('maxDepth'):
                threat.set("maximum-depth", str(filter_config['maxDepth']))
            if filter_config.get('maxNodeCount'):
                threat.set("maximum-node-count", str(filter_config['maxNodeCount']))
            if filter_config.get('maxAttributeCount'):
                threat.set("maximum-attribute-count", str(filter_config['maxAttributeCount']))
            if filter_config.get('maxNamespaceCount'):
                threat.set("maximum-namespace-count", str(filter_config['maxNamespaceCount']))
            if filter_config.get('detectExternalEntities') is not None:
                threat.set("enable-external-entity-detection", str(filter_config['detectExternalEntities']).lower())
        
        elif filter_type == 'ThrottlingFilter':
            rate = ET.SubElement(section, "rate-limit")
            rate.set("calls", str(filter_config.get('maxRequests', '100')))
            rate.set("renewal-period", str(filter_config.get('timeWindow', '60')))
            if filter_config.get('keyExpression'):
                rate.set("counter-key", filter_config['keyExpression'])
            else:
                rate.set("counter-key", "@(context.Request.IpAddress)")
        
        elif filter_type == 'IPWhitelistFilter':
            ip_filter = ET.SubElement(section, "ip-filter")
            ip_filter.set("action", "allow")
            
            allowed_ips = filter_config.get('allowedIPs', ['127.0.0.1'])
            if isinstance(allowed_ips, str):
                allowed_ips = [allowed_ips]
            
            for ip in allowed_ips:
                address = ET.SubElement(ip_filter, "address-range")
                if '/' in ip:  # CIDR notation
                    address.set("from", ip.split('/')[0])
                    address.set("to", ip.split('/')[0])  # Simplified for demo
                else:
                    address.set("from", ip)
                    address.set("to", ip)
        
        elif filter_type == 'ConnectToURLFilter':
            backend = ET.SubElement(section, "set-backend-service")
            backend.set("base-url", filter_config.get('url', 'https://api.backend.com'))
            if filter_config.get('timeout'):
                backend.set("timeout", str(filter_config['timeout']))
        
        elif filter_type == 'XSLTransformFilter':
            xsl = ET.SubElement(section, "xsl-transform")
            xsl_content = filter_config.get('xslContent', '')
            if xsl_content:
                # Add CDATA section for XSL content
                xsl.text = xsl_content
        
        elif filter_type == 'JSONTransformFilter':
            json_xml = ET.SubElement(section, "json-to-xml")
            if filter_config.get('rootElement'):
                json_xml.set("root-element-name", filter_config['rootElement'])
            if filter_config.get('namespaceUri'):
                json_xml.set("namespace-uri", filter_config['namespaceUri'])
        
        elif filter_type == 'XMLToJSONFilter':
            xml_json = ET.SubElement(section, "xml-to-json")
            if filter_config.get('namespaceHandling'):
                xml_json.set("namespace-handling", filter_config['namespaceHandling'])
        
        elif filter_type == 'MonitoringFilter':
            log = ET.SubElement(section, "log-to-eventhub")
            log.set("logger-id", filter_config.get('logLevel', 'api-logger').lower())
            
            # Add message content
            message = ET.SubElement(log, "message")
            message.text = """@{
                var requestLine = string.Format("{0} {1} HTTP/{2}\\r\\n",
                    context.Request.Method,
                    context.Request.Url.Path + context.Request.Url.QueryString,
                    context.Request.HttpVersion
                );
                return requestLine;
            }"""
        
        elif filter_type == 'MetricsFilter':
            metric = ET.SubElement(section, "emit-metric")
            metric.set("name", filter_config.get('metricName', 'api_requests'))
            
            value = ET.SubElement(metric, "value")
            value.text = filter_config.get('metricValue', '1')
        
        else:
            # Generic policy for other supported types
            policy_name = self.supported_filters[filter_type]['policy']
            policy_elem = ET.SubElement(section, policy_name)
            
            # Add basic configuration as attributes
            for key, value in filter_config.items():
                if key not in ['name', 'type'] and isinstance(value, (str, int, float, bool)):
                    policy_elem.set(key.replace('_', '-'), str(value))

    def _prettify_xml(self, element: ET.Element) -> str:
        """Return a pretty-printed XML string for the Element."""
        rough_string = ET.tostring(element, 'unicode')
        reparsed = minidom.parseString(rough_string)
        
        # Get pretty printed XML and clean up
        pretty = reparsed.toprettyxml(indent="  ")
        
        # Remove empty lines and fix formatting
        lines = [line for line in pretty.split('\n') if line.strip()]
        
        # Remove XML declaration as APIM doesn't need it
        if lines and lines[0].startswith('<?xml'):
            lines = lines[1:]
        
        return '\n'.join(lines)

    def convert_yaml_to_xml(self, yaml_file_path: str, output_xml_path: Optional[str] = None) -> Dict[str, Any]:
        """
        Convert Axway FilterCircuit YAML file directly to Azure APIM XML policy.
        
        Args:
            yaml_file_path: Path to the Axway FilterCircuit YAML file
            output_xml_path: Optional path to save the converted XML policy
            
        Returns:
            Conversion result with statistics and XML data
        """
        try:
            # Load YAML file
            with open(yaml_file_path, 'r', encoding='utf-8') as file:
                circuit_data = yaml.safe_load(file)
            
            logger.info(f"Loaded FilterCircuit from: {yaml_file_path}")
            
            # Convert to XML
            xml_content = self.convert_filter_circuit_to_xml(circuit_data)
            
            # Save output if path provided
            if output_xml_path:
                with open(output_xml_path, 'w', encoding='utf-8') as output_file:
                    output_file.write(xml_content)
                logger.info(f"Saved XML policy to: {output_xml_path}")
            
            # Calculate statistics
            filters = circuit_data.get('filters', [])
            converted = sum(1 for f in filters if f.get('type') in self.supported_filters)
            externalized = len(filters) - converted
            success_rate = f"{(converted / len(filters)) * 100:.0f}%" if filters else "0%"
            
            return {
                'success': True,
                'xml_policy': xml_content,
                'statistics': {
                    'total_filters': len(filters),
                    'converted_filters': converted,
                    'externalized_filters': externalized,
                    'success_rate': success_rate
                },
                'message': f"Successfully converted FilterCircuit to XML policy"
            }
            
        except FileNotFoundError:
            error_msg = f"YAML file not found: {yaml_file_path}"
            logger.error(error_msg)
            return {'success': False, 'error': error_msg}
        
        except yaml.YAMLError as e:
            error_msg = f"YAML parsing error: {str(e)}"
            logger.error(error_msg)
            return {'success': False, 'error': error_msg}
        
        except Exception as e:
            error_msg = f"Conversion error: {str(e)}"
            logger.error(error_msg)
            return {'success': False, 'error': error_msg}

    def batch_convert_to_xml(self, input_directory: str, output_directory: str) -> Dict[str, Any]:
        """
        Convert all FilterCircuit YAML files directly to XML format.
        
        Args:
            input_directory: Directory containing Axway FilterCircuit YAML files
            output_directory: Directory to save converted XML policies
            
        Returns:
            Batch conversion results with overall statistics
        """
        if not os.path.exists(input_directory):
            return {'success': False, 'error': f"Input directory not found: {input_directory}"}
        
        os.makedirs(output_directory, exist_ok=True)
        
        yaml_files = [f for f in os.listdir(input_directory) if f.endswith(('.yaml', '.yml'))]
        
        if not yaml_files:
            return {'success': False, 'error': f"No YAML files found in: {input_directory}"}
        
        results = []
        total_success = 0
        
        for yaml_file in yaml_files:
            input_path = os.path.join(input_directory, yaml_file)
            xml_filename = yaml_file.replace('.yaml', '.xml').replace('.yml', '.xml')
            xml_path = os.path.join(output_directory, xml_filename)
            
            result = self.convert_yaml_to_xml(input_path, xml_path)
            results.append({
                'file': yaml_file,
                'xml_output': xml_filename,
                'success': result['success'],
                'statistics': result.get('statistics'),
                'error': result.get('error')
            })
            
            if result['success']:
                total_success += 1
        
        return {
            'success': True,
            'total_files': len(yaml_files),
            'successful_conversions': total_success,
            'batch_success_rate': f"{(total_success / len(yaml_files)) * 100:.1f}%",
            'results': results
        }

def main():
    """Main entry point for the strategic converter."""
    parser = argparse.ArgumentParser(
        description="Strategic Axway FilterCircuit to Azure APIM XML Converter",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python strategic_filter_converter_xml.py --matrix
  python strategic_filter_converter_xml.py --convert policy.yaml --xml policy.xml
  python strategic_filter_converter_xml.py --batch input_dir/ xml_output_dir/
        """
    )
    
    parser.add_argument('--version', action='version', version='Strategic XML Converter 1.1.0')
    parser.add_argument('--matrix', action='store_true', help='Display strategic filter matrix')
    parser.add_argument('--convert', metavar='FILE', help='Convert single YAML file to XML')
    parser.add_argument('--xml', metavar='FILE', help='Output XML file')
    parser.add_argument('--batch', metavar='DIR', help='Batch convert directory of YAML files to XML')
    parser.add_argument('--output', metavar='DIR', help='Output directory for XML policies')
    parser.add_argument('--verbose', '-v', action='store_true', help='Verbose output')
    
    args = parser.parse_args()
    
    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)
    
    converter = StrategicFilterConverter()
    
    if args.matrix:
        converter.display_strategic_matrix()
        return
    
    if args.convert:
        xml_path = args.xml or f"{os.path.splitext(args.convert)[0]}.xml"
        result = converter.convert_yaml_to_xml(args.convert, xml_path)
        
        if result['success']:
            print(f"✅ Strategic FilterCircuit conversion completed!")
            print(f"🏗️  Architectural Transformation: Imperative Filter Network → Azure APIM XML Policy")
            print(f"📊 Strategic Analysis:")
            print(f"  - Circuit: {os.path.basename(args.convert)}")
            stats = result['statistics']
            print(f"  - Total filters: {stats['total_filters']}")
            print(f"  - Converted filters: {stats['converted_filters']}")
            print(f"  - Success rate: {stats['success_rate']}")
            print(f"  - Externalized filters: {stats['externalized_filters']}")
            print(f"📄 XML Policy: {xml_path}")
        else:
            print(f"❌ Conversion failed: {result['error']}")
            sys.exit(1)
    
    elif args.batch:
        output_dir = args.output or f"{args.batch}_xml_output"
        result = converter.batch_convert_to_xml(args.batch, output_dir)
        
        if result['success']:
            print(f"✅ Batch XML conversion completed!")
            print(f"📊 Results: {result['successful_conversions']}/{result['total_files']} files converted")
            print(f"📈 Success rate: {result['batch_success_rate']}")
            print(f"📁 XML policies saved to: {output_dir}")
        else:
            print(f"❌ Batch conversion failed: {result['error']}")
            sys.exit(1)
    
    else:
        # Default action - show matrix
        converter.display_strategic_matrix()
        print("\n🚀 Strategic XML Converter Ready!")
        print("Use --help for available commands")

if __name__ == "__main__":
    main()
