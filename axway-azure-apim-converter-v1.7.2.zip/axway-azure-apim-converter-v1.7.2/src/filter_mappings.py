#!/usr/bin/env python3
"""
Filter Mappings Configuration

Comprehensive mapping definitions for Axway FilterCircuit to Azure APIM conversions.
Defines transformation patterns, complexity levels, and enterprise migration strategies.

Author: Enterprise API Team
Version: 1.0.0
License: MIT
"""

import yaml
import json
from typing import Dict, List, Any, Optional
from enum import Enum

class FilterComplexity(Enum):
    """Filter conversion complexity levels."""
    SIMPLE = "Simple"
    MODERATE = "Moderate"
    COMPLEX = "Complex"
    CUSTOM = "Custom"

class PolicySection(Enum):
    """APIM policy sections."""
    INBOUND = "inbound"
    BACKEND = "backend"
    OUTBOUND = "outbound"
    ON_ERROR = "on-error"

class FilterMappings:
    """
    Central repository for all Axway to APIM filter mappings.
    
    Provides comprehensive mapping data for strategic converter operations
    including conversion patterns, validation rules, and deployment guidance.
    """
    
    def __init__(self):
        """Initialize filter mappings with comprehensive enterprise data."""
        self.version = "1.0.0"
        
        # Core filter mappings
        self.filter_mappings = {
            # Authentication & Identity Filters
            'HTTPBasicFilter': {
                'apim_policy': 'authentication-basic',
                'complexity': FilterComplexity.SIMPLE,
                'section': PolicySection.INBOUND,
                'description': 'HTTP Basic Authentication',
                'conversion_pattern': 'direct_mapping',
                'enterprise_notes': 'Standard authentication mechanism',
                'migration_effort_hours': 2,
                'testing_requirements': ['unit_test', 'integration_test'],
                'dependencies': [],
                'configuration_mapping': {
                    'username': 'username',
                    'password': 'password',
                    'realm': 'realm'
                }
            },
            
            'OAuth2Filter': {
                'apim_policy': 'validate-jwt',
                'complexity': FilterComplexity.MODERATE,
                'section': PolicySection.INBOUND,
                'description': 'OAuth 2.0 Token Validation',
                'conversion_pattern': 'enhanced_mapping',
                'enterprise_notes': 'Requires JWT configuration in APIM',
                'migration_effort_hours': 8,
                'testing_requirements': ['unit_test', 'integration_test', 'security_test'],
                'dependencies': ['jwt_signing_keys', 'token_issuer'],
                'configuration_mapping': {
                    'tokenEndpoint': 'issuer-signing-keys.key.value',
                    'clientId': 'audiences.audience',
                    'clientSecret': '{{oauth-client-secret}}',
                    'scope': 'required-claims.claim'
                }
            },
            
            'JWTFilter': {
                'apim_policy': 'validate-jwt',
                'complexity': FilterComplexity.MODERATE,
                'section': PolicySection.INBOUND,
                'description': 'JWT Token Validation',
                'conversion_pattern': 'enhanced_mapping',
                'enterprise_notes': 'Direct JWT validation with configurable claims',
                'migration_effort_hours': 6,
                'testing_requirements': ['unit_test', 'integration_test', 'security_test'],
                'dependencies': ['jwt_signing_keys'],
                'configuration_mapping': {
                    'signingKey': 'issuer-signing-keys.key.value',
                    'issuer': 'issuers.issuer',
                    'audience': 'audiences.audience',
                    'claims': 'required-claims'
                }
            },
            
            'LDAPFilter': {
                'apim_policy': 'authentication-basic',
                'complexity': FilterComplexity.COMPLEX,
                'section': PolicySection.INBOUND,
                'description': 'LDAP Authentication',
                'conversion_pattern': 'custom_policy',
                'enterprise_notes': 'Requires Azure AD integration or custom policy',
                'migration_effort_hours': 16,
                'testing_requirements': ['unit_test', 'integration_test', 'security_test', 'load_test'],
                'dependencies': ['azure_ad', 'ldap_connector'],
                'configuration_mapping': {
                    'ldapServer': '{{ldap-server}}',
                    'baseDN': '{{ldap-base-dn}}',
                    'userFilter': '{{ldap-user-filter}}'
                }
            },
            
            'SAMLFilter': {
                'apim_policy': 'validate-jwt',
                'complexity': FilterComplexity.COMPLEX,
                'section': PolicySection.INBOUND,
                'description': 'SAML Token Validation',
                'conversion_pattern': 'custom_policy',
                'enterprise_notes': 'Requires SAML to JWT transformation',
                'migration_effort_hours': 20,
                'testing_requirements': ['unit_test', 'integration_test', 'security_test', 'compliance_test'],
                'dependencies': ['saml_idp', 'jwt_converter'],
                'configuration_mapping': {
                    'idpMetadata': '{{saml-idp-metadata}}',
                    'spEntityId': '{{saml-sp-entity-id}}',
                    'certificateAlias': '{{saml-certificate}}'
                }
            },
            
            # Security & Protection Filters
            'XMLThreatProtectionFilter': {
                'apim_policy': 'xml-threat-detection',
                'complexity': FilterComplexity.COMPLEX,
                'section': PolicySection.INBOUND,
                'description': 'XML Threat Protection',
                'conversion_pattern': 'enhanced_mapping',
                'enterprise_notes': 'Advanced XML security validation',
                'migration_effort_hours': 10,
                'testing_requirements': ['unit_test', 'security_test', 'penetration_test'],
                'dependencies': [],
                'configuration_mapping': {
                    'maxDepth': 'maximum-depth',
                    'maxNodeCount': 'maximum-node-count',
                    'maxAttributeCount': 'maximum-attribute-count',
                    'maxNamespaceCount': 'maximum-namespace-count',
                    'detectExternalEntities': 'enable-external-entity-detection'
                }
            },
            
            'JSONThreatProtectionFilter': {
                'apim_policy': 'json-threat-detection',
                'complexity': FilterComplexity.COMPLEX,
                'section': PolicySection.INBOUND,
                'description': 'JSON Threat Protection',
                'conversion_pattern': 'enhanced_mapping',
                'enterprise_notes': 'JSON payload security validation',
                'migration_effort_hours': 8,
                'testing_requirements': ['unit_test', 'security_test', 'penetration_test'],
                'dependencies': [],
                'configuration_mapping': {
                    'maxDepth': 'maximum-depth',
                    'maxArrayElements': 'maximum-array-elements',
                    'maxObjectProperties': 'maximum-object-properties',
                    'maxStringLength': 'maximum-string-length'
                }
            },
            
            'IPWhitelistFilter': {
                'apim_policy': 'ip-filter',
                'complexity': FilterComplexity.SIMPLE,
                'section': PolicySection.INBOUND,
                'description': 'IP Address Whitelist',
                'conversion_pattern': 'direct_mapping',
                'enterprise_notes': 'Network access control',
                'migration_effort_hours': 3,
                'testing_requirements': ['unit_test', 'integration_test'],
                'dependencies': [],
                'configuration_mapping': {
                    'allowedIPs': 'address-range',
                    'action': 'action:allow'
                }
            },
            
            'IPBlacklistFilter': {
                'apim_policy': 'ip-filter',
                'complexity': FilterComplexity.SIMPLE,
                'section': PolicySection.INBOUND,
                'description': 'IP Address Blacklist',
                'conversion_pattern': 'direct_mapping',
                'enterprise_notes': 'Network access control',
                'migration_effort_hours': 3,
                'testing_requirements': ['unit_test', 'integration_test'],
                'dependencies': [],
                'configuration_mapping': {
                    'blockedIPs': 'address-range',
                    'action': 'action:forbid'
                }
            },
            
            # Rate Limiting & Throttling Filters
            'ThrottlingFilter': {
                'apim_policy': 'rate-limit',
                'complexity': FilterComplexity.SIMPLE,
                'section': PolicySection.INBOUND,
                'description': 'Request Rate Limiting',
                'conversion_pattern': 'direct_mapping',
                'enterprise_notes': 'API traffic control',
                'migration_effort_hours': 4,
                'testing_requirements': ['unit_test', 'load_test'],
                'dependencies': [],
                'configuration_mapping': {
                    'maxRequests': 'calls',
                    'timeWindow': 'renewal-period',
                    'keyExpression': 'counter-key'
                }
            },
            
            'ConcurrencyFilter': {
                'apim_policy': 'concurrency-limit',
                'complexity': FilterComplexity.MODERATE,
                'section': PolicySection.INBOUND,
                'description': 'Concurrent Request Limiting',
                'conversion_pattern': 'direct_mapping',
                'enterprise_notes': 'Concurrent connection control',
                'migration_effort_hours': 6,
                'testing_requirements': ['unit_test', 'load_test', 'stress_test'],
                'dependencies': [],
                'configuration_mapping': {
                    'maxConcurrentRequests': 'max-concurrency',
                    'queueLength': 'queue-length'
                }
            },
            
            'QuotaFilter': {
                'apim_policy': 'quota',
                'complexity': FilterComplexity.SIMPLE,
                'section': PolicySection.INBOUND,
                'description': 'API Usage Quota',
                'conversion_pattern': 'direct_mapping',
                'enterprise_notes': 'API consumption limits',
                'migration_effort_hours': 5,
                'testing_requirements': ['unit_test', 'integration_test', 'billing_test'],
                'dependencies': [],
                'configuration_mapping': {
                    'quotaLimit': 'calls',
                    'quotaPeriod': 'renewal-period',
                    'quotaCounter': 'counter-key'
                }
            },
            
            # Content Transformation Filters
            'XSLTransformFilter': {
                'apim_policy': 'xsl-transform',
                'complexity': FilterComplexity.MODERATE,
                'section': PolicySection.INBOUND,
                'description': 'XSL Transformation',
                'conversion_pattern': 'content_migration',
                'enterprise_notes': 'XML content transformation',
                'migration_effort_hours': 12,
                'testing_requirements': ['unit_test', 'integration_test', 'performance_test'],
                'dependencies': ['xsl_templates'],
                'configuration_mapping': {
                    'xslContent': 'xsl-content',
                    'xslTemplate': 'template',
                    'parameters': 'parameters'
                }
            },
            
            'JSONTransformFilter': {
                'apim_policy': 'json-to-xml',
                'complexity': FilterComplexity.MODERATE,
                'section': PolicySection.INBOUND,
                'description': 'JSON to XML Transformation',
                'conversion_pattern': 'direct_mapping',
                'enterprise_notes': 'Content format conversion',
                'migration_effort_hours': 8,
                'testing_requirements': ['unit_test', 'integration_test'],
                'dependencies': [],
                'configuration_mapping': {
                    'rootElement': 'root-element-name',
                    'namespaceUri': 'namespace-uri'
                }
            },
            
            'XMLToJSONFilter': {
                'apim_policy': 'xml-to-json',
                'complexity': FilterComplexity.MODERATE,
                'section': PolicySection.INBOUND,
                'description': 'XML to JSON Transformation',
                'conversion_pattern': 'direct_mapping',
                'enterprise_notes': 'Content format conversion',
                'migration_effort_hours': 8,
                'testing_requirements': ['unit_test', 'integration_test'],
                'dependencies': [],
                'configuration_mapping': {
                    'namespaceHandling': 'namespace-handling',
                    'arrayDetection': 'array-detection'
                }
            },
            
            'ContentModifyFilter': {
                'apim_policy': 'set-body',
                'complexity': FilterComplexity.SIMPLE,
                'section': PolicySection.INBOUND,
                'description': 'Content Body Modification',
                'conversion_pattern': 'direct_mapping',
                'enterprise_notes': 'Request/response body manipulation',
                'migration_effort_hours': 4,
                'testing_requirements': ['unit_test', 'integration_test'],
                'dependencies': [],
                'configuration_mapping': {
                    'content': 'template',
                    'contentType': 'content-type'
                }
            },
            
            # Routing & Backend Filters
            'ConnectToURLFilter': {
                'apim_policy': 'set-backend-service',
                'complexity': FilterComplexity.SIMPLE,
                'section': PolicySection.BACKEND,
                'description': 'Backend Service Connection',
                'conversion_pattern': 'direct_mapping',
                'enterprise_notes': 'Backend service routing',
                'migration_effort_hours': 3,
                'testing_requirements': ['unit_test', 'integration_test'],
                'dependencies': [],
                'configuration_mapping': {
                    'url': 'base-url',
                    'timeout': 'timeout',
                    'connectionTimeout': 'connection-timeout'
                }
            },
            
            'LoadBalancingFilter': {
                'apim_policy': 'set-backend-service',
                'complexity': FilterComplexity.MODERATE,
                'section': PolicySection.BACKEND,
                'description': 'Load Balancing',
                'conversion_pattern': 'custom_policy',
                'enterprise_notes': 'Requires Azure Load Balancer or custom logic',
                'migration_effort_hours': 16,
                'testing_requirements': ['unit_test', 'integration_test', 'load_test'],
                'dependencies': ['load_balancer_config'],
                'configuration_mapping': {
                    'algorithm': '{{lb-algorithm}}',
                    'healthCheck': '{{health-check-url}}',
                    'servers': '{{backend-servers}}'
                }
            },
            
            'FailoverFilter': {
                'apim_policy': 'retry',
                'complexity': FilterComplexity.MODERATE,
                'section': PolicySection.BACKEND,
                'description': 'Failover and Retry Logic',
                'conversion_pattern': 'enhanced_mapping',
                'enterprise_notes': 'Automatic failover with retry policies',
                'migration_effort_hours': 10,
                'testing_requirements': ['unit_test', 'integration_test', 'failover_test'],
                'dependencies': [],
                'configuration_mapping': {
                    'retryCount': 'count',
                    'retryInterval': 'interval',
                    'backoffMultiplier': 'delta'
                }
            },
            
            # Monitoring & Analytics Filters
            'MonitoringFilter': {
                'apim_policy': 'log-to-eventhub',
                'complexity': FilterComplexity.SIMPLE,
                'section': PolicySection.OUTBOUND,
                'description': 'Request/Response Monitoring',
                'conversion_pattern': 'enhanced_mapping',
                'enterprise_notes': 'Enterprise monitoring and analytics',
                'migration_effort_hours': 6,
                'testing_requirements': ['unit_test', 'integration_test', 'monitoring_test'],
                'dependencies': ['event_hub', 'log_analytics'],
                'configuration_mapping': {
                    'logLevel': 'logger-id',
                    'includeHeaders': '{{include-headers}}',
                    'includeBody': '{{include-body}}'
                }
            },
            
            'MetricsFilter': {
                'apim_policy': 'emit-metric',
                'complexity': FilterComplexity.SIMPLE,
                'section': PolicySection.OUTBOUND,
                'description': 'Custom Metrics Collection',
                'conversion_pattern': 'direct_mapping',
                'enterprise_notes': 'Business metrics and KPIs',
                'migration_effort_hours': 4,
                'testing_requirements': ['unit_test', 'integration_test'],
                'dependencies': ['metrics_collection'],
                'configuration_mapping': {
                    'metricName': 'name',
                    'metricValue': 'value',
                    'metricDimensions': 'dimensions'
                }
            },
            
            # Response Processing Filters
            'ResponseCacheFilter': {
                'apim_policy': 'cache-lookup-value',
                'complexity': FilterComplexity.SIMPLE,
                'section': PolicySection.INBOUND,
                'description': 'Response Caching',
                'conversion_pattern': 'dual_policy',
                'enterprise_notes': 'Performance optimization through caching',
                'migration_effort_hours': 8,
                'testing_requirements': ['unit_test', 'performance_test', 'cache_test'],
                'dependencies': ['cache_configuration'],
                'configuration_mapping': {
                    'cacheDuration': 'duration',
                    'cacheKey': 'key',
                    'varyByHeaders': 'vary-by'
                }
            },
            
            'CompressionFilter': {
                'apim_policy': 'compression',
                'complexity': FilterComplexity.SIMPLE,
                'section': PolicySection.OUTBOUND,
                'description': 'Response Compression',
                'conversion_pattern': 'direct_mapping',
                'enterprise_notes': 'Bandwidth optimization',
                'migration_effort_hours': 2,
                'testing_requirements': ['unit_test', 'performance_test'],
                'dependencies': [],
                'configuration_mapping': {
                    'compressionLevel': 'level',
                    'compressionTypes': 'content-types'
                }
            }
        }
        
        # Enterprise migration patterns
        self.migration_patterns = {
            'direct_mapping': {
                'description': 'One-to-one filter to policy mapping',
                'automation_level': 'high',
                'manual_effort': 'minimal',
                'risk_level': 'low'
            },
            'enhanced_mapping': {
                'description': 'Filter with additional APIM configuration',
                'automation_level': 'moderate',
                'manual_effort': 'moderate',
                'risk_level': 'medium'
            },
            'content_migration': {
                'description': 'Content transformation with template migration',
                'automation_level': 'low',
                'manual_effort': 'high',
                'risk_level': 'medium'
            },
            'custom_policy': {
                'description': 'Requires custom APIM policy development',
                'automation_level': 'minimal',
                'manual_effort': 'high',
                'risk_level': 'high'
            },
            'dual_policy': {
                'description': 'Requires multiple APIM policies for complete functionality',
                'automation_level': 'moderate',
                'manual_effort': 'moderate',
                'risk_level': 'medium'
            }
        }

    def get_filter_mapping(self, filter_name: str) -> Optional[Dict[str, Any]]:
        """
        Get mapping information for a specific filter.
        
        Args:
            filter_name: Name of the Axway filter
            
        Returns:
            Mapping information or None if not found
        """
        return self.filter_mappings.get(filter_name)

    def get_supported_filters(self) -> List[str]:
        """Get list of all supported filter names."""
        return list(self.filter_mappings.keys())

    def get_filters_by_complexity(self, complexity: FilterComplexity) -> List[str]:
        """
        Get filters by complexity level.
        
        Args:
            complexity: FilterComplexity enum value
            
        Returns:
            List of filter names with the specified complexity
        """
        return [
            filter_name for filter_name, mapping in self.filter_mappings.items()
            if mapping['complexity'] == complexity
        ]

    def get_filters_by_section(self, section: PolicySection) -> List[str]:
        """
        Get filters by APIM policy section.
        
        Args:
            section: PolicySection enum value
            
        Returns:
            List of filter names for the specified section
        """
        return [
            filter_name for filter_name, mapping in self.filter_mappings.items()
            if mapping['section'] == section
        ]

    def calculate_migration_effort(self, filter_list: List[str]) -> Dict[str, Any]:
        """
        Calculate total migration effort for a list of filters.
        
        Args:
            filter_list: List of filter names
            
        Returns:
            Migration effort analysis
        """
        total_hours = 0
        complexity_breakdown = {complexity.value: 0 for complexity in FilterComplexity}
        testing_requirements = set()
        dependencies = set()
        
        for filter_name in filter_list:
            mapping = self.get_filter_mapping(filter_name)
            if mapping:
                total_hours += mapping['migration_effort_hours']
                complexity_breakdown[mapping['complexity'].value] += 1
                testing_requirements.update(mapping['testing_requirements'])
                dependencies.update(mapping['dependencies'])
        
        return {
            'total_effort_hours': total_hours,
            'total_effort_days': total_hours / 8,  # Assuming 8-hour work days
            'complexity_breakdown': complexity_breakdown,
            'testing_requirements': list(testing_requirements),
            'dependencies': list(dependencies),
            'filters_analyzed': len(filter_list),
            'supported_filters': len([f for f in filter_list if f in self.filter_mappings])
        }

    def get_enterprise_recommendations(self, filter_list: List[str]) -> Dict[str, Any]:
        """
        Get enterprise migration recommendations for a filter list.
        
        Args:
            filter_list: List of filter names
            
        Returns:
            Enterprise recommendations and strategy
        """
        effort_analysis = self.calculate_migration_effort(filter_list)
        
        recommendations = {
            'migration_approach': 'phased',
            'priority_phases': [],
            'risk_mitigation': [],
            'resource_requirements': {},
            'timeline_estimate': {}
        }
        
        # Determine migration approach based on complexity
        complex_filters = self.get_filters_by_complexity(FilterComplexity.COMPLEX)
        custom_filters = [f for f in filter_list if f not in self.filter_mappings]
        
        if len(complex_filters) > 5 or len(custom_filters) > 2:
            recommendations['migration_approach'] = 'incremental'
            recommendations['risk_mitigation'].append('Consider parallel running of legacy and new systems')
        
        # Phase planning
        simple_filters = [f for f in filter_list if f in self.get_filters_by_complexity(FilterComplexity.SIMPLE)]
        moderate_filters = [f for f in filter_list if f in self.get_filters_by_complexity(FilterComplexity.MODERATE)]
        
        if simple_filters:
            recommendations['priority_phases'].append({
                'phase': 1,
                'description': 'Simple filters migration',
                'filters': simple_filters,
                'estimated_weeks': len(simple_filters) / 5
            })
        
        if moderate_filters:
            recommendations['priority_phases'].append({
                'phase': 2,
                'description': 'Moderate complexity filters',
                'filters': moderate_filters,
                'estimated_weeks': len(moderate_filters) / 3
            })
        
        if complex_filters:
            recommendations['priority_phases'].append({
                'phase': 3,
                'description': 'Complex filters and custom policies',
                'filters': complex_filters,
                'estimated_weeks': len(complex_filters) / 1.5
            })
        
        # Resource requirements
        recommendations['resource_requirements'] = {
            'api_architects': 1 + (len(complex_filters) // 3),
            'developers': 2 + (len(moderate_filters) // 5),
            'testers': 1 + (len(filter_list) // 10),
            'devops_engineers': 1
        }
        
        return recommendations

    def export_mappings_yaml(self, output_path: str):
        """
        Export filter mappings to YAML file.
        
        Args:
            output_path: Path to save the YAML file
        """
        # Convert enums to strings for YAML serialization
        yaml_data = {}
        for filter_name, mapping in self.filter_mappings.items():
            yaml_mapping = mapping.copy()
            yaml_mapping['complexity'] = mapping['complexity'].value
            yaml_mapping['section'] = mapping['section'].value
            yaml_data[filter_name] = yaml_mapping
        
        export_data = {
            'version': self.version,
            'filter_mappings': yaml_data,
            'migration_patterns': self.migration_patterns
        }
        
        with open(output_path, 'w', encoding='utf-8') as file:
            yaml.dump(export_data, file, default_flow_style=False, sort_keys=False)

    def export_mappings_json(self, output_path: str):
        """
        Export filter mappings to JSON file.
        
        Args:
            output_path: Path to save the JSON file
        """
        # Convert enums to strings for JSON serialization
        json_data = {}
        for filter_name, mapping in self.filter_mappings.items():
            json_mapping = mapping.copy()
            json_mapping['complexity'] = mapping['complexity'].value
            json_mapping['section'] = mapping['section'].value
            json_data[filter_name] = json_mapping
        
        export_data = {
            'version': self.version,
            'filter_mappings': json_data,
            'migration_patterns': self.migration_patterns
        }
        
        with open(output_path, 'w', encoding='utf-8') as file:
            json.dump(export_data, file, indent=2, ensure_ascii=False)

def main():
    """Main function for testing filter mappings."""
    mappings = FilterMappings()
    
    # Example usage
    print("=== FILTER MAPPINGS DEMONSTRATION ===")
    print(f"Total supported filters: {len(mappings.get_supported_filters())}")
    print(f"Simple filters: {len(mappings.get_filters_by_complexity(FilterComplexity.SIMPLE))}")
    print(f"Moderate filters: {len(mappings.get_filters_by_complexity(FilterComplexity.MODERATE))}")
    print(f"Complex filters: {len(mappings.get_filters_by_complexity(FilterComplexity.COMPLEX))}")
    
    # Sample migration analysis
    sample_filters = ['HTTPBasicFilter', 'OAuth2Filter', 'XMLThreatProtectionFilter', 'ThrottlingFilter']
    effort = mappings.calculate_migration_effort(sample_filters)
    print(f"\nSample migration effort for {sample_filters}:")
    print(f"Total effort: {effort['total_effort_days']:.1f} days")
    print(f"Testing requirements: {effort['testing_requirements']}")

if __name__ == "__main__":
    main()
