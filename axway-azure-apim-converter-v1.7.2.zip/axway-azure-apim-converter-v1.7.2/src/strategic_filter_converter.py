#!/usr/bin/env python3
"""
Strategic Axway FilterCircuit to Azure APIM Converter

Demo converter transforming imperative Axway FilterCircuit networks 
into declarative Azure APIM policy pipelines.

Author: Enterprise API Team
Version: 1.0.0
License: MIT
"""

import yaml
import json
import argparse
import sys
import os
from typing import Dict, List, Any, Tuple, Optional
from datetime import datetime
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class StrategicFilterConverter:
    """
    Strategic converter for Axway FilterCircuit to Azure APIM transformation.
    
    Implements Demo conversion patterns for 25+ filter types with
    comprehensive validation and strategic assessment capabilities.
    """
    
    def __init__(self):
        """Initialize the strategic converter with enterprise mappings."""
        self.version = "1.1.0"
        self.supported_filters = {
            # Authentication & Identity (5 filters)
            'HTTPBasicFilter': {'policy': 'authentication-basic', 'complexity': 'Simple'},
            'OAuth2Filter': {'policy': 'validate-jwt', 'complexity': 'Moderate'},
            'JWTFilter': {'policy': 'validate-jwt', 'complexity': 'Moderate'},
            'LDAPFilter': {'policy': 'authentication-basic', 'complexity': 'Complex'},
            'SAMLFilter': {'policy': 'validate-jwt', 'complexity': 'Complex'},
            
            # Security & Protection (6 filters)
            'XMLThreatProtectionFilter': {'policy': 'xml-threat-detection', 'complexity': 'Complex'},
            'JSONThreatProtectionFilter': {'policy': 'json-threat-detection', 'complexity': 'Complex'},
            'IPWhitelistFilter': {'policy': 'ip-filter', 'complexity': 'Simple'},
            'IPBlacklistFilter': {'policy': 'ip-filter', 'complexity': 'Simple'},
            'SQLInjectionFilter': {'policy': 'sql-threat-detection', 'complexity': 'Moderate'},
            'XSSProtectionFilter': {'policy': 'xss-protection', 'complexity': 'Moderate'},
            
            # Rate Limiting & Throttling (3 filters)
            'ThrottlingFilter': {'policy': 'rate-limit', 'complexity': 'Simple'},
            'ConcurrencyFilter': {'policy': 'concurrency-limit', 'complexity': 'Moderate'},
            'QuotaFilter': {'policy': 'quota', 'complexity': 'Simple'},
            
            # Content Transformation (4 filters)
            'XSLTransformFilter': {'policy': 'xsl-transform', 'complexity': 'Moderate'},
            'JSONTransformFilter': {'policy': 'json-to-xml', 'complexity': 'Moderate'},
            'XMLToJSONFilter': {'policy': 'xml-to-json', 'complexity': 'Moderate'},
            'ContentModifyFilter': {'policy': 'set-body', 'complexity': 'Simple'},
            
            # Routing & Backend (3 filters)
            'ConnectToURLFilter': {'policy': 'set-backend-service', 'complexity': 'Simple'},
            'LoadBalancingFilter': {'policy': 'set-backend-service', 'complexity': 'Moderate'},
            'FailoverFilter': {'policy': 'retry', 'complexity': 'Moderate'},
            
            # Monitoring & Analytics (2 filters)
            'MonitoringFilter': {'policy': 'log-to-eventhub', 'complexity': 'Simple'},
            'MetricsFilter': {'policy': 'emit-metric', 'complexity': 'Simple'},
            
            # Response Processing (2 filters)
            'ResponseCacheFilter': {'policy': 'cache-lookup-value', 'complexity': 'Simple'},
            'CompressionFilter': {'policy': 'compression', 'complexity': 'Simple'}
        }
        
        # Strategic complexity mapping
        self.complexity_symbols = {
            'Simple': '🟢',
            'Moderate': '🟡', 
            'Complex': '🔴'
        }
        
        # Initialize statistics
        self.stats = {
            'total_circuits': 0,
            'total_filters': 0,
            'converted_filters': 0,
            'externalized_filters': 0,
            'success_rate': 0.0
        }

    def display_strategic_matrix(self):
        """Display the strategic filter transformation matrix."""
        print("\n" + "=" * 100)
        print("  STRATEGIC AXWAY FILTERCIRCUIT TO AZURE APIM - ENTERPRISE MIGRATION")
        print("=" * 100)
        print(f"Total Supported Filters: {len(self.supported_filters)}")
        print("Architecture: Imperative Filter Networks → Declarative Policy Pipelines")
        print()
        
        # Group filters by category
        categories = {
            'Authentication & Identity': [
                'HTTPBasicFilter', 'OAuth2Filter', 'JWTFilter', 'LDAPFilter', 'SAMLFilter'
            ],
            'Security & Protection': [
                'XMLThreatProtectionFilter', 'JSONThreatProtectionFilter', 'IPWhitelistFilter',
                'IPBlacklistFilter', 'SQLInjectionFilter', 'XSSProtectionFilter'
            ],
            'Rate Limiting & Throttling': [
                'ThrottlingFilter', 'ConcurrencyFilter', 'QuotaFilter'
            ],
            'Content Transformation': [
                'XSLTransformFilter', 'JSONTransformFilter', 'XMLToJSONFilter', 'ContentModifyFilter'
            ],
            'Routing & Backend': [
                'ConnectToURLFilter', 'LoadBalancingFilter', 'FailoverFilter'
            ],
            'Monitoring & Analytics': [
                'MonitoringFilter', 'MetricsFilter'
            ],
            'Response Processing': [
                'ResponseCacheFilter', 'CompressionFilter'
            ]
        }
        
        for category, filters in categories.items():
            print(f"📁 {category}:")
            for filter_name in filters:
                if filter_name in self.supported_filters:
                    policy_info = self.supported_filters[filter_name]
                    symbol = self.complexity_symbols[policy_info['complexity']]
                    print(f"   {filter_name:<30} → {policy_info['policy']:<20} ({symbol} {policy_info['complexity']})")
            print()

    def convert_filter(self, filter_name: str, filter_config: Dict[str, Any]) -> Dict[str, Any]:
        """
        Convert a single Axway filter to Azure APIM policy.
        
        Args:
            filter_name: Name of the Axway filter
            filter_config: Configuration of the filter
            
        Returns:
            Dictionary containing the converted APIM policy
        """
        if filter_name not in self.supported_filters:
            logger.warning(f"Filter '{filter_name}' not supported - externalizing")
            self.stats['externalized_filters'] += 1
            return {
                'type': 'externalized',
                'original_filter': filter_name,
                'note': f'Filter {filter_name} requires manual conversion',
                'suggestion': 'Consider implementing as custom policy or microservice'
            }
        
        mapping = self.supported_filters[filter_name]
        policy_type = mapping['policy']
        complexity = mapping['complexity']
        
        # Generate policy based on filter type
        if filter_name == 'HTTPBasicFilter':
            return self._convert_http_basic_filter(filter_config)
        elif filter_name in ['OAuth2Filter', 'JWTFilter']:
            return self._convert_jwt_filter(filter_config)
        elif filter_name == 'XMLThreatProtectionFilter':
            return self._convert_xml_threat_filter(filter_config)
        elif filter_name == 'ThrottlingFilter':
            return self._convert_throttling_filter(filter_config)
        elif filter_name == 'IPWhitelistFilter':
            return self._convert_ip_whitelist_filter(filter_config)
        elif filter_name == 'XSLTransformFilter':
            return self._convert_xsl_transform_filter(filter_config)
        elif filter_name == 'ConnectToURLFilter':
            return self._convert_connect_url_filter(filter_config)
        else:
            # Generic conversion for other supported filters
            return self._convert_generic_filter(filter_name, filter_config, policy_type, complexity)

    def _convert_http_basic_filter(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """Convert HTTPBasicFilter to Azure APIM authentication-basic policy."""
        return {
            'type': 'authentication-basic',
            'policy': {
                'authentication-basic': {
                    'username': config.get('username', '{{username}}'),
                    'password': config.get('password', '{{password}}')
                }
            },
            'inbound': True,
            'complexity': 'Simple'
        }

    def _convert_jwt_filter(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """Convert OAuth2Filter/JWTFilter to Azure APIM validate-jwt policy."""
        return {
            'type': 'validate-jwt',
            'policy': {
                'validate-jwt': {
                    'header-name': config.get('headerName', 'Authorization'),
                    'require-scheme': 'Bearer',
                    'issuer-signing-keys': {
                        'key': [{
                            'value': config.get('signingKey', '{{jwt-signing-key}}')
                        }]
                    },
                    'audiences': {
                        'audience': config.get('audience', 'api://default')
                    }
                }
            },
            'inbound': True,
            'complexity': 'Moderate'
        }

    def _convert_xml_threat_filter(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """Convert XMLThreatProtectionFilter to Azure APIM xml-threat-detection policy."""
        return {
            'type': 'xml-threat-detection',
            'policy': {
                'xml-threat-detection': {
                    'maximum-depth': str(config.get('maxDepth', '10')),
                    'maximum-node-count': str(config.get('maxNodeCount', '1000')),
                    'maximum-attribute-count': str(config.get('maxAttributeCount', '100')),
                    'maximum-namespace-count': str(config.get('maxNamespaceCount', '10')),
                    'enable-external-entity-detection': str(config.get('detectExternalEntities', 'true')).lower()
                }
            },
            'inbound': True,
            'complexity': 'Complex'
        }

    def _convert_throttling_filter(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """Convert ThrottlingFilter to Azure APIM rate-limit policy."""
        return {
            'type': 'rate-limit',
            'policy': {
                'rate-limit': {
                    'calls': config.get('maxRequests', '100'),
                    'renewal-period': config.get('timeWindow', '60'),
                    'counter-key': '@(context.Request.IpAddress)'
                }
            },
            'inbound': True,
            'complexity': 'Simple'
        }

    def _convert_ip_whitelist_filter(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """Convert IPWhitelistFilter to Azure APIM ip-filter policy."""
        allowed_ips = config.get('allowedIPs', ['127.0.0.1'])
        if isinstance(allowed_ips, str):
            allowed_ips = [allowed_ips]
        
        return {
            'type': 'ip-filter',
            'policy': {
                'ip-filter': {
                    'action': 'allow',
                    'address-range': [{'from': ip, 'to': ip} for ip in allowed_ips]
                }
            },
            'inbound': True,
            'complexity': 'Simple'
        }

    def _convert_xsl_transform_filter(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """Convert XSLTransformFilter to Azure APIM xsl-transform policy."""
        return {
            'type': 'xsl-transform',
            'policy': {
                'xsl-transform': {
                    'xsl-content': config.get('xslContent', '<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"></xsl:stylesheet>')
                }
            },
            'inbound': True,
            'complexity': 'Moderate'
        }

    def _convert_connect_url_filter(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """Convert ConnectToURLFilter to Azure APIM set-backend-service policy."""
        return {
            'type': 'set-backend-service',
            'policy': {
                'set-backend-service': {
                    'base-url': config.get('url', 'https://api.backend.com')
                }
            },
            'inbound': True,
            'complexity': 'Simple'
        }

    def _convert_generic_filter(self, filter_name: str, config: Dict[str, Any], 
                               policy_type: str, complexity: str) -> Dict[str, Any]:
        """Generic conversion for supported filters without specific implementation."""
        return {
            'type': policy_type,
            'policy': {
                policy_type: {
                    'note': f'Converted from {filter_name}',
                    'configuration': config
                }
            },
            'inbound': True,
            'complexity': complexity,
            'requires_manual_review': True
        }

    def convert_filter_circuit(self, circuit_config: Dict[str, Any]) -> Dict[str, Any]:
        """
        Convert a complete Axway FilterCircuit to Azure APIM policy.
        
        Args:
            circuit_config: Complete FilterCircuit configuration
            
        Returns:
            Dictionary containing the converted APIM policy set
        """
        circuit_name = circuit_config.get('name', 'UnknownCircuit')
        filters = circuit_config.get('filters', [])
        
        logger.info(f"Converting FilterCircuit: {circuit_name}")
        logger.info(f"Total filters in circuit: {len(filters)}")
        
        self.stats['total_circuits'] += 1
        self.stats['total_filters'] += len(filters)
        
        converted_policies = []
        
        for filter_config in filters:
            filter_name = filter_config.get('name', 'UnknownFilter')
            filter_type = filter_config.get('type', filter_name)
            
            converted_policy = self.convert_filter(filter_type, filter_config)
            converted_policy['original_name'] = filter_name
            converted_policies.append(converted_policy)
            
            if converted_policy.get('type') != 'externalized':
                self.stats['converted_filters'] += 1

        # Calculate success rate
        if self.stats['total_filters'] > 0:
            self.stats['success_rate'] = (self.stats['converted_filters'] / self.stats['total_filters']) * 100

        # Generate complete APIM policy
        apim_policy = {
            'name': f"{circuit_name}_APIM_Policy",
            'original_circuit': circuit_name,
            'conversion_timestamp': datetime.now().isoformat(),
            'statistics': {
                'total_filters': len(filters),
                'converted_filters': self.stats['converted_filters'] - (self.stats['total_filters'] - len(filters)),
                'externalized_filters': len([p for p in converted_policies if p.get('type') == 'externalized']),
                'success_rate': f"{((len(filters) - len([p for p in converted_policies if p.get('type') == 'externalized'])) / len(filters)) * 100:.0f}%" if filters else "0%"
            },
            'inbound_policies': [p for p in converted_policies if p.get('inbound', True)],
            'outbound_policies': [p for p in converted_policies if not p.get('inbound', True)],
            'backend_policies': [p for p in converted_policies if p.get('type') == 'set-backend-service']
        }
        
        return apim_policy

    def convert_yaml_to_apim(self, yaml_file_path: str, output_file_path: Optional[str] = None) -> Dict[str, Any]:
        """
        Convert Axway FilterCircuit YAML file to Azure APIM policy.
        
        Args:
            yaml_file_path: Path to the Axway FilterCircuit YAML file
            output_file_path: Optional path to save the converted APIM policy
            
        Returns:
            Conversion result with statistics and policy data
        """
        try:
            # Load YAML file
            with open(yaml_file_path, 'r', encoding='utf-8') as file:
                circuit_data = yaml.safe_load(file)
            
            logger.info(f"Loaded FilterCircuit from: {yaml_file_path}")
            
            # Convert the circuit
            apim_policy = self.convert_filter_circuit(circuit_data)
            
            # Save output if path provided
            if output_file_path:
                with open(output_file_path, 'w', encoding='utf-8') as output_file:
                    json.dump(apim_policy, output_file, indent=2, ensure_ascii=False)
                logger.info(f"Saved APIM policy to: {output_file_path}")
            
            return {
                'success': True,
                'apim_policy': apim_policy,
                'statistics': apim_policy['statistics'],
                'message': f"Successfully converted FilterCircuit to APIM policy"
            }
            
        except FileNotFoundError:
            error_msg = f"YAML file not found: {yaml_file_path}"
            logger.error(error_msg)
            return {'success': False, 'error': error_msg}
        
        except yaml.YAMLError as e:
            error_msg = f"YAML parsing error: {str(e)}"
            logger.error(error_msg)
            return {'success': False, 'error': error_msg}
        
        except Exception as e:
            error_msg = f"Conversion error: {str(e)}"
            logger.error(error_msg)
            return {'success': False, 'error': error_msg}

    def batch_convert(self, input_directory: str, output_directory: str) -> Dict[str, Any]:
        """
        Convert all FilterCircuit YAML files in a directory.
        
        Args:
            input_directory: Directory containing Axway FilterCircuit YAML files
            output_directory: Directory to save converted APIM policies
            
        Returns:
            Batch conversion results with overall statistics
        """
        if not os.path.exists(input_directory):
            return {'success': False, 'error': f"Input directory not found: {input_directory}"}
        
        os.makedirs(output_directory, exist_ok=True)
        
        yaml_files = [f for f in os.listdir(input_directory) if f.endswith(('.yaml', '.yml'))]
        
        if not yaml_files:
            return {'success': False, 'error': f"No YAML files found in: {input_directory}"}
        
        results = []
        total_success = 0
        
        for yaml_file in yaml_files:
            input_path = os.path.join(input_directory, yaml_file)
            output_path = os.path.join(output_directory, f"{os.path.splitext(yaml_file)[0]}_apim.json")
            
            result = self.convert_yaml_to_apim(input_path, output_path)
            results.append({
                'file': yaml_file,
                'success': result['success'],
                'statistics': result.get('statistics'),
                'error': result.get('error')
            })
            
            if result['success']:
                total_success += 1
        
        return {
            'success': True,
            'total_files': len(yaml_files),
            'successful_conversions': total_success,
            'batch_success_rate': f"{(total_success / len(yaml_files)) * 100:.1f}%",
            'results': results
        }

    def strategic_assessment(self, circuit_configs: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Perform strategic assessment of FilterCircuit migration complexity.
        
        Args:
            circuit_configs: List of FilterCircuit configurations
            
        Returns:
            Strategic assessment report
        """
        assessment = {
            'total_circuits': len(circuit_configs),
            'complexity_analysis': {'Simple': 0, 'Moderate': 0, 'Complex': 0},
            'migration_recommendations': [],
            'risk_factors': [],
            'estimated_effort_days': 0
        }
        
        for circuit in circuit_configs:
            filters = circuit.get('filters', [])
            
            for filter_config in filters:
                filter_type = filter_config.get('type', 'Unknown')
                
                if filter_type in self.supported_filters:
                    complexity = self.supported_filters[filter_type]['complexity']
                    assessment['complexity_analysis'][complexity] += 1
                else:
                    assessment['complexity_analysis']['Complex'] += 1
                    assessment['risk_factors'].append(f"Unsupported filter: {filter_type}")
        
        # Generate recommendations based on complexity analysis
        total_filters = sum(assessment['complexity_analysis'].values())
        
        if assessment['complexity_analysis']['Complex'] / total_filters > 0.3:
            assessment['migration_recommendations'].append("Consider phased migration approach")
            assessment['estimated_effort_days'] += 15
        
        if assessment['complexity_analysis']['Moderate'] / total_filters > 0.5:
            assessment['migration_recommendations'].append("Allocate extra testing time for moderate complexity filters")
            assessment['estimated_effort_days'] += 10
        
        assessment['estimated_effort_days'] += (assessment['complexity_analysis']['Simple'] * 0.5 +
                                              assessment['complexity_analysis']['Moderate'] * 2 +
                                              assessment['complexity_analysis']['Complex'] * 5)
        
        return assessment

def main():
    """Main entry point for the strategic converter."""
    parser = argparse.ArgumentParser(
        description="Strategic Axway FilterCircuit to Azure APIM Converter",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python strategic_filter_converter.py --matrix
  python strategic_filter_converter.py --convert policy.yaml
  python strategic_filter_converter.py --batch input_dir/ output_dir/
  python strategic_filter_converter.py --assess policies/ --report assessment.json
        """
    )
    
    parser.add_argument('--version', action='version', version='Strategic Converter 1.0.0')
    parser.add_argument('--matrix', action='store_true', help='Display strategic filter matrix')
    parser.add_argument('--convert', metavar='FILE', help='Convert single YAML file')
    parser.add_argument('--output', metavar='FILE', help='Output file for converted policy')
    parser.add_argument('--batch', metavar='DIR', help='Batch convert directory of YAML files')
    parser.add_argument('--batch-output', metavar='DIR', help='Output directory for batch conversion')
    parser.add_argument('--assess', metavar='DIR', help='Perform strategic assessment')
    parser.add_argument('--report', metavar='FILE', help='Save assessment report to file')
    parser.add_argument('--verbose', '-v', action='store_true', help='Verbose output')
    
    args = parser.parse_args()
    
    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)
    
    converter = StrategicFilterConverter()
    
    if args.matrix:
        converter.display_strategic_matrix()
        return
    
    if args.convert:
        output_path = args.output or f"{os.path.splitext(args.convert)[0]}_apim.json"
        result = converter.convert_yaml_to_apim(args.convert, output_path)
        
        if result['success']:
            print(f"✅ Strategic FilterCircuit conversion completed!")
            print(f"🏗️  Architectural Transformation: Imperative Filter Network → Declarative Policy Pipeline")
            print(f"📊 Strategic Analysis:")
            print(f"  - Circuit: {os.path.basename(args.convert)}")
            stats = result['statistics']
            print(f"  - Total filters: {stats['total_filters']}")
            print(f"  - Converted filters: {stats['converted_filters']}")
            print(f"  - Success rate: {stats['success_rate']}")
            print(f"  - Externalized filters: {stats['externalized_filters']}")
        else:
            print(f"❌ Conversion failed: {result['error']}")
            sys.exit(1)
    
    elif args.batch:
        output_dir = args.batch_output or f"{args.batch}_apim_output"
        result = converter.batch_convert(args.batch, output_dir)
        
        if result['success']:
            print(f"✅ Batch conversion completed!")
            print(f"📊 Results: {result['successful_conversions']}/{result['total_files']} files converted")
            print(f"📈 Success rate: {result['batch_success_rate']}")
        else:
            print(f"❌ Batch conversion failed: {result['error']}")
            sys.exit(1)
    
    elif args.assess:
        # Load all YAML files for assessment
        yaml_files = [f for f in os.listdir(args.assess) if f.endswith(('.yaml', '.yml'))]
        circuits = []
        
        for yaml_file in yaml_files:
            try:
                with open(os.path.join(args.assess, yaml_file), 'r') as f:
                    circuits.append(yaml.safe_load(f))
            except Exception as e:
                logger.warning(f"Could not load {yaml_file}: {e}")
        
        assessment = converter.strategic_assessment(circuits)
        
        if args.report:
            with open(args.report, 'w') as f:
                json.dump(assessment, f, indent=2)
            print(f"📋 Strategic assessment saved to: {args.report}")
        
        print(f"🎯 Strategic Migration Assessment:")
        print(f"  - Total circuits: {assessment['total_circuits']}")
        print(f"  - Estimated effort: {assessment['estimated_effort_days']:.1f} days")
        print(f"  - Risk factors: {len(assessment['risk_factors'])}")
    
    else:
        # Default action - show matrix
        converter.display_strategic_matrix()
        print("\n🚀 Strategic Converter Ready!")
        print("Use --help for available commands")

if __name__ == "__main__":
    main()
