#!/usr/bin/env python3
"""
Utility Functions

Common utilities for Axway to Azure APIM conversion operations.
Provides helper functions for file operations, validation, and data processing.

Author: Enterprise API Team
Version: 1.0.0
License: MIT
"""

import os
import json
import yaml
import re
import hashlib
import logging
from typing import Dict, List, Any, Optional, Union, Tuple
from datetime import datetime
from pathlib import Path

logger = logging.getLogger(__name__)

class FileUtils:
    """File operation utilities."""
    
    @staticmethod
    def ensure_directory(path: str) -> str:
        """
        Ensure directory exists, create if necessary.
        
        Args:
            path: Directory path to ensure
            
        Returns:
            The path that was created/verified
        """
        os.makedirs(path, exist_ok=True)
        return path
    
    @staticmethod
    def read_yaml_file(file_path: str) -> Dict[str, Any]:
        """
        Read and parse YAML file.
        
        Args:
            file_path: Path to YAML file
            
        Returns:
            Parsed YAML data
            
        Raises:
            FileNotFoundError: If file doesn't exist
            yaml.YAMLError: If YAML is invalid
        """
        try:
            with open(file_path, 'r', encoding='utf-8') as file:
                return yaml.safe_load(file)
        except FileNotFoundError:
            logger.error(f"YAML file not found: {file_path}")
            raise
        except yaml.YAMLError as e:
            logger.error(f"Invalid YAML in {file_path}: {str(e)}")
            raise
    
    @staticmethod
    def write_yaml_file(data: Dict[str, Any], file_path: str):
        """
        Write data to YAML file.
        
        Args:
            data: Data to write
            file_path: Output file path
        """
        FileUtils.ensure_directory(os.path.dirname(file_path))
        with open(file_path, 'w', encoding='utf-8') as file:
            yaml.dump(data, file, default_flow_style=False, sort_keys=False)
    
    @staticmethod
    def read_json_file(file_path: str) -> Dict[str, Any]:
        """
        Read and parse JSON file.
        
        Args:
            file_path: Path to JSON file
            
        Returns:
            Parsed JSON data
        """
        try:
            with open(file_path, 'r', encoding='utf-8') as file:
                return json.load(file)
        except FileNotFoundError:
            logger.error(f"JSON file not found: {file_path}")
            raise
        except json.JSONDecodeError as e:
            logger.error(f"Invalid JSON in {file_path}: {str(e)}")
            raise
    
    @staticmethod
    def write_json_file(data: Dict[str, Any], file_path: str, indent: int = 2):
        """
        Write data to JSON file.
        
        Args:
            data: Data to write
            file_path: Output file path
            indent: JSON indentation level
        """
        FileUtils.ensure_directory(os.path.dirname(file_path))
        with open(file_path, 'w', encoding='utf-8') as file:
            json.dump(data, file, indent=indent, ensure_ascii=False)
    
    @staticmethod
    def get_file_hash(file_path: str) -> str:
        """
        Calculate SHA-256 hash of file.
        
        Args:
            file_path: Path to file
            
        Returns:
            Hexadecimal hash string
        """
        hash_sha256 = hashlib.sha256()
        with open(file_path, 'rb') as file:
            for chunk in iter(lambda: file.read(4096), b""):
                hash_sha256.update(chunk)
        return hash_sha256.hexdigest()
    
    @staticmethod
    def find_files_by_extension(directory: str, extensions: List[str]) -> List[str]:
        """
        Find all files with specified extensions in directory.
        
        Args:
            directory: Directory to search
            extensions: List of file extensions (e.g., ['.yaml', '.yml'])
            
        Returns:
            List of file paths
        """
        found_files = []
        for root, _, files in os.walk(directory):
            for file in files:
                if any(file.lower().endswith(ext.lower()) for ext in extensions):
                    found_files.append(os.path.join(root, file))
        return found_files

class ValidationUtils:
    """Validation utilities for policy and configuration data."""
    
    @staticmethod
    def validate_policy_name(name: str) -> Tuple[bool, List[str]]:
        """
        Validate policy name against enterprise naming conventions.
        
        Args:
            name: Policy name to validate
            
        Returns:
            Tuple of (is_valid, list_of_issues)
        """
        issues = []
        
        # Check basic format
        if not re.match(r'^[A-Za-z][A-Za-z0-9_-]*$', name):
            issues.append("Name must start with letter and contain only letters, numbers, underscores, and hyphens")
        
        # Check length
        if len(name) < 3:
            issues.append("Name must be at least 3 characters long")
        elif len(name) > 50:
            issues.append("Name must not exceed 50 characters")
        
        # Check for reserved words
        reserved_words = ['default', 'global', 'system', 'admin', 'root']
        if name.lower() in reserved_words:
            issues.append(f"Name '{name}' is reserved")
        
        return len(issues) == 0, issues
    
    @staticmethod
    def validate_url(url: str) -> Tuple[bool, List[str]]:
        """
        Validate URL format.
        
        Args:
            url: URL to validate
            
        Returns:
            Tuple of (is_valid, list_of_issues)
        """
        issues = []
        
        # Basic URL pattern - Updated to be more permissive for localhost
        url_pattern = re.compile(
            r'^https?://'  # http:// or https://
            r'(?:'
            r'(?:[A-Z0-9](?:[A-Z0-9-]{0,61}[A-Z0-9])?\.)+[A-Z]{2,6}\.?|'  # domain...
            r'localhost(?::[0-9]+)?|'  # localhost with optional port...
            r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}(?::[0-9]+)?'  # ...or ip with optional port
            r')'
            r'(?:/?|[/?]\S+)*$', re.IGNORECASE)  # path
        
        if not url_pattern.match(url):
            issues.append("Invalid URL format")
        
        # Security recommendations
        if url.startswith('http://') and not url.startswith('http://localhost'):
            issues.append("Consider using HTTPS for security")
        
        return len(issues) == 0, issues
    
    @staticmethod
    def validate_json_structure(data: Any, required_fields: List[str]) -> Tuple[bool, List[str]]:
        """
        Validate JSON data structure.
        
        Args:
            data: JSON data to validate
            required_fields: List of required field names
            
        Returns:
            Tuple of (is_valid, list_of_issues)
        """
        issues = []
        
        if not isinstance(data, dict):
            issues.append("Data must be a JSON object")
            return False, issues
        
        for field in required_fields:
            if field not in data:
                issues.append(f"Missing required field: {field}")
        
        return len(issues) == 0, issues

class DataUtils:
    """Data processing and transformation utilities."""
    
    @staticmethod
    def merge_dictionaries(dict1: Dict, dict2: Dict, deep: bool = True) -> Dict:
        """
        Merge two dictionaries.
        
        Args:
            dict1: First dictionary
            dict2: Second dictionary (takes precedence)
            deep: Whether to perform deep merge
            
        Returns:
            Merged dictionary
        """
        if not deep:
            result = dict1.copy()
            result.update(dict2)
            return result
        
        result = dict1.copy()
        for key, value in dict2.items():
            if key in result and isinstance(result[key], dict) and isinstance(value, dict):
                result[key] = DataUtils.merge_dictionaries(result[key], value, deep=True)
            else:
                result[key] = value
        
        return result
    
    @staticmethod
    def flatten_dictionary(data: Dict, separator: str = '.') -> Dict:
        """
        Flatten nested dictionary.
        
        Args:
            data: Dictionary to flatten
            separator: Separator for nested keys
            
        Returns:
            Flattened dictionary
        """
        def _flatten(obj, parent_key='', sep='.'):
            items = []
            if isinstance(obj, dict):
                for key, value in obj.items():
                    new_key = f"{parent_key}{sep}{key}" if parent_key else key
                    if isinstance(value, dict):
                        items.extend(_flatten(value, new_key, sep).items())
                    else:
                        items.append((new_key, value))
            return dict(items)
        
        return _flatten(data, sep=separator)
    
    @staticmethod
    def sanitize_string(text: str, max_length: Optional[int] = None) -> str:
        """
        Sanitize string for safe usage in configurations.
        
        Args:
            text: Text to sanitize
            max_length: Optional maximum length
            
        Returns:
            Sanitized string
        """
        # Remove control characters and excessive whitespace
        sanitized = re.sub(r'[\x00-\x1f\x7f-\x9f]', '', text)
        sanitized = ' '.join(sanitized.split())
        
        # Truncate if necessary
        if max_length and len(sanitized) > max_length:
            sanitized = sanitized[:max_length-3] + '...'
        
        return sanitized
    
    @staticmethod
    def extract_variables(text: str) -> List[str]:
        """
        Extract variable placeholders from text.
        
        Args:
            text: Text containing variables like {{variable}}
            
        Returns:
            List of variable names
        """
        pattern = r'\{\{([^}]+)\}\}'
        matches = re.findall(pattern, text)
        return [match.strip() for match in matches]
    
    @staticmethod
    def replace_variables(text: str, variables: Dict[str, str]) -> str:
        """
        Replace variable placeholders in text.
        
        Args:
            text: Text containing variables like {{variable}}
            variables: Dictionary of variable name to value mappings
            
        Returns:
            Text with variables replaced
        """
        def replace_func(match):
            var_name = match.group(1).strip()
            return variables.get(var_name, match.group(0))
        
        return re.sub(r'\{\{([^}]+)\}\}', replace_func, text)

class ConversionUtils:
    """Utilities for filter to policy conversions."""
    
    @staticmethod
    def generate_policy_id(circuit_name: str, filter_name: str) -> str:
        """
        Generate unique policy ID.
        
        Args:
            circuit_name: Name of the circuit
            filter_name: Name of the filter
            
        Returns:
            Unique policy ID
        """
        base_id = f"{circuit_name}_{filter_name}".lower()
        base_id = re.sub(r'[^a-z0-9_-]', '_', base_id)
        timestamp = datetime.now().strftime("%Y%m%d")
        return f"{base_id}_{timestamp}"
    
    @staticmethod
    def normalize_filter_name(filter_name: str) -> str:
        """
        Normalize filter name for consistent processing.
        
        Args:
            filter_name: Original filter name
            
        Returns:
            Normalized filter name
        """
        # Remove common prefixes/suffixes
        normalized = filter_name
        for prefix in ['com.vordel.', 'org.axway.']:
            if normalized.startswith(prefix):
                normalized = normalized[len(prefix):]
        
        # Remove package path
        if '.' in normalized:
            normalized = normalized.split('.')[-1]
        
        return normalized
    
    @staticmethod
    def convert_time_units(value: str, from_unit: str, to_unit: str) -> int:
        """
        Convert time values between units.
        
        Args:
            value: Time value as string
            from_unit: Source unit (seconds, minutes, hours, days)
            to_unit: Target unit (seconds, minutes, hours, days)
            
        Returns:
            Converted time value
        """
        try:
            num_value = int(value)
        except ValueError:
            raise ValueError(f"Invalid time value: {value}")
        
        # Convert to seconds first
        to_seconds = {
            'seconds': 1,
            'minutes': 60,
            'hours': 3600,
            'days': 86400
        }
        
        if from_unit not in to_seconds:
            raise ValueError(f"Unsupported time unit: {from_unit}")
        
        if to_unit not in to_seconds:
            raise ValueError(f"Unsupported time unit: {to_unit}")
        
        seconds = num_value * to_seconds[from_unit]
        return seconds // to_seconds[to_unit]
    
    @staticmethod
    def generate_apim_policy_xml(policy_type: str, configuration: Dict[str, Any]) -> str:
        """
        Generate XML for APIM policy.
        
        Args:
            policy_type: Type of APIM policy
            configuration: Policy configuration
            
        Returns:
            XML string for the policy
        """
        # Basic XML template generation
        xml_parts = [f'<{policy_type}']
        
        # Add attributes
        for key, value in configuration.items():
            if isinstance(value, (str, int, float, bool)):
                xml_parts.append(f' {key}="{value}"')
        
        xml_parts.append(' />')
        
        return ''.join(xml_parts)

class LoggingUtils:
    """Logging utilities for conversion operations."""
    
    @staticmethod
    def setup_logging(log_level: str = 'INFO', log_file: Optional[str] = None):
        """
        Setup logging configuration.
        
        Args:
            log_level: Logging level (DEBUG, INFO, WARNING, ERROR)
            log_file: Optional log file path
        """
        log_format = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        
        # Configure root logger
        logging.basicConfig(
            level=getattr(logging, log_level.upper()),
            format=log_format,
            handlers=[]
        )
        
        # Console handler
        console_handler = logging.StreamHandler()
        console_handler.setFormatter(logging.Formatter(log_format))
        logging.getLogger().addHandler(console_handler)
        
        # File handler if specified
        if log_file:
            FileUtils.ensure_directory(os.path.dirname(log_file))
            file_handler = logging.FileHandler(log_file)
            file_handler.setFormatter(logging.Formatter(log_format))
            logging.getLogger().addHandler(file_handler)
    
    @staticmethod
    def log_conversion_stats(stats: Dict[str, Any]):
        """
        Log conversion statistics.
        
        Args:
            stats: Conversion statistics dictionary
        """
        logger.info("=== CONVERSION STATISTICS ===")
        for key, value in stats.items():
            logger.info(f"{key}: {value}")

class ErrorUtils:
    """Error handling utilities."""
    
    @staticmethod
    def create_error_response(error_type: str, message: str, details: Optional[Dict] = None) -> Dict[str, Any]:
        """
        Create standardized error response.
        
        Args:
            error_type: Type of error
            message: Error message
            details: Optional error details
            
        Returns:
            Standardized error response
        """
        error_response = {
            'success': False,
            'error': {
                'type': error_type,
                'message': message,
                'timestamp': datetime.now().isoformat()
            }
        }
        
        if details:
            error_response['error']['details'] = details
        
        return error_response
    
    @staticmethod
    def handle_conversion_error(func):
        """
        Decorator for handling conversion errors.
        
        Args:
            func: Function to wrap with error handling
            
        Returns:
            Wrapped function with error handling
        """
        def wrapper(*args, **kwargs):
            try:
                return func(*args, **kwargs)
            except FileNotFoundError as e:
                return ErrorUtils.create_error_response('FileNotFound', str(e))
            except yaml.YAMLError as e:
                return ErrorUtils.create_error_response('YAMLError', f'YAML parsing error: {str(e)}')
            except json.JSONDecodeError as e:
                return ErrorUtils.create_error_response('JSONError', f'JSON parsing error: {str(e)}')
            except Exception as e:
                return ErrorUtils.create_error_response('UnexpectedError', f'Unexpected error: {str(e)}')
        
        return wrapper

# Export main classes for easy import
__all__ = [
    'FileUtils',
    'ValidationUtils', 
    'DataUtils',
    'ConversionUtils',
    'LoggingUtils',
    'ErrorUtils'
]
