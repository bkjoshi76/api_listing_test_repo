#!/usr/bin/env python3
"""
Azure APIM Policy Validator

Demo validation for Azure APIM policies converted from Axway FilterCircuit.
Ensures 100% schema compliance and identifies potential deployment issues.

Author: Enterprise API Team
Version: 1.0.0
License: MIT
"""

import json
import xml.etree.ElementTree as ET
import re
import argparse
import os
import sys
from typing import Dict, List, Any, Tuple, Optional
import logging
from datetime import datetime

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class APIMPolicyValidator:
    """
    Comprehensive validator for Azure APIM policies.
    
    Validates converted policies against Azure APIM schema requirements,
    security best practices, and enterprise deployment standards.
    """
    
    def __init__(self):
        """Initialize the APIM policy validator."""
        self.version = "1.0.0"
        
        # Azure APIM supported policy types
        self.supported_policies = {
            # Authentication
            'authentication-basic', 'authentication-certificate', 'validate-jwt',
            # Access control
            'ip-filter', 'check-header', 'cors',
            # Advanced
            'rate-limit', 'quota', 'concurrency-limit',
            # Transformation
            'set-body', 'set-header', 'set-query-parameter', 'rewrite-uri',
            'json-to-xml', 'xml-to-json', 'find-and-replace', 'xsl-transform',
            # Backend
            'set-backend-service', 'retry', 'timeout', 'forward-request',
            # Monitoring
            'log-to-eventhub', 'emit-metric', 'trace',
            # Cache
            'cache-lookup', 'cache-store', 'cache-lookup-value', 'cache-store-value',
            # Security
            'xml-threat-detection', 'json-threat-detection',
            # Response
            'mock-response', 'return-response'
        }
        
        # Policy section requirements
        self.policy_sections = ['inbound', 'backend', 'outbound', 'on-error']
        
        # Validation rules
        self.validation_rules = {
            'required_attributes': {
                'rate-limit': ['calls', 'renewal-period'],
                'validate-jwt': ['header-name'],
                'ip-filter': ['action'],
                'set-backend-service': ['base-url'],
                'cache-lookup': ['key'],
                'quota': ['calls', 'bandwidth', 'renewal-period']
            },
            'security_validations': [
                'no_hardcoded_secrets',
                'https_backends_only',
                'secure_headers',
                'input_validation'
            ],
            'performance_validations': [
                'reasonable_timeouts',
                'efficient_transformations',
                'appropriate_caching'
            ]
        }
        
        # Enterprise compliance requirements
        self.enterprise_requirements = {
            'naming_convention': r'^[A-Za-z][A-Za-z0-9_-]*$',
            'max_policy_size': 64 * 1024,  # 64KB max policy size
            'max_nesting_depth': 10,
            'required_monitoring': ['emit-metric', 'log-to-eventhub', 'trace']
        }

    def validate_policy_structure(self, policy_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Validate the basic structure of an APIM policy.
        
        Args:
            policy_data: Policy data dictionary
            
        Returns:
            Validation result with structure compliance details
        """
        validation_result = {
            'structure_valid': True,
            'issues': [],
            'warnings': [],
            'recommendations': []
        }
        
        # Check if it's a valid policy structure
        if not isinstance(policy_data, dict):
            validation_result['structure_valid'] = False
            validation_result['issues'].append("Policy must be a JSON object")
            return validation_result
        
        # Check for required top-level fields
        required_fields = ['name', 'inbound_policies']
        for field in required_fields:
            if field not in policy_data:
                validation_result['warnings'].append(f"Missing recommended field: {field}")
        
        # Validate policy sections
        policy_sections = ['inbound_policies', 'backend_policies', 'outbound_policies']
        for section in policy_sections:
            if section in policy_data:
                if not isinstance(policy_data[section], list):
                    validation_result['issues'].append(f"Section '{section}' must be an array")
                    validation_result['structure_valid'] = False
        
        # Check policy size
        policy_size = len(json.dumps(policy_data))
        if policy_size > self.enterprise_requirements['max_policy_size']:
            validation_result['warnings'].append(
                f"Policy size ({policy_size} bytes) exceeds recommended maximum "
                f"({self.enterprise_requirements['max_policy_size']} bytes)"
            )
        
        # Validate naming convention
        policy_name = policy_data.get('name', '')
        if policy_name and not re.match(self.enterprise_requirements['naming_convention'], policy_name):
            validation_result['warnings'].append(
                f"Policy name '{policy_name}' doesn't follow enterprise naming convention"
            )
        
        return validation_result

    def validate_individual_policies(self, policies: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Validate individual policy elements within a policy collection.
        
        Args:
            policies: List of individual policy configurations
            
        Returns:
            Validation result for individual policies
        """
        validation_result = {
            'policies_valid': True,
            'validated_policies': 0,
            'supported_policies': 0,
            'unsupported_policies': 0,
            'issues': [],
            'warnings': [],
            'policy_details': []
        }
        
        for policy in policies:
            policy_detail = {
                'type': policy.get('type', 'unknown'),
                'valid': True,
                'issues': [],
                'warnings': []
            }
            
            policy_type = policy.get('type')
            validation_result['validated_policies'] += 1
            
            # Check if policy type is supported
            if policy_type not in self.supported_policies:
                validation_result['unsupported_policies'] += 1
                policy_detail['valid'] = False
                policy_detail['issues'].append(f"Unsupported policy type: {policy_type}")
                validation_result['issues'].append(f"Unsupported policy type: {policy_type}")
                validation_result['policies_valid'] = False
            else:
                validation_result['supported_policies'] += 1
                
                # Validate required attributes
                if policy_type in self.validation_rules['required_attributes']:
                    required_attrs = self.validation_rules['required_attributes'][policy_type]
                    policy_config = policy.get('policy', {}).get(policy_type, {})
                    
                    for attr in required_attrs:
                        if attr not in policy_config:
                            policy_detail['issues'].append(f"Missing required attribute: {attr}")
                            validation_result['issues'].append(
                                f"Policy {policy_type} missing required attribute: {attr}"
                            )
                            validation_result['policies_valid'] = False
                
                # Validate policy-specific requirements
                policy_validation = self._validate_specific_policy(policy_type, policy)
                policy_detail['issues'].extend(policy_validation.get('issues', []))
                policy_detail['warnings'].extend(policy_validation.get('warnings', []))
                
                if policy_validation.get('issues'):
                    policy_detail['valid'] = False
                    validation_result['policies_valid'] = False
            
            validation_result['policy_details'].append(policy_detail)
        
        return validation_result

    def _validate_specific_policy(self, policy_type: str, policy: Dict[str, Any]) -> Dict[str, Any]:
        """
        Validate specific policy type requirements.
        
        Args:
            policy_type: Type of the policy
            policy: Policy configuration
            
        Returns:
            Validation result for the specific policy
        """
        result = {'issues': [], 'warnings': []}
        policy_config = policy.get('policy', {}).get(policy_type, {})
        
        # Rate limit validation
        if policy_type == 'rate-limit':
            calls = policy_config.get('calls')
            if calls and (not isinstance(calls, (int, str)) or (isinstance(calls, str) and not calls.isdigit())):
                result['issues'].append("Rate limit 'calls' must be a number")
            
            renewal_period = policy_config.get('renewal-period')
            if renewal_period and int(renewal_period) < 1:
                result['warnings'].append("Very low renewal period may cause performance issues")
        
        # JWT validation
        elif policy_type == 'validate-jwt':
            header_name = policy_config.get('header-name', '')
            if header_name and not header_name.startswith('Authorization'):
                result['warnings'].append("JWT typically uses Authorization header")
            
            # Check for signing keys configuration
            if 'issuer-signing-keys' not in policy_config and 'open-id-config-url' not in policy_config:
                result['issues'].append("JWT validation requires either signing keys or OpenID config URL")
        
        # Backend service validation
        elif policy_type == 'set-backend-service':
            base_url = policy_config.get('base-url', '')
            if base_url and not base_url.startswith('https://'):
                result['warnings'].append("Consider using HTTPS for backend services")
        
        # IP filter validation
        elif policy_type == 'ip-filter':
            action = policy_config.get('action')
            if action not in ['allow', 'forbid']:
                result['issues'].append("IP filter action must be 'allow' or 'forbid'")
        
        return result

    def validate_security_compliance(self, policy_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Validate security compliance of the policy.
        
        Args:
            policy_data: Complete policy data
            
        Returns:
            Security validation result
        """
        security_result = {
            'security_compliant': True,
            'security_score': 100,
            'issues': [],
            'warnings': [],
            'recommendations': []
        }
        
        # Check for hardcoded secrets
        policy_json = json.dumps(policy_data).lower()
        suspicious_patterns = ['password', 'secret', 'key', 'token']
        
        for pattern in suspicious_patterns:
            if f'"{pattern}"' in policy_json and not pattern.startswith('{{'):
                security_result['warnings'].append(f"Potential hardcoded {pattern} detected")
                security_result['security_score'] -= 10
        
        # Check for HTTPS enforcement
        all_policies = []
        for section in ['inbound_policies', 'backend_policies', 'outbound_policies']:
            if section in policy_data:
                all_policies.extend(policy_data[section])
        
        has_https_enforcement = False
        has_authentication = False
        has_rate_limiting = False
        
        for policy in all_policies:
            policy_type = policy.get('type')
            
            if policy_type in ['authentication-basic', 'authentication-certificate', 'validate-jwt']:
                has_authentication = True
            
            if policy_type in ['rate-limit', 'quota', 'concurrency-limit']:
                has_rate_limiting = True
            
            if policy_type == 'set-backend-service':
                backend_config = policy.get('policy', {}).get('set-backend-service', {})
                backend_url = backend_config.get('base-url', '')
                if backend_url and backend_url.startswith('https://'):
                    has_https_enforcement = True
        
        # Security recommendations
        if not has_authentication:
            security_result['recommendations'].append("Consider adding authentication policy")
            security_result['security_score'] -= 20
        
        if not has_rate_limiting:
            security_result['recommendations'].append("Consider adding rate limiting for DoS protection")
            security_result['security_score'] -= 15
        
        if not has_https_enforcement:
            security_result['recommendations'].append("Ensure all backend services use HTTPS")
            security_result['security_score'] -= 10
        
        if security_result['security_score'] < 70:
            security_result['security_compliant'] = False
        
        return security_result

    def validate_enterprise_compliance(self, policy_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Validate enterprise deployment compliance.
        
        Args:
            policy_data: Complete policy data
            
        Returns:
            Enterprise compliance validation result
        """
        enterprise_result = {
            'enterprise_compliant': True,
            'compliance_score': 100,
            'issues': [],
            'warnings': [],
            'recommendations': []
        }
        
        # Check for monitoring policies
        all_policies = []
        for section in ['inbound_policies', 'backend_policies', 'outbound_policies']:
            if section in policy_data:
                all_policies.extend(policy_data[section])
        
        monitoring_policies = [p for p in all_policies 
                             if p.get('type') in self.enterprise_requirements['required_monitoring']]
        
        if not monitoring_policies:
            enterprise_result['warnings'].append("No monitoring policies detected")
            enterprise_result['recommendations'].append("Add monitoring policies for observability")
            enterprise_result['compliance_score'] -= 20
        
        # Check for error handling
        has_error_handling = 'on_error_policies' in policy_data
        if not has_error_handling:
            enterprise_result['recommendations'].append("Consider adding error handling policies")
            enterprise_result['compliance_score'] -= 10
        
        # Check documentation
        if 'description' not in policy_data and 'documentation' not in policy_data:
            enterprise_result['warnings'].append("Policy lacks documentation")
            enterprise_result['compliance_score'] -= 10
        
        # Check version information
        if 'version' not in policy_data:
            enterprise_result['recommendations'].append("Add version information for tracking")
            enterprise_result['compliance_score'] -= 5
        
        if enterprise_result['compliance_score'] < 80:
            enterprise_result['enterprise_compliant'] = False
        
        return enterprise_result

    def validate_policy_file(self, file_path: str) -> Dict[str, Any]:
        """
        Validate a single policy file.
        
        Args:
            file_path: Path to the policy JSON file
            
        Returns:
            Complete validation result
        """
        try:
            with open(file_path, 'r', encoding='utf-8') as file:
                policy_data = json.load(file)
            
            logger.info(f"Validating policy file: {file_path}")
            
            # Perform all validations
            structure_result = self.validate_policy_structure(policy_data)
            
            all_policies = []
            for section in ['inbound_policies', 'backend_policies', 'outbound_policies']:
                if section in policy_data:
                    all_policies.extend(policy_data[section])
            
            policies_result = self.validate_individual_policies(all_policies)
            security_result = self.validate_security_compliance(policy_data)
            enterprise_result = self.validate_enterprise_compliance(policy_data)
            
            # Combine results
            overall_valid = (structure_result['structure_valid'] and 
                           policies_result['policies_valid'] and
                           security_result['security_compliant'] and
                           enterprise_result['enterprise_compliant'])
            
            return {
                'file_path': file_path,
                'overall_valid': overall_valid,
                'validation_timestamp': datetime.now().isoformat(),
                'structure': structure_result,
                'policies': policies_result,
                'security': security_result,
                'enterprise': enterprise_result,
                'summary': {
                    'total_policies': policies_result['validated_policies'],
                    'supported_policies': policies_result['supported_policies'],
                    'unsupported_policies': policies_result['unsupported_policies'],
                    'security_score': security_result['security_score'],
                    'compliance_score': enterprise_result['compliance_score']
                }
            }
            
        except FileNotFoundError:
            return {'success': False, 'error': f"File not found: {file_path}"}
        except json.JSONDecodeError as e:
            return {'success': False, 'error': f"JSON parsing error: {str(e)}"}
        except Exception as e:
            return {'success': False, 'error': f"Validation error: {str(e)}"}

    def validate_directory(self, directory_path: str) -> Dict[str, Any]:
        """
        Validate all policy files in a directory.
        
        Args:
            directory_path: Directory containing policy JSON files
            
        Returns:
            Batch validation results
        """
        if not os.path.exists(directory_path):
            return {'success': False, 'error': f"Directory not found: {directory_path}"}
        
        json_files = [f for f in os.listdir(directory_path) if f.endswith('.json')]
        
        if not json_files:
            return {'success': False, 'error': f"No JSON files found in: {directory_path}"}
        
        results = []
        overall_stats = {
            'total_files': len(json_files),
            'valid_files': 0,
            'invalid_files': 0,
            'total_policies': 0,
            'supported_policies': 0,
            'average_security_score': 0,
            'average_compliance_score': 0
        }
        
        for json_file in json_files:
            file_path = os.path.join(directory_path, json_file)
            result = self.validate_policy_file(file_path)
            
            if result.get('overall_valid'):
                overall_stats['valid_files'] += 1
            else:
                overall_stats['invalid_files'] += 1
            
            if 'summary' in result:
                summary = result['summary']
                overall_stats['total_policies'] += summary['total_policies']
                overall_stats['supported_policies'] += summary['supported_policies']
                overall_stats['average_security_score'] += summary['security_score']
                overall_stats['average_compliance_score'] += summary['compliance_score']
            
            results.append(result)
        
        # Calculate averages
        if len(json_files) > 0:
            overall_stats['average_security_score'] = overall_stats['average_security_score'] / len(json_files)
            overall_stats['average_compliance_score'] = overall_stats['average_compliance_score'] / len(json_files)
            overall_stats['validation_success_rate'] = f"{(overall_stats['valid_files'] / len(json_files)) * 100:.1f}%"
        
        return {
            'success': True,
            'validation_timestamp': datetime.now().isoformat(),
            'overall_statistics': overall_stats,
            'file_results': results
        }

    def generate_validation_report(self, validation_results: Dict[str, Any], 
                                 output_path: Optional[str] = None) -> str:
        """
        Generate a comprehensive validation report.
        
        Args:
            validation_results: Results from validation
            output_path: Optional path to save the report
            
        Returns:
            Report content as string
        """
        report = []
        report.append("=" * 80)
        report.append("  AZURE APIM POLICY VALIDATION REPORT")
        report.append("=" * 80)
        report.append(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        report.append("")
        
        if 'overall_statistics' in validation_results:
            stats = validation_results['overall_statistics']
            report.append("📊 OVERALL STATISTICS")
            report.append("-" * 40)
            report.append(f"Total files validated: {stats['total_files']}")
            report.append(f"Valid files: {stats['valid_files']}")
            report.append(f"Invalid files: {stats['invalid_files']}")
            report.append(f"Success rate: {stats.get('validation_success_rate', 'N/A')}")
            report.append(f"Total policies: {stats['total_policies']}")
            report.append(f"Supported policies: {stats['supported_policies']}")
            report.append(f"Average security score: {stats['average_security_score']:.1f}/100")
            report.append(f"Average compliance score: {stats['average_compliance_score']:.1f}/100")
            report.append("")
        
        # Individual file results
        if 'file_results' in validation_results:
            report.append("📁 INDIVIDUAL FILE RESULTS")
            report.append("-" * 40)
            
            for result in validation_results['file_results']:
                if 'error' in result:
                    report.append(f"❌ {result.get('file_path', 'Unknown')}: {result['error']}")
                    continue
                
                file_name = os.path.basename(result['file_path'])
                status = "✅ VALID" if result['overall_valid'] else "❌ INVALID"
                report.append(f"{status} {file_name}")
                
                if 'summary' in result:
                    summary = result['summary']
                    report.append(f"   Policies: {summary['supported_policies']}/{summary['total_policies']} supported")
                    report.append(f"   Security: {summary['security_score']}/100")
                    report.append(f"   Compliance: {summary['compliance_score']}/100")
                
                # Show issues if any
                issues = []
                for section in ['structure', 'policies', 'security', 'enterprise']:
                    if section in result and 'issues' in result[section]:
                        issues.extend(result[section]['issues'])
                
                if issues:
                    report.append(f"   Issues: {'; '.join(issues[:3])}{'...' if len(issues) > 3 else ''}")
                
                report.append("")
        
        report_content = "\n".join(report)
        
        if output_path:
            with open(output_path, 'w', encoding='utf-8') as f:
                f.write(report_content)
            logger.info(f"Validation report saved to: {output_path}")
        
        return report_content

def main():
    """Main entry point for the APIM policy validator."""
    parser = argparse.ArgumentParser(
        description="Azure APIM Policy Validator",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python validate_apim_policies.py policy.json
  python validate_apim_policies.py --directory policies/
  python validate_apim_policies.py --directory policies/ --report validation_report.txt
        """
    )
    
    parser.add_argument('--version', action='version', version='APIM Policy Validator 1.0.0')
    parser.add_argument('file', nargs='?', help='Single policy file to validate')
    parser.add_argument('--directory', '-d', metavar='DIR', help='Directory of policy files to validate')
    parser.add_argument('--report', '-r', metavar='FILE', help='Save validation report to file')
    parser.add_argument('--verbose', '-v', action='store_true', help='Verbose output')
    parser.add_argument('--json-output', '-j', action='store_true', help='Output results as JSON')
    
    args = parser.parse_args()
    
    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)
    
    validator = APIMPolicyValidator()
    
    if args.file:
        # Validate single file
        result = validator.validate_policy_file(args.file)
        
        if args.json_output:
            print(json.dumps(result, indent=2))
        else:
            if result.get('overall_valid'):
                print("✅ POLICY VALIDATION PASSED")
                print(f"📁 File: {args.file}")
                if 'summary' in result:
                    summary = result['summary']
                    print(f"📊 Statistics:")
                    print(f"   - Policies: {summary['supported_policies']}/{summary['total_policies']} supported")
                    print(f"   - Security Score: {summary['security_score']}/100")
                    print(f"   - Compliance Score: {summary['compliance_score']}/100")
            else:
                print("❌ POLICY VALIDATION FAILED")
                if 'error' in result:
                    print(f"Error: {result['error']}")
                else:
                    # Show issues from all sections
                    for section_name in ['structure', 'policies', 'security', 'enterprise']:
                        if section_name in result:
                            section = result[section_name]
                            if section.get('issues'):
                                print(f"{section_name.title()} Issues:")
                                for issue in section['issues']:
                                    print(f"   - {issue}")
    
    elif args.directory:
        # Validate directory
        result = validator.validate_directory(args.directory)
        
        if not result.get('success'):
            print(f"❌ Validation failed: {result['error']}")
            sys.exit(1)
        
        if args.json_output:
            print(json.dumps(result, indent=2))
        else:
            # Generate and display report
            report = validator.generate_validation_report(result, args.report)
            print(report)
            
            # Summary
            stats = result['overall_statistics']
            if stats['valid_files'] == stats['total_files']:
                print("🎉 ALL VALIDATIONS PASSED")
            else:
                print(f"⚠️  {stats['invalid_files']}/{stats['total_files']} files failed validation")
    
    else:
        parser.print_help()
        sys.exit(1)

if __name__ == "__main__":
    main()
