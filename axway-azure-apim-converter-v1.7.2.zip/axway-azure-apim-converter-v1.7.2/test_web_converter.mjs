import fs from 'fs';
import { AxwayToApimConverter } from './web/src/js/axway-converter.js';

// Read test file
const testFile = 'simple_test.json';
const configContent = fs.readFileSync(testFile, 'utf8');
const config = JSON.parse(configContent);

// Initialize converter
const converter = new AxwayToApimConverter();

// Convert
// Note: The web converter expects an object for convertFilterCircuitToXml
const result = converter.convertFilterCircuitToXml(config);

// Write output
fs.writeFileSync('web_output.xml', result.xml);
console.log('Web conversion complete. Output written to web_output.xml');
