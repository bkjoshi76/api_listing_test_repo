import os
import glob
import subprocess
import sys

# Paths
base_dir = r"c:\projects\axway-azure-apim-converter-complete-v1.1.0\axway-azure-apim-converter-complete"
test_dir = os.path.join(base_dir, "tests", "comparison_run")
converter_script = os.path.join(base_dir, "scripts", "fully_validated_converter.py")

# Get all JSON and YAML files
files = glob.glob(os.path.join(test_dir, "*.json")) + glob.glob(os.path.join(test_dir, "*.yaml"))

print(f"Found {len(files)} files to convert.")

for file_path in files:
    filename = os.path.basename(file_path)
    output_filename = f"{os.path.splitext(filename)[0]}_python.xml"
    output_path = os.path.join(test_dir, output_filename)
    
    print(f"Converting {filename}...")
    
    try:
        # Construct command
        cmd = [sys.executable, converter_script, "--convert", file_path, "--output", output_path]
        
        # Run converter
        result = subprocess.run(cmd, capture_output=True, text=True)
        
        if result.returncode == 0:
            print(f"  SUCCESS: {output_filename}")
        else:
            print(f"  FAILED: {filename}")
            print(f"  Error: {result.stderr}")
            
    except Exception as e:
        print(f"  ERROR: {e}")

print("Python conversion complete.")
